#!/usr/bin/env bash
# ==============================================================
# Banxico-Plus — INF-07: endurecimiento UFW + SSH por Tailscale
# Idempotente. Prerequisito: tailscale0 con IP 100.x (rol previo)
# ==============================================================
set -euo pipefail

VPC_CIDR="${1:-10.10.0.0/20}"
TRON_P2P_PORT="18888"
TRON_API_PORT="8090"
SSH_PORT="22"

[[ $EUID -eq 0 ]] || { echo "ERROR: root requerido"; exit 1; }

TS_IP="$(ip -4 -o addr show dev tailscale0 | awk '{print $4}' | cut -d/ -f1 || true)"
[[ "$TS_IP" =~ ^100\. ]] || { echo "ERROR: tailscale0 sin IP 100.x — UFW intacto"; exit 1; }

ufw default deny incoming
ufw default allow outgoing

# Purga idempotente
ufw delete allow "${SSH_PORT}/tcp"                        2>/dev/null || true
ufw delete allow in on tailscale0 to any port "$SSH_PORT" proto tcp 2>/dev/null || true
ufw delete allow from "$VPC_CIDR"                         2>/dev/null || true
ufw delete allow "${TRON_P2P_PORT}/tcp"                   2>/dev/null || true
ufw delete allow "${TRON_P2P_PORT}/udp"                   2>/dev/null || true
ufw delete allow from "$VPC_CIDR" to any port "$TRON_API_PORT" proto tcp 2>/dev/null || true
ufw delete deny  "${TRON_API_PORT}/tcp"                   2>/dev/null || true

ufw allow in on tailscale0 to any port "$SSH_PORT" proto tcp comment 'SSH via Tailscale only'
ufw allow from "$VPC_CIDR" comment 'DO VPC interno'
ufw allow from "$VPC_CIDR" to any port "$TRON_API_PORT" proto tcp comment 'TRON API solo VPC'
ufw deny  "${TRON_API_PORT}/tcp" comment 'TRON API bloqueada al exterior'
ufw allow "${TRON_P2P_PORT}/tcp" comment 'TRON P2P TCP'
ufw allow "${TRON_P2P_PORT}/udp" comment 'TRON P2P UDP'

ufw --force enable
ufw reload
ufw status verbose
