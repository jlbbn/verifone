// ==============================================================
// Banxico-Plus — Chaos Engineering (k6)
// Objetivo: romper idempotency_keys, FOR UPDATE SKIP LOCKED y
// el pool de Postgres con 10k webhooks + reorgs oscilantes.
//
// Ejecución:
//   BASE_URL=https://app.banxico.plus STRIPE_WEBHOOK_SECRET=whsec_... \
//   k6 run chaos/stress-test.js
// ==============================================================
import http from 'k6/http';
import { check, sleep } from 'k6';
import { Counter, Trend, Rate } from 'k6/metrics';
import crypto from 'k6/crypto';
import exec from 'k6/execution';

// ---- Config ----
const BASE_URL = __ENV.BASE_URL || 'http://localhost:3000';
const STRIPE_SECRET = __ENV.STRIPE_WEBHOOK_SECRET || 'whsec_chaos';
const TARGET_WEBHOOKS = 10000;

// ---- Métricas de batalla ----
const idempotencyDuplicates = new Counter('idempotency_duplicates');   // 200s repetidos sobre mismo event.id
const illegalTransitions    = new Counter('illegal_transitions');      // regresiones rechazadas (esperado >0)
const serverErrors          = new Counter('server_5xx');               // 5xx = pool/locks rotos (NO esperado)
const dbTimeouts            = new Counter('db_timeout_signatures');    // cuerpos con lock/pool timeout
const latencyWebhook        = new Trend('webhook_latency_ms', true);
const dupWinRate            = new Rate('duplicate_win_rate');          // % duplicados que NO generaron doble efecto

export const options = {
  scenarios: {
    // ── Escenario 1: tormenta de DUPLICADOS Stripe ──
    // El MISMO event.id disparado masivamente en paralelo →
    // fuerza colisión en PK (provider,key) de idempotency_keys.
    stripe_duplicate_storm: {
      executor: 'shared-iterations',
      exec: 'stripeDuplicate',
      vus: 200,
      iterations: 4000,          // 40% del volumen: mismo eventId
      maxDuration: '10m',
    },
    // ── Escenario 2: webhooks Stripe únicos (presión de pool) ──
    stripe_unique_storm: {
      executor: 'shared-iterations',
      exec: 'stripeUnique',
      vus: 300,
      iterations: 4000,
      maxDuration: '10m',
    },
    // ── Escenario 3: oscilación reorg/confirm TRON ──
    // CONFIRMED ↔ REORGED concurrente sobre el mismo txHash →
    // fuerza contención FOR UPDATE y valida la máquina CHAIN.
    tron_reorg_oscillation: {
      executor: 'shared-iterations',
      exec: 'tronReorg',
      vus: 100,
      iterations: 2000,
      maxDuration: '10m',
    },
  },
  thresholds: {
    // Criterios de RUPTURA: si se violan, el sistema falló el chaos test
    'server_5xx':              ['count<50'],        // <0.5% de 5xx tolerables
    'db_timeout_signatures':   ['count<20'],
    'duplicate_win_rate':      ['rate>0.99'],       // 99% de duplicados neutralizados
    'webhook_latency_ms':      ['p(95)<2000'],      // cola de locks no debe degradar p95
  },
};

// ---- Utilidades ----
function stripeSignature(payload, secret) {
  const ts = Math.floor(Date.now() / 1000);
  const sig = crypto.hmac('sha256', secret, `${ts}.${payload}`, 'hex');
  return `t=${ts},v1=${sig}`;
}

function stripeEvent(eventId, objectId) {
  return JSON.stringify({
    id: eventId,
    type: 'payment_intent.succeeded',
    data: { object: { id: objectId, amount: 150000, currency: 'mxn', status: 'succeeded' } },
  });
}

function postStripe(payload) {
  const res = http.post(`${BASE_URL}/webhook/stripe`, payload, {
    headers: {
      'content-type': 'application/json',
      'stripe-signature': stripeSignature(payload, STRIPE_SECRET),
    },
    timeout: '30s',
  });
  latencyWebhook.add(res.timings.duration);
  if (res.status >= 500) serverErrors.add(1);
  if (res.body && /(lock timeout|connection pool|remaining connection slots|too many clients)/i.test(res.body)) {
    dbTimeouts.add(1);
  }
  return res;
}

// EventId COMPARTIDO por todo el escenario: el peor caso de Stripe retries
const SHARED_EVENT_ID = 'evt_chaos_shared_0001';

export function stripeDuplicate() {
  const payload = stripeEvent(SHARED_EVENT_ID, 'pi_chaos_shared_0001');
  const res = postStripe(payload);

  const accepted = check(res, { 'dup aceptado sin 5xx': (r) => r.status === 200 });
  if (accepted && res.status === 200) idempotencyDuplicates.add(1);
  // Si el endpoint devuelve metadata del resultado, el duplicado debe reportar applied:false
  try {
    const body = JSON.parse(res.body);
    dupWinRate.add(body.applied === false || body.reason === 'duplicate_event' || res.status === 200);
  } catch (_) {
    dupWinRate.add(res.status === 200); // sin body estructurado: basta no-5xx
  }
  sleep(0.05);
}

export function stripeUnique() {
  const i = exec.scenario.iterationInTest;
  const payload = stripeEvent(`evt_chaos_u_${i}`, `pi_chaos_u_${i}`);
  const res = postStripe(payload);
  check(res, { 'unique procesado': (r) => r.status === 200 });
  sleep(0.02);
}

// ---- TRON: mismo txHash oscilando CONFIRMED → REORGED → CONFIRMED ----
export function tronReorg() {
  const i = exec.scenario.iterationInTest;
  const txHash = `tron_chaos_${String(i % 25).padStart(4, '0')}`;   // solo 25 hashes: máxima contención por fila
  const wantReorg = (exec.vu.idInTest % 2) === 0;                    // mitad pide reorg, mitad confirma

  const res = http.post(
    `${BASE_URL}/webhook/tron`,
    JSON.stringify({
      txHash,
      blockHash: `blk_${i}`,
      action: wantReorg ? 'reorg' : 'confirm',
      idempotencyKey: `${wantReorg ? 'reorg' : 'confirm'}:${txHash}:${i}`,
    }),
    { headers: { 'content-type': 'application/json' }, timeout: '30s' },
  );

  latencyWebhook.add(res.timings.duration);
  if (res.status >= 500) serverErrors.add(1);
  if (res.body && /(lock timeout|deadlock|connection pool)/i.test(res.body)) dbTimeouts.add(1);

  try {
    const body = JSON.parse(res.body);
    if (body.reason && String(body.reason).startsWith('illegal_transition')) illegalTransitions.add(1);
  } catch (_) { /* cuerpo no JSON */ }

  check(res, { 'reorg sin 5xx': (r) => r.status < 500 });
  sleep(0.05);
}

// ---- Teardown: resumen de posturas rotas ----
export function teardown() {
  console.log('=== CHAOS SUMMARY ===');
  console.log(`Duplicados recibidos:     ver métrica idempotency_duplicates`);
  console.log(`Duplicados neutralizados: ver duplicate_win_rate (umbral >99%)`);
  console.log(`5xx (pool/locks rotos):   ver server_5xx (umbral <50)`);
  console.log(`Firmas timeout DB:        ver db_timeout_signatures (umbral <20)`);
}
```

```bash
# Ejecución del chaos test
BASE_URL=https://app.banxico.plus STRIPE_WEBHOOK_SECRET=whsec_*** k6 run chaos/stress-test.js

# Variante agresiva contra el pool (elevar VUs sin subir iterations)
BASE_URL=https://app.banxico.plus k6 run --vus 600 --duration 5m chaos/stress-test.js
```