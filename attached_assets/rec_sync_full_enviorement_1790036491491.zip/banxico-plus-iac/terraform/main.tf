# ==============================================================
# Banxico-Plus LLC — IaC principal (DigitalOcean)
# VPC + PostgreSQL gestionado + Spaces (backups) + Droplets
# ==============================================================

terraform {
  required_version = ">= 1.6.0"

  required_providers {
    digitalocean = {
      source  = "digitalocean/digitalocean"
      version = "~> 2.40"
    }
  }

  # Backend remoto recomendado (descomentar tras crear el bucket de estado):
  # backend "s3" {
  #   bucket                      = "banxico-plus-terraform-state"
  #   key                         = "prod/terraform.tfstate"
  #   region                      = "us-east-1" # requerido por aws-sdk, DO lo ignora
  #   endpoints = { s3 = "https://nyc3.digitaloceanspaces.com" }
  #   skip_credentials_validation = true
  #   skip_metadata_api_check     = true
  #   skip_region_validation      = true
  #   skip_requesting_account_id  = true
  # }
}

provider "digitalocean" {
  token = var.do_token
}

# --------------------------------------------------------------
# VPC (INF-07: subred privada 10.10.0.0/20)
# --------------------------------------------------------------
resource "digitalocean_vpc" "main" {
  name        = "${var.project}-vpc"
  region      = var.region
  ip_range    = var.vpc_cidr
  description = "VPC privada Banxico-Plus — tráfico interno irrestricto"
}

# --------------------------------------------------------------
# PostgreSQL gestionado (banxico-plus-db)
# --------------------------------------------------------------
resource "digitalocean_database_cluster" "pg" {
  name                 = "${var.project}-pg"
  engine               = "pg"
  version              = var.pg_version
  size                 = var.pg_size
  region               = var.region
  node_count           = var.pg_node_count
  private_network_uuid = digitalocean_vpc.main.id

  maintenance_window {
    day  = "sunday"
    hour = "04:00:00"
  }
}

resource "digitalocean_database_db" "main" {
  cluster_id = digitalocean_database_cluster.pg.id
  name       = "banxico-plus-db"
}

resource "digitalocean_database_db" "sandbox" {
  cluster_id = digitalocean_database_cluster.pg.id
  name       = "banxico-plus-sandbox-db"
}

resource "digitalocean_database_user" "app" {
  cluster_id = digitalocean_database_cluster.pg.id
  name       = "banxico_app"
}

# Firewall del clúster: solo droplets del proyecto (defensa en profundidad vs. UFW)
resource "digitalocean_database_firewall" "pg" {
  cluster_id = digitalocean_database_cluster.pg.id

  rule {
    type  = "droplet"
    value = digitalocean_droplet.app.id
  }
  rule {
    type  = "droplet"
    value = digitalocean_droplet.tron_signer.id
  }
}

# --------------------------------------------------------------
# Spaces — bucket de backups cifrados (INF-14, retención 30d)
# --------------------------------------------------------------
resource "digitalocean_spaces_bucket" "backups" {
  name   = "${var.project}-backups"
  region = var.spaces_region
  acl    = "private"

  lifecycle_rule {
    id      = "purge-backups-30d"
    enabled = true
    prefix  = "backups/banxico-plus-db/"
    expiration {
      days = 30
    }
    abort_incomplete_multipart_upload_days = 1
  }
}

# --------------------------------------------------------------
# SSH key para bootstrap inicial (post-Ansible queda solo Tailscale)
# --------------------------------------------------------------
resource "digitalocean_ssh_key" "bootstrap" {
  name       = "${var.project}-bootstrap"
  public_key = file(var.ssh_public_key_path)
}

# --------------------------------------------------------------
# Droplet: app (API + workers tron-poller / outbound-dispatcher)
# --------------------------------------------------------------
resource "digitalocean_droplet" "app" {
  name     = "${var.project}-app"
  image    = var.droplet_image
  size     = var.app_size
  region   = var.region
  vpc_uuid = digitalocean_vpc.main.id
  ssh_keys = [digitalocean_ssh_key.bootstrap.id]
  tags     = ["${var.project}", "app"]

  user_data = <<-EOF
    #cloud-config
    packages: [curl, ufw]
    runcmd:
      - curl -fsSL https://tailscale.com/install.sh | sh
  EOF
}

# --------------------------------------------------------------
# Droplet: tron-mainnet-lite (fullnode + solidity local)
# --------------------------------------------------------------
resource "digitalocean_droplet" "tron_mainnet_lite" {
  name     = "${var.project}-tron-mainnet-lite"
  image    = var.droplet_image
  size     = var.tron_node_size
  region   = var.region
  vpc_uuid = digitalocean_vpc.main.id
  ssh_keys = [digitalocean_ssh_key.bootstrap.id]
  tags     = ["${var.project}", "tron-node"]

  user_data = <<-EOF
    #cloud-config
    packages: [curl, ufw, openjdk-17-jre-headless]
    runcmd:
      - curl -fsSL https://tailscale.com/install.sh | sh
  EOF
}

# --------------------------------------------------------------
# Droplet: tron-signer (firma aislada — sin servicios públicos)
# --------------------------------------------------------------
resource "digitalocean_droplet" "tron_signer" {
  name     = "${var.project}-tron-signer"
  image    = var.droplet_image
  size     = var.signer_size
  region   = var.region
  vpc_uuid = digitalocean_vpc.main.id
  ssh_keys = [digitalocean_ssh_key.bootstrap.id]
  tags     = ["${var.project}", "tron-signer"]

  user_data = <<-EOF
    #cloud-config
    packages: [curl, ufw]
    runcmd:
      - curl -fsSL https://tailscale.com/install.sh | sh
  EOF
}
