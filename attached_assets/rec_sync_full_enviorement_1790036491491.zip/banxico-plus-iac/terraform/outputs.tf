output "vpc_id" {
  value = digitalocean_vpc.main.id
}

output "app_public_ip" {
  value = digitalocean_droplet.app.ipv4_address
}

output "app_private_ip" {
  value = digitalocean_droplet.app.ipv4_address_private
}

output "tron_mainnet_lite_private_ip" {
  value = digitalocean_droplet.tron_mainnet_lite.ipv4_address_private
}

output "tron_signer_private_ip" {
  value = digitalocean_droplet.tron_signer.ipv4_address_private
}

output "pg_host_private" {
  value = digitalocean_database_cluster.pg.private_host
}

output "pg_port" {
  value = digitalocean_database_cluster.pg.port
}

output "pg_app_password" {
  description = "Password del rol banxico_app — registrar en Doppler inmediatamente"
  value       = digitalocean_database_user.app.password
  sensitive   = true
}

output "database_url" {
  description = "DSN de producción (inyectar a Doppler como DATABASE_URL)"
  value       = "postgresql://${digitalocean_database_user.app.name}:${digitalocean_database_user.app.password}@${digitalocean_database_cluster.pg.private_host}:${digitalocean_database_cluster.pg.port}/banxico-plus-db?sslmode=require"
  sensitive   = true
}

output "sandbox_database_url" {
  description = "DSN sandbox (inyectar a Doppler como SANDBOX_DATABASE_URL — INF-15)"
  value       = "postgresql://${digitalocean_database_user.app.name}:${digitalocean_database_user.app.password}@${digitalocean_database_cluster.pg.private_host}:${digitalocean_database_cluster.pg.port}/banxico-plus-sandbox-db?sslmode=require"
  sensitive   = true
}

output "backups_bucket" {
  value = digitalocean_spaces_bucket.backups.name
}

output "backups_bucket_endpoint" {
  value = "https://${var.spaces_region}.digitaloceanspaces.com"
}
