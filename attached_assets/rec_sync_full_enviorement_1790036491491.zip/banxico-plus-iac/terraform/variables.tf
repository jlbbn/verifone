variable "do_token" {
  description = "DigitalOcean API token (inyectar: TF_VAR_do_token vía Doppler)"
  type        = string
  sensitive   = true
}

variable "project" {
  description = "Prefijo de nombrado de todos los recursos"
  type        = string
  default     = "banxico-plus"
}

variable "region" {
  description = "Región principal de DigitalOcean"
  type        = string
  default     = "nyc3"
}

variable "spaces_region" {
  description = "Región del bucket Spaces (soporta lifecycle rules)"
  type        = string
  default     = "nyc3"
}

variable "vpc_cidr" {
  description = "Subred privada VPC — alineada con reglas UFW INF-07"
  type        = string
  default     = "10.10.0.0/20"
}

variable "pg_version" {
  type    = string
  default = "16"
}

variable "pg_size" {
  description = "Slug del plan del clúster PG gestionado"
  type        = string
  default     = "db-s-2vcpu-4gb"
}

variable "pg_node_count" {
  description = "Nodos del clúster (2 = standby automático + failover)"
  type        = number
  default     = 2
}

variable "droplet_image" {
  type    = string
  default = "ubuntu-24-04-x64"
}

variable "app_size" {
  description = "Droplet API + workers"
  type        = string
  default     = "s-2vcpu-4gb"
}

variable "tron_node_size" {
  description = "Droplet nodo TRON — exige I/O y RAM para el chain DB"
  type        = string
  default     = "g-4vcpu-16gb"
}

variable "signer_size" {
  description = "Droplet signer — cómputo mínimo, exposición mínima"
  type        = string
  default     = "s-1vcpu-1gb"
}

variable "ssh_public_key_path" {
  description = "Llave pública de bootstrap (se elimina tras Ansible; SSH final = Tailscale)"
  type        = string
  default     = "~/.ssh/id_ed25519.pub"
}
