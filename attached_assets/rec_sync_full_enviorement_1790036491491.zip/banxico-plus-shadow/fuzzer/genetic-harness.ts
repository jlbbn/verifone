// ==============================================================
// fuzzer/genetic-harness.ts — Motor de Fuzzing Mutacional (Genético)
// Arquitectura:
//   Hilo principal  → población de mutadores, selección genética,
//                     métricas globales (p99, heap snapshots, umbrales)
//   worker_threads  → inyección HTTP keep-alive a 50k RPS objetivo
//   SharedArrayBuffer → contadores y histograma de latencia compartidos
//                       (Atomics — cero serialización entre hilos)
//
// Clases de mutación (fitness = errores 5xx + latencia inducida):
//   A. Corrupción ASN.1 DER en firmas de webhook
//   B. Overflow BigInt en montos (NUMERIC(20,6), 2^64, negativos, 1e308)
//   C. Colisión de entropía HMAC (replay, XOR, truncado, timestamp skew)
//
// Uso:
//   TARGET=http://shadow.banxico.local RPS_TARGET=50000 \
//   DURATION_MIN=30 npx tsx fuzzer/genetic-harness.ts
// ==============================================================
import { Worker, isMainThread, workerData, parentPort } from "node:worker_threads";
import { cpus } from "node:os";
import * as http from "node:http";
import * as crypto from "node:crypto";
import * as v8 from "node:v8";
import { writeFileSync } from "node:fs";
import { join } from "node:path";

// ---------------------------------------------------------------
// Configuración
// ---------------------------------------------------------------
const TARGET       = process.env.TARGET       ?? "http://localhost:3000";
const RPS_TARGET   = Number(process.env.RPS_TARGET ?? 50_000);
const DURATION_MIN = Number(process.env.DURATION_MIN ?? 30);
const NUM_WORKERS  = Math.max(2, cpus().length - 1);
const SECRET       = process.env.STRIPE_WEBHOOK_SECRET ?? "whsec_shadow";

// ---------------------------------------------------------------
// Layout del SharedArrayBuffer (Int32/Float64 compartidos)
//   [0]  requests totales        [1]  respuestas 2xx
//   [2]  respuestas 4xx          [3]  respuestas 5xx
//   [4]  timeouts (>30s)         [5]  errores de socket (ECONNRESET etc.)
//   [6]  firma de pool roto (body match)   [7]  deadlocks detectados
//   [8..107] histograma de latencia: 100 buckets logarítmicos (0.1ms..60s)
// ---------------------------------------------------------------
const SAB_SLOTS = 128;
const LAT_BUCKET_BASE = 8;
const LAT_BUCKETS = 100;

// Latencia ms → bucket logarítmico (b = floor(log2(ms*10)), acotado)
function latBucket(ms: number): number {
  const b = Math.floor(Math.log2(Math.max(ms * 10, 1)));
  return Math.min(Math.max(b, 0), LAT_BUCKETS - 1);
}
function bucketMs(b: number): number { return Math.pow(2, b) / 10; }

// ---------------------------------------------------------------
// GENERADORES DE PAYLOAD BASE
// ---------------------------------------------------------------
function baseStripeEvent(id: string) {
  return {
    id,
    type: "payment_intent.succeeded",
    data: { object: { id: `pi_${id}`, amount: 150000, currency: "mxn", status: "succeeded" } },
  };
}
function baseTronEvent(txHash: string) {
  return { txHash, blockHash: crypto.randomBytes(16).toString("hex"), action: "confirm" };
}

// ---------------------------------------------------------------
// MUTADORES — cada uno recibe un payload válido y lo corrompe
// ---------------------------------------------------------------
type Mutator = (payload: Buffer, headers: Record<string, string>) => { payload: Buffer; headers: Record<string, string> };

// --- Clase A: corrupción ASN.1 DER de la firma del webhook ---
// La firma Stripe v1 es hex de HMAC, pero el harness inyecta DER crudo
// para sondear parsers laxos (TRON recoverable sigs serializadas DER).
const mutDerBitFlip: Mutator = (p, h) => {
  const der = Buffer.from("3046022100" + crypto.randomBytes(33).toString("hex") +
                          "022100" + crypto.randomBytes(33).toString("hex"), "hex");
  const i = crypto.randomInt(der.length);
  der[i] ^= 1 << crypto.randomInt(8);              // flip de 1 bit aleatorio
  return { payload: Buffer.concat([p, der]), headers: { ...h, "x-der-signature": der.toString("hex") } };
};
const mutDerLengthOverflow: Mutator = (p, h) => {
  // Longitud declarada 0xFF con contenido real de 4 bytes → parser que confíe
  // en el length field lee fuera de rango (OOB read en implementaciones débiles)
  const der = Buffer.from([0x30, 0xff, 0x02, 0x01, 0x01, 0x00]);
  return { payload: Buffer.concat([p, der]), headers: { ...h, "x-der-signature": der.toString("hex") } };
};
const mutDerTruncated: Mutator = (p, h) => {
  const der = crypto.randomBytes(72);
  return { payload: p, headers: { ...h, "x-der-signature": der.subarray(0, 8).toString("hex") } };
};

// --- Clase B: overflow de enteros/BigInt en montos ---
const mutBigIntOverflow: Mutator = (p, h) => {
  const ev = JSON.parse(p.toString());
  const amounts = [
    "18446744073709551616",          // 2^64 — desborda BIGINT
    "-1",                            // negativo en monto
    "99999999999999999999.999999",   // NUMERIC(20,6) saturado al máximo legal
    "100000000000000000000.0",       // NUMERIC(20,6) +1 dígito → debe rechazar
    "1e308",                         // float que al stringify revienta precisión
    "0.0000001",                     // sub-precisión (7 decimales > escala 6)
    "NaN", "Infinity",               // vectores de parseo laxo
  ];
  ev.data.object.amount = amounts[crypto.randomInt(amounts.length)];
  return { payload: Buffer.from(JSON.stringify(ev)), headers: h };
};

// --- Clase C: colisiones de entropía HMAC ---
const mutHmacReplay: Mutator = (p, h) => {
  // Timestamp fijado: firma válida una vez, replay eterno → debe morir en
  // idempotency_keys o en la ventana anti-replay (300s)
  const ts = "1700000000";
  const sig = crypto.createHmac("sha256", SECRET).update(`${ts}.${p.toString()}`).digest("hex");
  return { payload: p, headers: { ...h, "stripe-signature": `t=${ts},v1=${sig}` } };
};
const mutHmacXor: Mutator = (p, h) => {
  // Firma válida con 1 byte XOR — debe rechazarse en tiempo constante
  // sin oráculo de timing (el harness mide varianza de latencia en 401s)
  const ts = Math.floor(Date.now() / 1000).toString();
  const sig = Buffer.from(crypto.createHmac("sha256", SECRET).update(`${ts}.${p.toString()}`).digest("hex"));
  sig[0] = String.fromCharCode(sig[0].charCodeAt(0) === "a" ? "b".charCodeAt(0) : "a".charCodeAt(0));
  return { payload: p, headers: { ...h, "stripe-signature": `t=${ts},v1=${sig.toString()}` } };
};
const mutHmacTruncated: Mutator = (p, h) => {
  const ts = Math.floor(Date.now() / 1000).toString();
  const sig = crypto.createHmac("sha256", SECRET).update(`${ts}.${p.toString()}`).digest("hex");
  return { payload: p, headers: { ...h, "stripe-signature": `t=${ts},v1=${sig.slice(0, 16)}` } };
};
const mutHmacFutureTs: Mutator = (p, h) => {
  // Timestamp 1h en el futuro — skew attack contra la ventana anti-replay
  const ts = (Math.floor(Date.now() / 1000) + 3600).toString();
  const sig = crypto.createHmac("sha256", SECRET).update(`${ts}.${p.toString()}`).digest("hex");
  return { payload: p, headers: { ...h, "stripe-signature": `t=${ts},v1=${sig}` } };
};

// --- Mutación genética: crossover de dos vectores ---
function crossover(a: Buffer, b: Buffer): Buffer {
  if (a.length < 8 || b.length < 8) return a;
  const cut = crypto.randomInt(1, Math.min(a.length, b.length) - 1);
  return Buffer.concat([a.subarray(0, cut), b.subarray(cut)]);
}

// ---------------------------------------------------------------
// POBLACIÓN GENÉTICA (hilo principal)
// fitness(m) = 5xx_inducidos*10 + pool_breaks*50 + (p99_delta_ms / 100)
// Selección: torneo de 3, elitismo del 20%, tasa de mutación 15%
// ---------------------------------------------------------------
interface Individual {
  name: string;
  mutator: Mutator;
  fitness: number;
  uses: number;
  breaks: number;    // 5xx + pool signatures atribuidas
}

const POPULATION: Individual[] = [
  { name: "der-bitflip",        mutator: mutDerBitFlip,        fitness: 0, uses: 0, breaks: 0 },
  { name: "der-len-overflow",   mutator: mutDerLengthOverflow, fitness: 0, uses: 0, breaks: 0 },
  { name: "der-truncated",      mutator: mutDerTruncated,      fitness: 0, uses: 0, breaks: 0 },
  { name: "bigint-overflow",    mutator: mutBigIntOverflow,    fitness: 0, uses: 0, breaks: 0 },
  { name: "hmac-replay",        mutator: mutHmacReplay,        fitness: 0, uses: 0, breaks: 0 },
  { name: "hmac-xor",           mutator: mutHmacXor,           fitness: 0, uses: 0, breaks: 0 },
  { name: "hmac-truncated",     mutator: mutHmacTruncated,     fitness: 0, uses: 0, breaks: 0 },
  { name: "hmac-future-ts",     mutator: mutHmacFutureTs,      fitness: 0, uses: 0, breaks: 0 },
];

function tournamentSelect(): Individual {
  let best = POPULATION[crypto.randomInt(POPULATION.length)];
  for (let i = 0; i < 2; i++) {
    const c = POPULATION[crypto.randomInt(POPULATION.length)];
    if (c.fitness > best.fitness) best = c;
  }
  return best;
}

// ---------------------------------------------------------------
// WORKER THREAD — inyector HTTP de alta frecuencia
// ---------------------------------------------------------------
const WORKER_SOURCE = `
const { parentPort, workerData } = require("node:worker_threads");
const http = require("node:http");
const crypto = require("node:crypto");

const { sab, target, rpsPerWorker, workerId } = workerData;
const stats = new Int32Array(sab);
const LAT_BASE = ${8};

function latBucket(ms) {
  const b = Math.floor(Math.log2(Math.max(ms * 10, 1)));
  return Math.min(Math.max(b, 0), 99);
}

const agent = new http.Agent({
  keepAlive: true,
  maxSockets: 512,            // sockets concurrentes por worker
  maxFreeSockets: 64,
  scheduling: "lifo",         // reutiliza el socket más caliente (menos handshake)
  timeout: 30000,
});

const POOL_RE = /(lock timeout|connection pool|remaining connection slots|too many clients|query_wait_timeout)/i;
const DEADLOCK_RE = /deadlock detected/i;

let running = true;
parentPort.on("message", (m) => { if (m === "stop") running = false; });

function fire(payloadBuf, headers) {
  const t0 = process.hrtime.bigint();
  const req = http.request(target + "/webhook/stripe", {
    method: "POST",
    agent,
    headers: {
      "content-type": "application/json",
      "content-length": payloadBuf.length,
      ...headers,
    },
  }, (res) => {
    let body = "";
    res.on("data", (c) => { body += c; });
    res.on("end", () => {
      const ms = Number(process.hrtime.bigint() - t0) / 1e6;
      Atomics.add(stats, LAT_BASE + latBucket(ms), 1);
      if (res.statusCode >= 200 && res.statusCode < 300) Atomics.add(stats, 1, 1);
      else if (res.statusCode >= 500) Atomics.add(stats, 3, 1);
      else Atomics.add(stats, 2, 1);
      if (POOL_RE.test(body)) Atomics.add(stats, 6, 1);
      if (DEADLOCK_RE.test(body)) Atomics.add(stats, 7, 1);
    });
  });
  req.on("timeout", () => { Atomics.add(stats, 4, 1); req.destroy(); });
  req.on("error", () => Atomics.add(stats, 5, 1));
  req.end(payloadBuf);
  Atomics.add(stats, 0, 1);
}

// Bucle de inyección con token bucket: sostiene rpsPerWorker sostenido
const intervalMs = 1000 / rpsPerWorker;
let next = Date.now();
(function loop() {
  if (!running) { agent.destroy(); return; }
  const now = Date.now();
  if (now >= next) {
    parentPort.postMessage({ type: "need-payload" });
    next = Math.max(next + intervalMs, now - 1000); // catch-up acotado: no espiral tras stall
  }
  setImmediate(loop);
})();

parentPort.on("message", (m) => {
  if (m && m.type === "payload") {
    fire(Buffer.from(m.payload, "base64"), m.headers);
  }
});
`;

// ---------------------------------------------------------------
// HILO PRINCIPAL — orquestación, genética, métricas
// ---------------------------------------------------------------
async function main(): Promise<void> {
  const sab = new SharedArrayBuffer(SAB_SLOTS * Int32Array.BYTES_PER_ELEMENT);
  const stats = new Int32Array(sab);

  const rpsPerWorker = Math.ceil(RPS_TARGET / NUM_WORKERS);
  console.log(`[fuzzer] workers=${NUM_WORKERS} rps/worker=${rpsPerWorker} target=${TARGET} dur=${DURATION_MIN}min`);

  const workers: Worker[] = [];
  for (let i = 0; i < NUM_WORKERS; i++) {
    const w = new Worker(WORKER_SOURCE, {
      eval: true,
      workerData: { sab, target: TARGET, rpsPerWorker, workerId: i },
    });
    // El worker pide payloads; el hilo principal muta con la población actual
    w.on("message", (m) => {
      if (m?.type === "need-payload") {
        const ind = Math.random() < 0.15
          ? POPULATION[crypto.randomInt(POPULATION.length)] // exploración 15%
          : tournamentSelect();                              // explotación 85%
        const base = Buffer.from(JSON.stringify(baseStripeEvent(`evt_fz_${crypto.randomUUID()}`)));
        const mutated = ind.mutator(base, {});
        ind.uses++;
        w.postMessage({ type: "payload", payload: mutated.payload.toString("base64"), headers: mutated.headers });
      }
    });
    w.on("error", (e) => console.error(`[fuzzer] worker ${i} error:`, e.message));
    workers.push(w);
  }

  // ---- Métricas y heap snapshots ----
  const startedAt = Date.now();
  const endAt = startedAt + DURATION_MIN * 60_000;
  let lastRequests = 0;
  let window5xx = 0;
  let heapBaseline = v8.getHeapStatistics().heap_size_limit;

  const snapshotDir = join(process.cwd(), "fuzzer-snapshots");
  let snapshotCount = 0;

  const tick = setInterval(() => {
    const now = Date.now();
    const total = Atomics.load(stats, 0);
    const rps = (total - lastRequests) / 5;
    lastRequests = total;

    // p50/p95/p99 del histograma compartido
    const hist: number[] = [];
    let histTotal = 0;
    for (let b = 0; b < LAT_BUCKETS; b++) {
      const n = Atomics.load(stats, LAT_BUCKET_BASE + b);
      hist.push(n);
      histTotal += n;
    }
    const pct = (q: number): number => {
      let acc = 0;
      for (let b = 0; b < LAT_BUCKETS; b++) {
        acc += hist[b];
        if (acc >= histTotal * q) return bucketMs(b);
      }
      return bucketMs(LAT_BUCKETS - 1);
    };
    const p50 = pct(0.5), p95 = pct(0.95), p99 = pct(0.99);

    const e2xx = Atomics.load(stats, 1);
    const e4xx = Atomics.load(stats, 2);
    const e5xx = Atomics.load(stats, 3);
    const timeouts = Atomics.load(stats, 4);
    const sockErr = Atomics.load(stats, 5);
    const poolBreaks = Atomics.load(stats, 6);
    const deadlocks = Atomics.load(stats, 7);

    window5xx = e5xx - window5xx;

    // Fitness: premia individuos que inducen 5xx/roturas de pool y latencia
    for (const ind of POPULATION) {
      const share = ind.uses > 0 ? ind.uses / Math.max(total, 1) : 0;
      ind.breaks = Math.round(poolBreaks * share * 50 + e5xx * share * 10);
      ind.fitness = ind.breaks + Math.max(0, p99 - 100) / 100;
    }

    const heap = v8.getHeapStatistics();
    const heapPct = (heap.used_heap_size / heap.heap_size_limit) * 100;

    console.log(
      `[fuzzer] t+${Math.round((now - startedAt) / 1000)}s ` +
      `rps=${rps.toFixed(0)} 2xx=${e2xx} 4xx=${e4xx} 5xx=${e5xx} ` +
      `t/o=${timeouts} sock=${sockErr} pool=${poolBreaks} dl=${deadlocks} | ` +
      `p50=${p50.toFixed(1)} p95=${p95.toFixed(1)} p99=${p99.toFixed(1)}ms | ` +
      `heap=${heapPct.toFixed(1)}% | elite=${POPULATION.slice().sort((a, b) => b.fitness - a.fitness)[0].name}`,
    );

    // Umbrales de degradación — abortar soak si el sistema colapsa
    if (p99 > 10_000 && now - startedAt > 120_000) {
      console.error(`[fuzzer] UMBRAL VIOLADO: p99=${p99}ms sostenido — sistema degradado, abortando`);
      shutdown(workers, tick, 2);
    }
    if (heapPct > 92) {
      console.error(`[fuzzer] UMBRAL VIOLADO: V8 heap ${heapPct}% — fuga de memoria probable`);
      const snap = v8.getHeapSnapshot();
      const path = join(snapshotDir, `heap-critical-${Date.now()}.heapsnapshot`);
      writeFileSync(path, "");
      snap.pipe(require("node:fs").createWriteStream(path));
      console.error(`[fuzzer] snapshot crítico en ${path}`);
    }

    // Heap snapshot periódico (cada 5 min) para análisis post-soak
    if (now - startedAt > snapshotCount * 300_000 + 60_000) {
      snapshotCount++;
      const snap = v8.getHeapSnapshot();
      const path = join(snapshotDir, `heap-${snapshotCount}.heapsnapshot`);
      writeFileSync(path, "");
      snap.pipe(require("node:fs").createWriteStream(path));
    }

    if (now >= endAt) shutdown(workers, tick, 0);
  }, 5_000);

  require("node:fs").mkdirSync(snapshotDir, { recursive: true });
}

function shutdown(workers: Worker[], tick: NodeJS.Timeout, code: number): void {
  clearInterval(tick);
  for (const w of workers) w.postMessage("stop");
  console.log(`[fuzzer] soak finalizado (code=${code})`);
  setTimeout(() => process.exit(code), 2_000);
}

if (isMainThread) {
  main().catch((e) => { console.error(e); process.exit(1); });
} else {
  parentPort?.postMessage(workerData);
}
