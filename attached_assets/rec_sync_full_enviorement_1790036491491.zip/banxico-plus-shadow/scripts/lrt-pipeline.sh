#!/usr/bin/env bash
# ==============================================================
# lrt-pipeline.sh — Long-Running Test (Soak) del Shadow Cluster
# Fases:
#   1. Compilar capa criptográfica Wasm (wasm-pack)
#   2. Construir imágenes multi-stage (Docker buildx)
#   3. Aprovisionar clúster K3s efímero (k3d) + Chaos Mesh
#   4. Desplegar manifiestos shadow y esperar readiness
#   5. Soak Phase: fuzzing mutacional continuo + monitor de pool PG
#   6. Validación de umbrales de degradación y teardown
#
# Prerequisitos en el host: rustup+cargo, wasm-pack, docker,
# k3d, kubectl, helm, node>=20, npx tsx, psql (cliente).
# ==============================================================
set -euo pipefail

# ---- Config (variables a modificar por entorno) ----
CLUSTER_NAME="${CLUSTER_NAME:-banxico-shadow-lrt}"
REGISTRY="${REGISTRY:-registry.local}"
IMAGE_TAG="${IMAGE_TAG:-shadow}"
SOAK_MINUTES="${SOAK_MINUTES:-30}"
RPS_TARGET="${RPS_TARGET:-50000}"
K3D_SERVERS="${K3D_SERVERS:-1}"
K3D_AGENTS="${K3D_AGENTS:-3}"

# Umbrales de degradación del pool (abortan el pipeline con código 2)
POOL_MAX_WAIT_S=5          # max_wait sostenido en PgBouncer SHOW POOLS
POOL_SATURATION_PCT=95     # cl_active/max_connections sostenido
DEGRADE_WINDOW_S=60        # ventana sostenida antes de declarar degradación

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ARTIFACTS="${ROOT_DIR}/lrt-artifacts/$(date -u +%Y%m%dT%H%M%SZ)"
mkdir -p "$ARTIFACTS"
log() { echo "[lrt $(date -u +%H:%M:%S)] $*" | tee -a "$ARTIFACTS/pipeline.log"; }

cleanup() {
  log "teardown: eliminando clúster efímero ${CLUSTER_NAME}"
  k3d cluster delete "$CLUSTER_NAME" >/dev/null 2>&1 || true
}
trap cleanup EXIT

# ==============================================================
# FASE 1 — Compilar Wasm
# ==============================================================
log "FASE 1: wasm-pack build (release, nodejs target)"
cd "$ROOT_DIR/crypto-core"
cargo --version >/dev/null
wasm-pack build --release --target nodejs --out-dir pkg 2>&1 | tee -a "$ARTIFACTS/wasm-pack.log"
[[ -f pkg/banxico_crypto_core_bg.wasm ]] || { log "FATAL: .wasm no generado"; exit 1; }
WASM_SIZE=$(stat -c%s pkg/banxico_crypto_core_bg.wasm)
log "wasm OK: ${WASM_SIZE} bytes"
# Presupuesto de tamaño: >2MB indica que faltó LTO/strip/wasm-opt
[[ "$WASM_SIZE" -lt 2097152 ]] || { log "FATAL: wasm excede presupuesto 2MB"; exit 1; }

# ==============================================================
# FASE 2 — Imágenes multi-stage
# ==============================================================
log "FASE 2: docker buildx (app, tron-node-mock, webhook-sink)"
cat > "$ARTIFACTS/Dockerfile.app" <<'DOCKER'
# ---------- Stage 1: deps + build ----------
FROM node:22-bookworm-slim AS build
WORKDIR /app
COPY app/package.json app/package-lock.json ./
RUN npm ci
COPY app/ ./
COPY crypto-core/pkg/ ./crypto-core/pkg/
RUN npx tsc --noEmit && npm run build

# ---------- Stage 2: runtime mínimo ----------
FROM node:22-bookworm-slim
ENV NODE_ENV=production
WORKDIR /app
RUN groupadd -r app && useradd -r -g app app
COPY --from=build --chown=app:app /app/dist ./dist
COPY --from=build --chown=app:app /app/node_modules ./node_modules
COPY --from=build --chown=app:app /app/crypto-core/pkg ./crypto-core/pkg
COPY --from=build --chown=app:app /app/server ./server
COPY --from=build --chown=app:app /app/shared ./shared
COPY --from=build --chown=app:app /app/package.json ./
USER app
EXPOSE 3000
# ENTRYPOINT fijado por los args de cada Deployment (index / workers)
ENTRYPOINT ["npx", "tsx"]
DOCKER

cat > "$ARTIFACTS/Dockerfile.tron-mock" <<'DOCKER'
FROM node:22-bookworm-slim
WORKDIR /mock
RUN npm init -y >/dev/null 2>&1
COPY shadow-mocks/tron-node-mock.js ./index.js
EXPOSE 8090 8091
CMD ["node", "index.js"]
DOCKER

cat > "$ARTIFACTS/Dockerfile.sink" <<'DOCKER'
FROM node:22-bookworm-slim
WORKDIR /sink
COPY shadow-mocks/webhook-sink.js ./index.js
EXPOSE 8080
CMD ["node", "index.js"]
DOCKER

docker buildx build -f "$ARTIFACTS/Dockerfile.app"       -t "${REGISTRY}/banxico-plus/app:${IMAGE_TAG}"          --load "$ROOT_DIR"
docker buildx build -f "$ARTIFACTS/Dockerfile.tron-mock" -t "${REGISTRY}/banxico-plus/tron-node-mock:${IMAGE_TAG}" --load "$ROOT_DIR"
docker buildx build -f "$ARTIFACTS/Dockerfile.sink"      -t "${REGISTRY}/banxico-plus/webhook-sink:${IMAGE_TAG}"  --load "$ROOT_DIR"
log "imágenes OK"

# ==============================================================
# FASE 3 — K3s efímero + Chaos Mesh
# ==============================================================
log "FASE 3: k3d cluster ${CLUSTER_NAME} (${K3D_SERVERS}s/${K3D_AGENTS}a)"
k3d cluster create "$CLUSTER_NAME" \
  --servers "$K3D_SERVERS" --agents "$K3D_AGENTS" \
  --k3s-arg "--disable=traefik@server:0" \
  --wait --timeout 120s

# Importar imágenes al runtime del clúster (registry.local es lógico)
k3d image import -c "$CLUSTER_NAME" \
  "${REGISTRY}/banxico-plus/app:${IMAGE_TAG}" \
  "${REGISTRY}/banxico-plus/tron-node-mock:${IMAGE_TAG}" \
  "${REGISTRY}/banxico-plus/webhook-sink:${IMAGE_TAG}"

log "instalando ingress-nginx"
kubectl apply -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/main/deploy/static/provider/kind/deploy.yaml
kubectl -n ingress-nginx wait --for=condition=ready pod -l app.kubernetes.io/component=controller --timeout=180s

log "instalando chaos-mesh"
helm repo add chaos-mesh https://charts.chaos-mesh.org >/dev/null 2>&1 || true
helm upgrade --install chaos-mesh chaos-mesh/chaos-mesh \
  -n chaos-mesh --create-namespace \
  --set chaosDaemon.runtime=containerd \
  --set chaosDaemon.socketPath=/run/k3s/containerd/containerd.sock \
  --set dashboard.create=false \
  --wait --timeout 300s

# ==============================================================
# FASE 4 — Despliegue shadow
# ==============================================================
log "FASE 4: aplicando manifiestos"
kubectl apply -f "$ROOT_DIR/k8s/00-namespace.yaml"
kubectl apply -f "$ROOT_DIR/k8s/01-postgres-statefulset.yaml"
kubectl -n banxico-shadow wait --for=condition=ready pod -l app=postgres --timeout=300s
kubectl apply -f "$ROOT_DIR/k8s/02-workers.yaml"
kubectl apply -f "$ROOT_DIR/k8s/03-network-policies.yaml"
kubectl -n banxico-shadow wait --for=condition=ready pod -l app=api --timeout=180s

# Esquema de DB: ledger + tablas core
PG_POD=$(kubectl -n banxico-shadow get pod -l app=postgres -o jsonpath='{.items[0].metadata.name}')
kubectl -n banxico-shadow cp "$ROOT_DIR/../banxico-plus-ledger/db/001_ledger.sql" "$PG_POD":/tmp/001.sql -c postgres
kubectl -n banxico-shadow cp "$ROOT_DIR/../banxico-plus-ledger/db/002_daily_close.sql" "$PG_POD":/tmp/002.sql -c postgres
kubectl -n banxico-shadow exec "$PG_POD" -c postgres -- psql -U banxico_app -d banxico-plus-db -v ON_ERROR_STOP=1 -f /tmp/001.sql
kubectl -n banxico-shadow exec "$PG_POD" -c postgres -- psql -U banxico_app -d banxico-plus-db -v ON_ERROR_STOP=1 -f /tmp/002.sql
log "esquema aplicado"

# Caos de red/fallos activo durante todo el soak
kubectl apply -f "$ROOT_DIR/k8s/04-chaos-mesh.yaml"
log "chaos-mesh armado (latency 50ms, loss 2%, pod-kill PG @10m, cpu-stress, time-skew)"

# ==============================================================
# FASE 5 — Soak Phase
# ==============================================================
log "FASE 5: soak ${SOAK_MINUTES}min a ${RPS_TARGET} RPS objetivo"
INGRESS_IP=$(kubectl -n ingress-nginx get svc ingress-nginx-controller -o jsonpath='{.status.loadBalancer.ingress[0].ip}' 2>/dev/null || echo "127.0.0.1")

# Monitor del pool PG en paralelo: SHOW POOLS cada 10s vía psql a PgBouncer admin
(
  degrade_since=0
  while true; do
    read -r cl_active max_conn max_wait <<<"$(kubectl -n banxico-shadow exec "$PG_POD" -c pgbouncer -- \
      sh -c "psql -h 127.0.0.1 -p 6432 -U pgbouncer pgbouncer -tAc \"SHOW POOLS\"" 2>/dev/null \
      | awk -F'|' '{s+=$4; w=(w<$8?$8:w)} END {m=25; print s+0, m, w+0}' || echo "0 25 0")"
    sat=$(( max_conn > 0 ? cl_active * 100 / max_conn : 0 ))
    echo "$(date -u +%s) cl_active=$cl_active sat=${sat}% max_wait=${max_wait}s" >> "$ARTIFACTS/pool-monitor.log"
    if [[ "$max_wait" -gt "$POOL_MAX_WAIT_S" || "$sat" -gt "$POOL_SATURATION_PCT" ]]; then
      now=$(date +%s)
      [[ "$degrade_since" -eq 0 ]] && degrade_since=$now
      if (( now - degrade_since > DEGRADE_WINDOW_S )); then
        echo "DEGRADED max_wait=${max_wait}s sat=${sat}%" > "$ARTIFACTS/POOL_DEGRADED"
        break
      fi
    else
      degrade_since=0
    fi
    sleep 10
  done
) &
POOL_MONITOR_PID=$!

# Arnés de fuzzing (proceso principal del soak)
set +e
TARGET="http://${INGRESS_IP}" \
RPS_TARGET="$RPS_TARGET" \
DURATION_MIN="$SOAK_MINUTES" \
STRIPE_WEBHOOK_SECRET="whsec_shadow" \
npx tsx "$ROOT_DIR/fuzzer/genetic-harness.ts" 2>&1 | tee "$ARTIFACTS/fuzzer.log"
FUZZ_RC=${PIPESTATUS[0]}
set -e

kill "$POOL_MONITOR_PID" 2>/dev/null || true

# ==============================================================
# FASE 6 — Validación de umbrales y evidencia
# ==============================================================
log "FASE 6: validación de umbrales"
RC=0

if [[ -f "$ARTIFACTS/POOL_DEGRADED" ]]; then
  log "FALLO: pool de Postgres degradado — $(cat "$ARTIFACTS/POOL_DEGRADED")"
  RC=2
fi
if [[ "$FUZZ_RC" -ne 0 ]]; then
  log "FALLO: fuzzer abortó con código ${FUZZ_RC} (umbral p99 o heap)"
  RC=2
fi

# Evidencia: logs de pods + métricas + estado final de chaos
kubectl -n banxico-shadow get pods -o wide > "$ARTIFACTS/pods-final.txt"
kubectl -n banxico-shadow logs -l app=api --tail=500 --prefix > "$ARTIFACTS/api-logs.txt" 2>/dev/null || true
kubectl -n banxico-shadow logs -l app=outbound-dispatcher --tail=200 --prefix > "$ARTIFACTS/dispatcher-logs.txt" 2>/dev/null || true
kubectl -n banxico-shadow get networkchaos,podchaos,stresschaos,timechaos > "$ARTIFACTS/chaos-status.txt" 2>/dev/null || true

# 5xx finales del log del fuzzer
FINAL_5XX=$(grep -oE '5xx=[0-9]+' "$ARTIFACTS/fuzzer.log" | tail -1 | cut -d= -f2 || echo "0")
FINAL_POOL=$(grep -oE 'pool=[0-9]+' "$ARTIFACTS/fuzzer.log" | tail -1 | cut -d= -f2 || echo "0")
log "resumen: 5xx_total=${FINAL_5XX} pool_breaks=${FINAL_POOL} fuzz_rc=${FUZZ_RC}"

if [[ "$RC" -eq 0 ]]; then
  log "SOAK PASSED — umbrales de degradación respetados en ${SOAK_MINUTES}min"
else
  log "SOAK FAILED — revisar ${ARTIFACTS}"
fi
log "artefactos: $ARTIFACTS"
exit "$RC"
