//! banxico-crypto-core — firmas secp256k1 (TRON) y HMAC-SHA256 (webhooks).
//!
//! Modelo de memoria lineal Wasm (prevención de fugas):
//!  - Entradas: `&[u8]` — el glue de wasm-bindgen las copia UNA vez a la
//!    memoria lineal y libera al retornar (pass-by-pointer + memcpy).
//!  - Salidas: `js_sys::Uint8Array` — se materializa una única copia hacia
//!    JS; el buffer intermedio de Rust se libera en el mismo frame.
//!  - Secretos: `zeroize` garantiza que la llave privada no quede residente
//!    en la memoria lineal tras la firma (drop con sobreescritura).
//!  - Sin `Box::leak`, sin buffers estáticos mutables, sin `Rc`/`RefCell`:
//!    cada llamada es un ciclo alloc→use→drop cerrado.

use wasm_bindgen::prelude::*;
use js_sys::Uint8Array;
use secp256k1::{ecdsa::RecoverableSignature, Message, Secp256k1, SecretKey};
use sha2::{Digest, Sha256};
use hmac::{Hmac, Mac};
use zeroize::Zeroize;

type HmacSha256 = Hmac<Sha256>;

/// Contexto secp256k1 por llamada. `Secp256k1::new()` es costoso (~µs) pero
/// determinista y thread-safe; para volumen extremo el bridge mantiene el
/// módulo caliente y este costo se amortiza bajo opt-level 3.
#[inline]
fn context() -> Secp256k1<secp256k1::All> {
    Secp256k1::new()
}

/// Firma una transacción TRON: ECDSA recoverable sobre el digest SHA-256
/// del raw_data (32 bytes). Devuelve 65 bytes: r(32) || s(32) || v(1),
/// con v ∈ {27, 28} (convención TRON/Ethereum pre-EIP-155).
///
/// Latencia objetivo: < 200 µs en wasm32 release con LTO.
#[wasm_bindgen]
pub fn sign_tron_tx(tx_hash: &[u8], private_key: &[u8]) -> Result<Uint8Array, JsError> {
    if tx_hash.len() != 32 {
        return Err(JsError::new("tx_hash debe ser 32 bytes (SHA-256 del raw_data)"));
    }
    if private_key.len() != 32 {
        return Err(JsError::new("private_key debe ser 32 bytes"));
    }

    // Copia zeroizable del secreto: la memoria lineal queda limpia al salir
    let mut sk_buf = [0u8; 32];
    sk_buf.copy_from_slice(private_key);

    let result = (|| {
        let sk = SecretKey::from_slice(&sk_buf)
            .map_err(|_| JsError::new("llave fuera del campo secp256k1"))?;
        let msg = Message::from_slice(tx_hash)
            .map_err(|_| JsError::new("digest inválido"))?;

        let sig: RecoverableSignature = context().sign_ecdsa_recoverable(&msg, &sk);
        let (rec_id, rs) = sig.serialize_compact();

        let mut out = [0u8; 65];
        out[..64].copy_from_slice(&rs);
        out[64] = rec_id.to_i32() as u8 + 27; // v = 27 | 28
        Ok(out)
    })();

    sk_buf.zeroize(); // sobreescritura garantizada incluso en early-return
    let sig_bytes = result?;
    Ok(Uint8Array::from(&sig_bytes[..]))
}

/// Deriva la dirección TRON pública (sin comprimir, prefijo 0x41) a partir
/// de la llave privada — útil para validación del signer en arranque.
#[wasm_bindgen]
pub fn tron_pubkey_uncompressed(private_key: &[u8]) -> Result<Uint8Array, JsError> {
    if private_key.len() != 32 {
        return Err(JsError::new("private_key debe ser 32 bytes"));
    }
    let mut sk_buf = [0u8; 32];
    sk_buf.copy_from_slice(private_key);
    let result = (|| {
        let sk = SecretKey::from_slice(&sk_buf)
            .map_err(|_| JsError::new("llave fuera del campo secp256k1"))?;
        let pk = secp256k1::PublicKey::from_secret_key(&context(), &sk);
        Ok::<[u8; 65], JsError>(pk.serialize_uncompressed())
    })();
    sk_buf.zeroize();
    Ok(Uint8Array::from(&result?[..]))
}

/// HMAC-SHA256 crudo: key || msg → 32 bytes. Núcleo de verificación de
/// webhooks (Stripe `t={ts},v1={sig}`) y de firma saliente (INF-18).
#[wasm_bindgen]
pub fn hmac_sha256(key: &[u8], msg: &[u8]) -> Result<Uint8Array, JsError> {
    let mut mac = <HmacSha256 as Mac>::new_from_slice(key)
        .map_err(|_| JsError::new("key HMAC inválida"))?;
    mac.update(msg);
    let out = mac.finalize().into_bytes();
    Ok(Uint8Array::from(&out[..]))
}

/// SHA-256 simple — el poller lo usa para derivar txHash de raw_data TRON.
#[wasm_bindgen]
pub fn sha256(data: &[u8]) -> Uint8Array {
    let out = Sha256::digest(data);
    Uint8Array::from(&out[..])
}

/// Comparación en tiempo constante (anti-timing-attack). Sin early-exit:
/// el bucle recorre siempre los 32 bytes; la longitud se pliega al acumulador.
#[wasm_bindgen]
pub fn ct_eq(a: &[u8], b: &[u8]) -> bool {
    let mut acc = (a.len() ^ b.len()) as u8;
    let n = a.len().min(b.len());
    for i in 0..n {
        acc |= a[i] ^ b[i];
    }
    acc == 0
}

/// Verificación completa de webhook Stripe en una sola llamada a Wasm
/// (evita 3 cruces del boundary JS↔Wasm: concat + hmac + compare):
///   signed_payload = "{timestamp}.{payload}"
///   esperado = HMAC_SHA256(secret, signed_payload) == signature_hex
#[wasm_bindgen]
pub fn verify_stripe_signature(
    secret: &[u8],
    timestamp: &str,
    payload: &[u8],
    signature_hex: &str,
) -> Result<bool, JsError> {
    if signature_hex.len() != 64 {
        return Ok(false); // hex de 32 bytes — formato inválido, no secreto
    }
    let mut expected = [0u8; 32];
    for (i, chunk) in signature_hex.as_bytes().chunks_exact(2).enumerate() {
        let hi = hex_val(chunk[0]).ok_or_else(|| JsError::new("hex inválido"))?;
        let lo = hex_val(chunk[1]).ok_or_else(|| JsError::new("hex inválido"))?;
        expected[i] = (hi << 4) | lo;
    }

    let mut mac = <HmacSha256 as Mac>::new_from_slice(secret)
        .map_err(|_| JsError::new("key HMAC inválida"))?;
    mac.update(timestamp.as_bytes());
    mac.update(b".");
    mac.update(payload);
    let computed = mac.finalize().into_bytes();

    let mut acc = 0u8;
    for i in 0..32 {
        acc |= computed[i] ^ expected[i];
    }
    Ok(acc == 0)
}

#[inline]
fn hex_val(c: u8) -> Option<u8> {
    match c {
        b'0'..=b'9' => Some(c - b'0'),
        b'a'..=b'f' => Some(c - b'a' + 10),
        b'A'..=b'F' => Some(c - b'A' + 10),
        _ => None,
    }
}

/// Firma saliente HMAC-SHA256 en una sola llamada (outbound-dispatcher):
/// devuelve hex lowercase de HMAC(secret, "{ts}.{body}").
#[wasm_bindgen]
pub fn sign_outbound(secret: &[u8], timestamp: &str, body: &[u8]) -> Result<String, JsError> {
    let mut mac = <HmacSha256 as Mac>::new_from_slice(secret)
        .map_err(|_| JsError::new("key HMAC inválida"))?;
    mac.update(timestamp.as_bytes());
    mac.update(b".");
    mac.update(body);
    let out = mac.finalize().into_bytes();

    const HEX: &[u8; 16] = b"0123456789abcdef";
    let mut s = String::with_capacity(64);
    for b in out.iter() {
        s.push(HEX[(b >> 4) as usize] as char);
        s.push(HEX[(b & 0x0f) as usize] as char);
    }
    Ok(s)
}
