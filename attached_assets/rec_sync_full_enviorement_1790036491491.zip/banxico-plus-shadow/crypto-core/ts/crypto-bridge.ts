// ==============================================================
// crypto-bridge.ts — puente Node.js ↔ Wasm (banxico-crypto-core)
// Sustituye node:crypto en rutas calientes: firma TRON y HMAC de
// webhooks. El módulo Wasm se inicializa UNA vez (singleton) y se
// mantiene caliente; los buffers JS se pasan como vistas Uint8Array
// sin copias intermedias en JS (zero-copy hacia la memoria lineal).
// ==============================================================
import { readFileSync } from "node:fs";
import { join } from "node:path";

// Tipos del glue generado por wasm-bindgen (pkg/banxico_crypto_core.d.ts)
interface CryptoWasm {
  sign_tron_tx(tx_hash: Uint8Array, private_key: Uint8Array): Uint8Array;
  tron_pubkey_uncompressed(private_key: Uint8Array): Uint8Array;
  hmac_sha256(key: Uint8Array, msg: Uint8Array): Uint8Array;
  sha256(data: Uint8Array): Uint8Array;
  ct_eq(a: Uint8Array, b: Uint8Array): boolean;
  verify_stripe_signature(secret: Uint8Array, timestamp: string, payload: Uint8Array, signature_hex: string): boolean;
  sign_outbound(secret: Uint8Array, timestamp: string, body: Uint8Array): string;
}

let wasm: CryptoWasm | null = null;
let initPromise: Promise<void> | null = null;

// Carga perezosa con promesa compartida: concurrencia segura en arranque.
// En producción el glue se genera con `wasm-pack build --target nodejs`.
export async function initCrypto(pkgDir = join(__dirname, "../pkg")): Promise<void> {
  if (wasm) return;
  if (!initPromise) {
    initPromise = (async () => {
      // target nodejs: el glue expone init con el path del .wasm
      const glue = require(join(pkgDir, "banxico_crypto_core.js"));
      const wasmPath = join(pkgDir, "banxico_crypto_core_bg.wasm");
      await glue.default(readFileSync(wasmPath));
      wasm = glue as CryptoWasm;
    })();
  }
  await initPromise;
}

function core(): CryptoWasm {
  if (!wasm) throw new Error("crypto-core no inicializado — llamar initCrypto() en arranque (fail-fast)");
  return wasm;
}

// Buffer → vista Uint8Array SIN copia (misma memoria subyacente)
function view(b: Buffer | Uint8Array): Uint8Array {
  return b instanceof Uint8Array && !(b instanceof Buffer)
    ? b
    : new Uint8Array(b.buffer, b.byteOffset, b.byteLength);
}

// ---- API de producción ----

/** Firma TRON: 65 bytes r||s||v (v∈{27,28}). < 200µs bajo release. */
export function signTronTx(txHash: Buffer, privateKey: Buffer): Buffer {
  const out = core().sign_tron_tx(view(txHash), view(privateKey));
  return Buffer.from(out.buffer, out.byteOffset, out.byteLength); // 1 copia Wasm→JS, inmediata
}

/** Pubkey sin comprimir (0x04 || X || Y) para validación del signer. */
export function tronPubkeyUncompressed(privateKey: Buffer): Buffer {
  const out = core().tron_pubkey_uncompressed(view(privateKey));
  return Buffer.from(out.buffer, out.byteOffset, out.byteLength);
}

/** HMAC-SHA256 crudo (32 bytes). */
export function hmacSha256(key: Buffer | string, msg: Buffer | string): Buffer {
  const k = typeof key === "string" ? Buffer.from(key, "utf8") : key;
  const m = typeof msg === "string" ? Buffer.from(msg, "utf8") : msg;
  const out = core().hmac_sha256(view(k), view(m));
  return Buffer.from(out.buffer, out.byteOffset, out.byteLength);
}

/** SHA-256 (derivación de txHash desde raw_data TRON). */
export function sha256(data: Buffer): Buffer {
  const out = core().sha256(view(data));
  return Buffer.from(out.buffer, out.byteOffset, out.byteLength);
}

/**
 * Verificación Stripe en UN cruce de boundary (ts.concat+hmac+ct_eq dentro de Wasm).
 * `signatureHeader` = "t=1699999999,v1=<hex64>[,v0=...]"
 */
export function verifyStripeWebhook(secret: string, payloadRaw: Buffer, signatureHeader: string): boolean {
  const ts = /(?:^|,)t=(\d+)/.exec(signatureHeader)?.[1];
  const v1 = /(?:^|,)v1=([0-9a-fA-F]{64})/.exec(signatureHeader)?.[1];
  if (!ts || !v1) return false;

  // Anti-replay: ventana de 5 minutos (alineada con tolerancia Stripe)
  const ageSec = Math.abs(Math.floor(Date.now() / 1000) - Number(ts));
  if (ageSec > 300) return false;

  return core().verify_stripe_signature(Buffer.from(secret, "utf8"), ts, view(payloadRaw), v1);
}

/** Firma saliente (outbound-dispatcher, INF-18): hex de HMAC(secret, "ts.body"). */
export function signOutboundPayload(secret: string, timestamp: string, body: Buffer | string): string {
  const b = typeof body === "string" ? Buffer.from(body, "utf8") : body;
  return core().sign_outbound(Buffer.from(secret, "utf8"), timestamp, view(b));
}

/** Comparación tiempo constante genérica. */
export function constantTimeEqual(a: Buffer, b: Buffer): boolean {
  return core().ct_eq(view(a), view(b));
}

// ---- Self-test de arranque (fail-fast, INF-19 style) ----
// Vector conocido: HMAC("key", "The quick brown fox jumps over the lazy dog")
const HMAC_KAT = "f7bc83f430538424b13298e6aa6fb143ef4d59a14946175997479dbc2d1a3cd8";

export async function cryptoSelfTest(): Promise<void> {
  await initCrypto();
  const got = hmacSha256("key", "The quick brown fox jumps over the lazy dog").toString("hex");
  if (got !== HMAC_KAT) {
    console.error(`FATAL: crypto-core KAT falló (got=${got}) — abortando arranque`);
    process.exit(1);
  }
  console.log("[crypto-bridge] Wasm OK — KAT HMAC-SHA256 verificado");
}
