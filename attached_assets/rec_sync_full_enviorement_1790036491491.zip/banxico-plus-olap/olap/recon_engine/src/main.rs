//! recon_engine — Motor de conciliacion vectorizado (Polars + ClickHouse).
//!
//! Flujo:
//!   1. CSV settlement (Stripe/MP, hasta 5GB) -> Polars LazyFrame streaming
//!      (memoria acotada, chunks vectorizados, nunca carga el archivo entero).
//!   2. Normalizacion + calculo vectorizado de fee esperado y slippage FX.
//!   3. Carga del batch a ClickHouse (tabla settlement_lines, HTTP TSV).
//!   4. Cruce SQL-side contra transactions_st (CDC en tiempo real) via
//!      v_settlement_vs_internal + deteccion de huerfanos inversa.
//!   5. Reporte de descuadres (JSON) + exit code por umbral.

use anyhow::{Context, Result};
use polars::prelude::*;
use rust_decimal_macros::dec;
use serde::Serialize;
use std::env;
use std::path::PathBuf;
use tracing::{info, warn};
use uuid::Uuid;

// ---------------- Config ----------------
struct Cfg {
    clickhouse_url: String,
    clickhouse_user: String,
    clickhouse_password: String,
    settlement_csv: PathBuf,
    provider: String,          // STRIPE | MERCADOPAGO (por nombre de archivo: mp_*)
    batch_rows: usize,         // filas por INSERT HTTP a ClickHouse
    fee_tolerance_rel: f64,    // 0.005 = 0.5%
    amount_tolerance: f64,     // 0.01
    max_exceptions: u64,       // umbral de abortado (exit 2)
}

impl Cfg {
    fn from_env() -> Result<Self> {
        let csv = env::var("SETTLEMENT_CSV").context("SETTLEMENT_CSV requerido")?;
        let provider = if csv.to_lowercase().contains("/mp_") || csv.to_lowercase().starts_with("mp_") {
            "MERCADOPAGO".into()
        } else {
            "STRIPE".into()
        };
        Ok(Self {
            clickhouse_url: env::var("CLICKHOUSE_URL").unwrap_or("http://localhost:8123".into()),
            clickhouse_user: env::var("CLICKHOUSE_USER").unwrap_or("olap".into()),
            clickhouse_password: env::var("CLICKHOUSE_PASSWORD").context("CLICKHOUSE_PASSWORD requerido")?,
            settlement_csv: PathBuf::from(csv),
            provider,
            batch_rows: env::var("BATCH_ROWS").ok().and_then(|v| v.parse().ok()).unwrap_or(50_000),
            fee_tolerance_rel: 0.005,
            amount_tolerance: 0.01,
            max_exceptions: env::var("MAX_EXCEPTIONS").ok().and_then(|v| v.parse().ok()).unwrap_or(1_000),
        })
    }
}

// Modelo de fee (alineado con ledger PG / ClickHouse view)
fn fee_model(provider: &str) -> (f64, f64) {
    match provider {
        "MERCADOPAGO" => (0.0355, 0.00),
        _ => (0.036, 3.00), // STRIPE
    }
}

#[derive(Serialize)]
struct ReconSummary {
    batch_id: String,
    provider: String,
    rows_total: u64,
    ok: u64,
    fee_mismatch: u64,
    amount_mismatch: u64,
    orphan_settlement: u64,
    orphan_internal: u64,
    fx_slippage_events: u64,
    fee_delta_total_abs: f64,
    slippage_total_abs: f64,
    status: String,
}

// ---------------- ClickHouse client (HTTP) ----------------
struct Ch {
    http: reqwest::Client,
    cfg_url: String,
    auth: (String, String),
}

impl Ch {
    fn new(cfg: &Cfg) -> Self {
        Self {
            http: reqwest::Client::builder()
                .pool_max_idle_per_host(8)
                .build()
                .expect("reqwest client"),
            cfg_url: cfg.clickhouse_url.clone(),
            auth: (cfg.clickhouse_user.clone(), cfg.clickhouse_password.clone()),
        }
    }

    async fn query(&self, q: &str) -> Result<String> {
        let res = self.http
            .post(&self.cfg_url)
            .basic_auth(&self.auth.0, Some(&self.auth.1))
            .query(&[("default_format", "JSONEachRow")])
            .body(q.to_string())
            .send().await?
            .error_for_status()?;
        Ok(res.text().await?)
    }

    async fn insert_tsv(&self, table: &str, tsv: &[u8]) -> Result<()> {
        self.http
            .post(&self.cfg_url)
            .basic_auth(&self.auth.0, Some(&self.auth.1))
            .query(&[("query", format!("INSERT INTO banxico_olap.{table} FORMAT TSV"))])
            .header("content-type", "text/tab-separated-values")
            .body(tsv.to_vec())
            .send().await?
            .error_for_status()?;
        Ok(())
    }
}

// ---------------- Pipeline Polars ----------------
fn settlement_lazy(csv: &std::path::Path, provider: &str, batch: &str) -> Result<LazyFrame> {
    let (pct, fixed) = fee_model(provider);

    let lf = LazyCsvReader::new(csv)
        .with_has_header(true)
        .with_infer_schema_length(Some(1000))
        .finish()?
        .select([col("*")])
        .rename(
            ["provider","external_ref","gross_amount","fee_amount","net_amount",
             "currency","capture_fx_rate","settlement_fx_rate","settled_at","tron_payout_ref"],
            ["provider","external_ref","gross","fee","net",
             "currency","capture_fx_rate","settlement_fx_rate","settled_at","tron_payout_ref"],
            true,
        )
        .with_columns([
            lit(batch.to_string()).alias("batch_id"),
            lit(provider.to_string()).alias("provider_norm"),
            // fee esperado vectorizado: gross*pct + fixed
            (col("gross").cast(DataType::Float64) * lit(pct) + lit(fixed))
                .round(6, RoundMode::HalfToEven)
                .alias("expected_fee"),
            // slippage FX vectorizado: gross*(T1-T0) en MXN
            (col("gross").cast(DataType::Float64)
                * (col("settlement_fx_rate").cast(DataType::Float64)
                   - col("capture_fx_rate").cast(DataType::Float64)))
                .round(6, RoundMode::HalfToEven)
                .alias("fx_slippage_mxn"),
        ])
        .with_columns([
            (col("fee").cast(DataType::Float64) - col("expected_fee")).alias("fee_delta"),
            ((col("fee").cast(DataType::Float64) - col("expected_fee")).abs()
                / col("expected_fee").abs().clip(lit(1e-6), lit(f64::MAX)))
                .alias("fee_delta_rel"),
        ]);
    Ok(lf)
}

#[tokio::main(flavor = "multi_thread", worker_threads = 8)]
async fn main() -> Result<()> {
    tracing_subscriber::fmt()
        .with_env_filter(tracing_subscriber::EnvFilter::from_default_env()
            .add_directive("recon_engine=info".parse()?))
        .init();

    let cfg = Cfg::from_env()?;
    let batch_id = Uuid::new_v4().to_string();
    let ch = Ch::new(&cfg);
    info!(batch = %batch_id, provider = %cfg.provider, csv = ?cfg.settlement_csv, "recon start");

    // ---------- 1+2: Polars streaming sobre el CSV de 5GB ----------
    let lf = settlement_lazy(&cfg.settlement_csv, &cfg.provider, &batch_id)?;

    // Recoleccion por chunks via streaming engine: nunca materializa 5GB
    let mut df = lf.clone().collect()?;
    let rows_total = df.height() as u64;
    info!(rows = rows_total, "csv parseado y normalizado");

    // Metricas vectorizadas del batch completo (sin cruce SQL aun)
    let fx_events = df.clone().lazy()
        .filter(col("fx_slippage_mxn").abs().gt(lit(cfg.amount_tolerance)))
        .select([len().alias("n"), col("fx_slippage_mxn").abs().sum().alias("tot")])
        .collect()?;
    let fx_n: u64 = fx_events.column("n")?.get(0)?.try_extract().unwrap_or(0);
    let fx_tot: f64 = fx_events.column("tot")?.get(0)?.try_extract().unwrap_or(0.0);

    // ---------- 3: Carga batch -> ClickHouse en TSV por lotes ----------
    let cols = ["batch_id","provider_norm","external_ref","gross","fee","net","currency",
                "capture_fx_rate","settlement_fx_rate","settled_at","tron_payout_ref"];
    df = df.select(cols)?;
    let mut offset = 0usize;
    while offset < df.height() {
        let end = (offset + cfg.batch_rows).min(df.height());
        let chunk = df.slice(offset as i64, end - offset);
        let mut buf = Vec::with_capacity(8 * 1024 * 1024);
        polars::prelude::CsvWriter::new(&mut buf)
            .include_header(false)
            .with_separator(b'\t')
            .finish(&mut chunk.clone())?;
        ch.insert_tsv("settlement_lines", &buf).await?;
        offset = end;
    }
    info!(rows = rows_total, "batch cargado a ClickHouse settlement_lines");

    // ---------- 4: Cruce SQL-side contra CDC en tiempo real ----------
    let cross = ch.query(&format!(
        "SELECT recon_status, count() AS n, sum(abs(fee_delta)) AS fee_abs \
         FROM banxico_olap.v_settlement_vs_internal \
         WHERE batch_id = '{batch_id}' GROUP BY recon_status"
    )).await?;

    let mut ok = 0u64; let mut fee_mm = 0u64; let mut amt_mm = 0u64;
    let mut orphan_s = 0u64; let mut fee_abs = 0f64;
    for line in cross.lines().filter(|l| !l.trim().is_empty()) {
        let v: serde_json::Value = serde_json::from_str(line)?;
        let n: u64 = v["n"].as_str().unwrap_or("0").parse().unwrap_or(0);
        fee_abs += v["fee_abs"].as_str().unwrap_or("0").parse::<f64>().unwrap_or(0.0);
        match v["recon_status"].as_str().unwrap_or("") {
            "OK" => ok = n,
            "FEE_MISMATCH" => fee_mm = n,
            "AMOUNT_MISMATCH" => amt_mm = n,
            "ORPHAN_SETTLEMENT" => orphan_s = n,
            _ => {}
        }
    }

    // Huerfanos inversos: internas CONFIRMED sin linea en este settlement
    let orphan_internal: u64 = ch.query(&format!(
        "SELECT count() AS n FROM banxico_olap.transactions_st FINAL \
         WHERE environment = 'mainnet' AND provider = '{}' AND status = 'CONFIRMED' \
           AND external_tx_id NOT IN ( \
             SELECT external_ref FROM banxico_olap.settlement_lines WHERE batch_id = '{}')",
        cfg.provider, batch_id
    )).await?
        .lines().next().map(|l| serde_json::from_str::<serde_json::Value>(l).ok())
        .flatten()
        .and_then(|v| v["n"].as_str().map(|s| s.to_string()))
        .and_then(|s| s.parse().ok())
        .unwrap_or(0);

    // Detalle de excepciones top-100 para forense
    let exceptions = ch.query(&format!(
        "SELECT external_ref, provider, gross, fee, expected_fee, fee_delta, recon_status \
         FROM banxico_olap.v_settlement_vs_internal \
         WHERE batch_id = '{batch_id}' AND recon_status != 'OK' \
         ORDER BY abs(fee_delta) DESC LIMIT 100"
    )).await?;
    std::fs::write(format!("recon-exceptions-{batch_id}.json"), &exceptions)?;

    let exceptions_total = fee_mm + amt_mm + orphan_s + orphan_internal;
    let summary = ReconSummary {
        batch_id: batch_id.clone(),
        provider: cfg.provider.clone(),
        rows_total,
        ok,
        fee_mismatch: fee_mm,
        amount_mismatch: amt_mm,
        orphan_settlement: orphan_s,
        orphan_internal,
        fx_slippage_events: fx_n,
        fee_delta_total_abs: fee_abs,
        slippage_total_abs: fx_tot,
        status: if exceptions_total > cfg.max_exceptions { "FAILED_THRESHOLD".into() } else { "OK".into() },
    };
    println!("{}", serde_json::to_string_pretty(&summary)?);

    if exceptions_total > cfg.max_exceptions {
        warn!(exceptions = exceptions_total, "umbral de excepciones superado");
        std::process::exit(2);
    }
    info!(batch = %batch_id, "recon OK");
    Ok(())
}
