-- ==============================================================
-- ClickHouse — Ledger OLAP de doble partida en tiempo real
-- Ingesta CDC Debezium (topicos cdc.*) via motor Kafka,
-- Materialized Views -> SummingMergeTree con saldos por cuenta.
-- ClickHouse no soporta transacciones: la ecuacion contable se
-- valida analiticamente (v_daily_close), no por constraint.
-- ==============================================================

CREATE DATABASE IF NOT EXISTS banxico_olap;
USE banxico_olap;

-- --------------------------------------------------------------
-- 1. Capa RAW: motor Kafka (una tabla por topico CDC)
-- Envelope Debezium JSON plano: {before, after, source, op, ts_ms}
-- op: c=create, u=update, d=delete, r=read (snapshot)
-- --------------------------------------------------------------

CREATE TABLE IF NOT EXISTS cdc_journal_raw
(
    payload String
)
ENGINE = Kafka
SETTINGS
    kafka_broker_list = 'redpanda:9092',
    kafka_topic_list = 'cdc.ledger.journal_entries',
    kafka_group_name = 'ch_journal',
    kafka_format = 'JSONAsString',
    kafka_num_consumers = 2,
    kafka_handle_error_mode = 'stream';

CREATE TABLE IF NOT EXISTS cdc_entry_lines_raw
(
    payload String
)
ENGINE = Kafka
SETTINGS
    kafka_broker_list = 'redpanda:9092',
    kafka_topic_list = 'cdc.ledger.entry_lines',
    kafka_group_name = 'ch_lines',
    kafka_format = 'JSONAsString',
    kafka_num_consumers = 4,
    kafka_handle_error_mode = 'stream';

CREATE TABLE IF NOT EXISTS cdc_transactions_raw
(
    payload String
)
ENGINE = Kafka
SETTINGS
    kafka_broker_list = 'redpanda:9092',
    kafka_topic_list = 'cdc.public.transactions',
    kafka_group_name = 'ch_tx',
    kafka_format = 'JSONAsString',
    kafka_num_consumers = 2,
    kafka_handle_error_mode = 'stream';

-- --------------------------------------------------------------
-- 2. Capa STAGING: tablas destino de los MVs de ingesta
-- Parseo del envelope Debezium -> columnas tipadas
-- --------------------------------------------------------------

CREATE TABLE IF NOT EXISTS journal_entries_st
(
    entry_id      UUID,
    source        LowCardinality(String),
    external_ref  String,
    description   String,
    booked_at     DateTime64(3, 'UTC'),
    recon_batch   Nullable(UUID),
    op            LowCardinality(String),
    cdc_ts        DateTime64(3, 'UTC')
)
ENGINE = MergeTree
ORDER BY (booked_at, entry_id)
PARTITION BY toYYYYMM(booked_at);

CREATE TABLE IF NOT EXISTS entry_lines_st
(
    line_id       UInt64,
    entry_id      UUID,
    account_code  LowCardinality(String),
    debit         Decimal(20, 6),
    credit        Decimal(20, 6),
    op            LowCardinality(String),
    cdc_ts        DateTime64(3, 'UTC')
)
ENGINE = MergeTree
ORDER BY (account_code, entry_id, line_id)
PARTITION BY toYYYYMM(cdc_ts);

CREATE TABLE IF NOT EXISTS transactions_st
(
    tx_id          UUID,
    provider       LowCardinality(String),
    external_tx_id String,
    amount         Decimal(20, 6),
    currency       LowCardinality(String),
    status         LowCardinality(String),
    environment    LowCardinality(String),
    op             LowCardinality(String),
    cdc_ts         DateTime64(3, 'UTC')
)
ENGINE = ReplacingMergeTree(cdc_ts)   -- updates CDC: ultima version gana por external_tx_id
ORDER BY (environment, external_tx_id)
PARTITION BY toYYYYMM(cdc_ts);

-- --------------------------------------------------------------
-- 3. MVs de ingesta: Kafka -> staging (parseo del envelope)
-- after=NULL en deletes; se toma before para d, after para c/u/r
-- --------------------------------------------------------------

CREATE MATERIALIZED VIEW IF NOT EXISTS mv_journal_ingest TO journal_entries_st AS
SELECT
    toUUID(JSONExtractString(payload, 'after', 'id'))                              AS entry_id,
    JSONExtractString(payload, 'after', 'source')                                  AS source,
    JSONExtractString(payload, 'after', 'external_ref')                            AS external_ref,
    JSONExtractString(payload, 'after', 'description')                             AS description,
    toDateTime64(JSONExtractString(payload, 'after', 'booked_at'), 3, 'UTC')       AS booked_at,
    if(JSONExtractString(payload, 'after', 'recon_batch') = '',
       NULL, toUUID(JSONExtractString(payload, 'after', 'recon_batch')))           AS recon_batch,
    JSONExtractString(payload, 'op')                                               AS op,
    toDateTime64(JSONExtractUInt(payload, 'ts_ms') / 1000, 3, 'UTC')               AS cdc_ts
FROM cdc_journal_raw
WHERE JSONExtractString(payload, 'op') IN ('c', 'u', 'r')
  AND JSONExtractString(payload, 'after', 'id') != '';

CREATE MATERIALIZED VIEW IF NOT EXISTS mv_lines_ingest TO entry_lines_st AS
SELECT
    JSONExtractUInt(payload, 'after', 'id')                                        AS line_id,
    toUUID(JSONExtractString(payload, 'after', 'entry_id'))                        AS entry_id,
    JSONExtractString(payload, 'after', 'account_code')                            AS account_code,
    toDecimal64(JSONExtractString(payload, 'after', 'debit'), 6)                   AS debit,
    toDecimal64(JSONExtractString(payload, 'after', 'credit'), 6)                  AS credit,
    JSONExtractString(payload, 'op')                                               AS op,
    toDateTime64(JSONExtractUInt(payload, 'ts_ms') / 1000, 3, 'UTC')               AS cdc_ts
FROM cdc_entry_lines_raw
WHERE JSONExtractString(payload, 'op') IN ('c', 'u', 'r')
  AND JSONExtractString(payload, 'after', 'entry_id') != '';

CREATE MATERIALIZED VIEW IF NOT EXISTS mv_tx_ingest TO transactions_st AS
SELECT
    toUUID(JSONExtractString(payload, 'after', 'id'))                              AS tx_id,
    JSONExtractString(payload, 'after', 'provider')                                AS provider,
    JSONExtractString(payload, 'after', 'external_tx_id')                          AS external_tx_id,
    toDecimal64(JSONExtractString(payload, 'after', 'amount'), 6)                  AS amount,
    JSONExtractString(payload, 'after', 'currency')                                AS currency,
    JSONExtractString(payload, 'after', 'status')                                  AS status,
    JSONExtractString(payload, 'after', 'environment')                             AS environment,
    JSONExtractString(payload, 'op')                                               AS op,
    toDateTime64(JSONExtractUInt(payload, 'ts_ms') / 1000, 3, 'UTC')               AS cdc_ts
FROM cdc_transactions_raw
WHERE JSONExtractString(payload, 'op') IN ('c', 'u', 'r')
  AND JSONExtractString(payload, 'after', 'external_tx_id') != '';

-- --------------------------------------------------------------
-- 4. LEDGER SUMADO: SummingMergeTree de movimientos por cuenta
-- signed_amount: debit=+1, credit=-1 (convencion ASSET-normal)
-- --------------------------------------------------------------

CREATE TABLE IF NOT EXISTS ledger_movements
(
    day           Date,
    account_code  LowCardinality(String),
    currency      LowCardinality(String),
    debits        Decimal(20, 6),
    credits       Decimal(20, 6)
)
ENGINE = SummingMergeTree
PARTITION BY toYYYYMM(day)
ORDER BY (day, account_code, currency);

CREATE MATERIALIZED VIEW IF NOT EXISTS mv_ledger_movements TO ledger_movements AS
SELECT
    toDate(je.booked_at)  AS day,
    el.account_code       AS account_code,
    acc.currency          AS currency,
    el.debit              AS debits,
    el.credit             AS credits
FROM entry_lines_st AS el
INNER JOIN journal_entries_st AS je ON je.entry_id = el.entry_id
INNER JOIN
(
    SELECT 'stripe_clearing' AS code, 'MXN' AS currency UNION ALL
    SELECT 'mp_clearing', 'MXN' UNION ALL
    SELECT 'tron_wallet', 'USDT' UNION ALL
    SELECT 'transit', 'MXN' UNION ALL
    SELECT 'rolling_reserves', 'MXN' UNION ALL
    SELECT 'user_balances', 'MXN' UNION ALL
    SELECT 'reserves_payable', 'MXN' UNION ALL
    SELECT 'capital', 'MXN' UNION ALL
    SELECT 'revenue_fees', 'MXN' UNION ALL
    SELECT 'fees_stripe', 'MXN' UNION ALL
    SELECT 'fees_mp', 'MXN' UNION ALL
    SELECT 'fees_tron_network', 'USDT' UNION ALL
    SELECT 'fx_loss', 'MXN' UNION ALL
    SELECT 'fx_gain', 'MXN'
) AS acc ON acc.code = el.account_code;

-- --------------------------------------------------------------
-- 5. SALDOS EN TIEMPO REAL por clase de cuenta
-- Activo: debit-credit | Pasivo/Capital/Ingreso: credit-debit
-- --------------------------------------------------------------

CREATE VIEW IF NOT EXISTS v_realtime_balances AS
SELECT
    account_code,
    any(currency)                                                    AS currency,
    sum(debits)                                                      AS total_debits,
    sum(credits)                                                     AS total_credits,
    if(account_code IN ('user_balances', 'reserves_payable', 'capital',
                        'revenue_fees', 'fx_gain'),
       sum(credits) - sum(debits),                                   -- normal credito
       sum(debits) - sum(credits))                                   -- normal debito (activo/gasto)
                                                                   AS balance,
    multiIf(
        account_code IN ('user_balances', 'reserves_payable'), 'PASIVO',
        account_code IN ('stripe_clearing', 'mp_clearing', 'tron_wallet',
                         'transit', 'rolling_reserves'), 'ACTIVO',
        account_code IN ('revenue_fees', 'fx_gain'), 'INGRESO',
        account_code IN ('fees_stripe', 'fees_mp', 'fees_tron_network', 'fx_loss'), 'GASTO',
        'CAPITAL')                                                 AS clase
FROM ledger_movements
GROUP BY account_code;

-- --------------------------------------------------------------
-- 6. CIERRE DIARIO OLAP: ecuacion contable por dia
-- balance_global = 0 (suma de lineas debito = credito por construccion
-- del ledger PG; aqui se detecta cualquier desvio de CDC > 0.01)
-- --------------------------------------------------------------

CREATE VIEW IF NOT EXISTS v_daily_close AS
SELECT
    day,
    currency,
    sum(debits)                              AS debits,
    sum(credits)                             AS credits,
    sum(debits) - sum(credits)               AS imbalance,
    if(abs(imbalance) > 0.01, 'DESCUADRADO', 'BALANCED') AS close_status
FROM ledger_movements
GROUP BY day, currency
ORDER BY day DESC, currency;

-- --------------------------------------------------------------
-- 7. Tabla de liquidaciones cargadas por el recon engine (HTTP)
-- El motor Rust inserta batches de settlement parseados aqui
-- para el cruce vectorizado SQL-side contra transactions_st
-- --------------------------------------------------------------

CREATE TABLE IF NOT EXISTS settlement_lines
(
    batch_id           UUID,
    provider           LowCardinality(String),
    external_ref       String,
    gross              Decimal(20, 6),
    fee                Decimal(20, 6),
    net                Decimal(20, 6),
    currency           LowCardinality(String),
    capture_fx_rate    Nullable(Decimal(18, 8)),
    settlement_fx_rate Nullable(Decimal(18, 8)),
    settled_at         DateTime('UTC'),
    tron_payout_ref    Nullable(String),
    ingested_at        DateTime('UTC') DEFAULT now()
)
ENGINE = MergeTree
ORDER BY (batch_id, external_ref)
PARTITION BY toYYYYMM(settled_at);

-- Cruce SQL-side: fee esperado Stripe 3.6%+3.00 / MP 3.55%
CREATE VIEW IF NOT EXISTS v_settlement_vs_internal AS
SELECT
    s.batch_id,
    s.external_ref,
    s.provider,
    s.gross,
    s.fee,
    round(if(s.provider = 'STRIPE', s.gross * 0.036 + 3.00, s.gross * 0.0355), 6) AS expected_fee,
    s.fee - round(if(s.provider = 'STRIPE', s.gross * 0.036 + 3.00, s.gross * 0.0355), 6) AS fee_delta,
    t.amount AS internal_amount,
    s.gross - coalesce(t.amount, 0) AS amount_delta,
    if(t.external_tx_id = '', 'ORPHAN_SETTLEMENT',
       if(abs(s.fee - expected_fee) / greatest(expected_fee, 0.000001) > 0.005, 'FEE_MISMATCH',
          if(abs(s.gross - t.amount) > 0.01, 'AMOUNT_MISMATCH', 'OK'))) AS recon_status
FROM settlement_lines AS s
LEFT JOIN transactions_st AS t
    ON t.external_tx_id = s.external_ref AND t.environment = 'mainnet';
