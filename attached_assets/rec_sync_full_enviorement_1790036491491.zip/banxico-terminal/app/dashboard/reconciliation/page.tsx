import { redirect } from "next/navigation";
import { DataGrid, type Column } from "@/components/ui/DataGrid";
import { RevenueChart } from "@/components/RevenueChart";

export const dynamic = "force-dynamic";

interface ReconRow {
  external_ref: string;
  provider: "STRIPE" | "MERCADOPAGO" | "TRON";
  internal_amount: number;
  settled_amount: number;
  fee_expected: number;
  fee_actual: number;
  fx_slippage: number;
  status: "OK" | "FEE_MISMATCH" | "AMOUNT_MISMATCH" | "ORPHAN_SETTLEMENT" | "ORPHAN_INTERNAL" | "FX_SLIPPAGE";
  settled_at: string;
}

interface ReconPage {
  rows: ReconRow[];
  total: number;
  page: number;
  pageSize: number;
}

interface AnalyticsPoint {
  day: string;
  revenue: number;
  fx_slippage: number;
  network_fees: number;
}

const SORTABLE = new Set(["external_ref", "provider", "settled_amount", "fee_actual", "fx_slippage", "settled_at", "status"]);

async function fetchRecon(params: URLSearchParams): Promise<ReconPage> {
  const res = await fetch(`${process.env.INTERNAL_API_URL}/olap/reconciliation?${params}`, {
    cache: "no-store",
    headers: { authorization: `Bearer ${process.env.INTERNAL_API_TOKEN}` },
  });
  if (!res.ok) return { rows: [], total: 0, page: 1, pageSize: 25 };
  return res.json();
}

async function fetchAnalytics(): Promise<AnalyticsPoint[]> {
  const res = await fetch(`${process.env.INTERNAL_API_URL}/olap/daily-analytics`, {
    cache: "no-store",
    headers: { authorization: `Bearer ${process.env.INTERNAL_API_TOKEN}` },
  });
  if (!res.ok) return [];
  return res.json();
}

const columns: Column<ReconRow>[] = [
  { key: "external_ref", header: "Ref Externa", sortable: true, className: "font-mono text-xs",
    render: (r) => <span className="text-zinc-300">{r.external_ref.slice(0, 18)}…</span> },
  { key: "provider", header: "Proveedor", sortable: true,
    render: (r) => (
      <span className={`rounded px-1.5 py-0.5 font-mono text-[10px] ${
        r.provider === "STRIPE" ? "bg-violet-500/15 text-violet-300"
        : r.provider === "MERCADOPAGO" ? "bg-sky-500/15 text-sky-300"
        : "bg-red-500/15 text-red-300"}`}>{r.provider}</span>
    ) },
  { key: "internal_amount", header: "Interno", align: "right",
    render: (r) => r.internal_amount.toLocaleString("es-MX", { minimumFractionDigits: 2 }) },
  { key: "settled_amount", header: "Liquidado", align: "right", sortable: true,
    render: (r) => r.settled_amount.toLocaleString("es-MX", { minimumFractionDigits: 2 }) },
  { key: "fee_actual", header: "Fee Real", align: "right", sortable: true,
    render: (r) => {
      const delta = r.fee_actual - r.fee_expected;
      return (
        <span className={Math.abs(delta) > r.fee_expected * 0.005 ? "text-amber-400" : "text-zinc-300"}>
          {r.fee_actual.toLocaleString("es-MX", { minimumFractionDigits: 2 })}
          {Math.abs(delta) > r.fee_expected * 0.005 && <span className="ml-1 text-[9px]">Δ{delta.toFixed(2)}</span>}
        </span>
      );
    } },
  { key: "fx_slippage", header: "FX Slip", align: "right", sortable: true,
    render: (r) => (
      <span className={Math.abs(r.fx_slippage) > 0.01 ? "text-amber-400" : "text-zinc-600"}>
        {r.fx_slippage.toLocaleString("es-MX", { minimumFractionDigits: 4 })}
      </span>
    ) },
  { key: "status", header: "Estado", sortable: true,
    render: (r) => (
      <span className={`rounded px-1.5 py-0.5 font-mono text-[10px] ${
        r.status === "OK" ? "bg-emerald-500/15 text-emerald-300" : "bg-red-500/15 text-red-300"}`}>
        {r.status}
      </span>
    ) },
  { key: "settled_at", header: "Liquidación", sortable: true, className: "font-mono text-xs text-zinc-500",
    render: (r) => new Date(r.settled_at).toLocaleString("es-MX", { hour12: false }) },
];

export default async function ReconciliationPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | undefined>>;
}) {
  const sp = await searchParams;
  const page = Math.max(1, Number(sp.page ?? 1));
  const pageSize = Math.min(100, Math.max(10, Number(sp.pageSize ?? 25)));
  const sort = SORTABLE.has(sp.sort ?? "") ? sp.sort! : "settled_at";
  const order = sp.order === "asc" ? "asc" : "desc";
  const filterStatus = sp.status ?? "";
  const filterProvider = sp.provider ?? "";

  const params = new URLSearchParams({
    page: String(page),
    pageSize: String(pageSize),
    sort,
    order,
    ...(filterStatus && { status: filterStatus }),
    ...(filterProvider && { provider: filterProvider }),
  });

  const [data, analytics] = await Promise.all([fetchRecon(params), fetchAnalytics()]);

  if (page > 1 && data.rows.length === 0) redirect("?page=1");

  return (
    <div className="space-y-4 p-6">
      <div className="flex items-center justify-between">
        <h1 className="font-mono text-xl font-bold text-zinc-100">
          RECONCILIATION <span className="text-sm font-normal text-zinc-500">Stripe / MercadoPago vs TRON · ledger OLAP</span>
        </h1>
        <span className="font-mono text-xs text-zinc-500">{data.total.toLocaleString()} registros</span>
      </div>

      <RevenueChart data={analytics} />

      <form className="flex gap-2 font-mono text-xs" action="/dashboard/reconciliation" method="get">
        <select name="provider" defaultValue={filterProvider} className="rounded border border-zinc-800 bg-zinc-900 px-2 py-1 text-zinc-300">
          <option value="">Todos los proveedores</option>
          <option value="STRIPE">STRIPE</option>
          <option value="MERCADOPAGO">MERCADOPAGO</option>
          <option value="TRON">TRON</option>
        </select>
        <select name="status" defaultValue={filterStatus} className="rounded border border-zinc-800 bg-zinc-900 px-2 py-1 text-zinc-300">
          <option value="">Todos los estados</option>
          <option value="OK">OK</option>
          <option value="FEE_MISMATCH">FEE_MISMATCH</option>
          <option value="AMOUNT_MISMATCH">AMOUNT_MISMATCH</option>
          <option value="ORPHAN_SETTLEMENT">ORPHAN_SETTLEMENT</option>
          <option value="ORPHAN_INTERNAL">ORPHAN_INTERNAL</option>
          <option value="FX_SLIPPAGE">FX_SLIPPAGE</option>
        </select>
        <button type="submit" className="rounded bg-emerald-600 px-3 py-1 font-bold text-emerald-50 hover:bg-emerald-500">
          Filtrar
        </button>
      </form>

      <DataGrid
        rows={data.rows}
        columns={columns}
        rowKey={(r) => r.external_ref}
        pagination={{ page: data.page, pageSize: data.pageSize, total: data.total }}
        sort={{ key: sort, order }}
        basePath="/dashboard/reconciliation"
        extraParams={{ status: filterStatus, provider: filterProvider }}
      />
    </div>
  );
}
