import NextAuth, { type NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import { compare } from "bcryptjs";

export type Role = "ADMIN" | "TRADER";

declare module "next-auth" {
  interface Session {
    user: { id: string; email: string; name: string; role: Role };
  }
  interface User {
    role: Role;
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    role: Role;
    uid: string;
  }
}

export const authOptions: NextAuthOptions = {
  session: { strategy: "jwt", maxAge: 8 * 60 * 60 },
  jwt: { maxAge: 8 * 60 * 60 },
  pages: { signIn: "/login" },
  providers: [
    CredentialsProvider({
      name: "Banxico SSO",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials.password) return null;

        const res = await fetch(`${process.env.INTERNAL_API_URL}/auth/lookup`, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ email: credentials.email }),
          cache: "no-store",
        });
        if (!res.ok) return null;

        const account = (await res.json()) as {
          id: string;
          email: string;
          name: string;
          passwordHash: string;
          role: Role;
          active: boolean;
        };
        if (!account.active) return null;

        const valid = await compare(credentials.password, account.passwordHash);
        if (!valid) return null;

        return { id: account.id, email: account.email, name: account.name, role: account.role };
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.role = user.role;
        token.uid = user.id;
      }
      return token;
    },
    async session({ session, token }) {
      session.user.role = token.role;
      session.user.id = token.uid;
      return session;
    },
  },
  cookies: {
    sessionToken: {
      name: process.env.NODE_ENV === "production"
        ? "__Secure-next-auth.session-token"
        : "next-auth.session-token",
      options: { httpOnly: true, sameSite: "lax", path: "/", secure: process.env.NODE_ENV === "production" },
    },
  },
};

const handler = NextAuth(authOptions);
export { handler as GET, handler as POST };
