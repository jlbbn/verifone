import type { Metadata } from "next";
import { getServerSession } from "next-auth";
import { authOptions } from "./api/auth/[...nextauth]/route";
import { Sidebar } from "@/components/Sidebar";
import "./globals.css";

export const metadata: Metadata = {
  title: "Banxico Terminal",
  description: "Banxico-Plus institutional operations terminal",
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const session = await getServerSession(authOptions);

  return (
    <html lang="es" className="dark">
      <body className="bg-zinc-950 text-zinc-100 antialiased">
        {session ? (
          <div className="flex h-screen overflow-hidden">
            <Sidebar role={session.user.role} userName={session.user.name} />
            <main className="flex-1 overflow-y-auto">{children}</main>
          </div>
        ) : (
          children
        )}
      </body>
    </html>
  );
}
