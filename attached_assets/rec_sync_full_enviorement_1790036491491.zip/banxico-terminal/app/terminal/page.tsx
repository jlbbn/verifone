"use client";

import { useCallback } from "react";
import { OrderBook } from "@/components/OrderBook";
import { useWebSocket, type WsMessage } from "@/hooks/useWebSocket";
import { useOrderBookStore, type BookLevel, type Trade } from "@/store/useOrderBookStore";

const WS_URL = process.env.NEXT_PUBLIC_DARKPOOL_WS ?? "wss://darkpool.internal/ws";

export default function TerminalPage() {
  const applySnapshot = useOrderBookStore((s) => s.applySnapshot);
  const applyDelta = useOrderBookStore((s) => s.applyDelta);
  const pushTrade = useOrderBookStore((s) => s.pushTrade);
  const setConnected = useOrderBookStore((s) => s.setConnected);
  const trades = useOrderBookStore((s) => s.trades);
  const lastPrice = useOrderBookStore((s) => s.lastPrice);

  const onMessage = useCallback(
    (msg: WsMessage) => {
      switch (msg.channel) {
        case "book.snapshot": {
          const p = msg.payload as { bids: BookLevel[]; asks: BookLevel[] };
          applySnapshot(p.bids, p.asks);
          break;
        }
        case "book.delta": {
          const p = msg.payload as { side: "BID" | "ASK"; level: BookLevel };
          applyDelta(p.side, p.level);
          break;
        }
        case "trade": {
          pushTrade(msg.payload as Trade);
          break;
        }
      }
    },
    [applySnapshot, applyDelta, pushTrade],
  );

  const { connected } = useWebSocket({
    url: WS_URL,
    channels: ["book.snapshot", "book.delta", "trade"],
    onMessage,
  });

  // Propagar estado de conexion al store sin re-render en cada mensaje
  if (connected !== useOrderBookStore.getState().connected) setConnected(connected);

  return (
    <div className="grid h-full grid-cols-12 gap-3 p-4">
      <div className="col-span-12 flex items-center justify-between">
        <h1 className="font-mono text-xl font-bold text-zinc-100">
          DARKPOOL TERMINAL
          <span className="ml-3 text-sm font-normal text-zinc-500">USDT/MXN · HFT Engine</span>
        </h1>
        <div className="flex items-center gap-2 font-mono text-xs">
          <span className={`inline-block h-2 w-2 rounded-full ${connected ? "bg-emerald-400" : "bg-red-500 animate-pulse"}`} />
          <span className={connected ? "text-emerald-400" : "text-red-400"}>
            {connected ? "LIVE 60fps" : "RECONNECTING"}
          </span>
        </div>
      </div>

      <div className="col-span-4">
        <OrderBook />
      </div>

      <div className="col-span-5 rounded-lg border border-zinc-800 bg-zinc-900/50 p-3">
        <div className="mb-2 font-mono text-xs font-bold text-zinc-300">PRICE CHART</div>
        <div className="flex h-64 items-center justify-center font-mono text-4xl font-bold text-amber-300">
          {lastPrice.toLocaleString("es-MX", { minimumFractionDigits: 4 })}
        </div>
      </div>

      <div className="col-span-3 rounded-lg border border-zinc-800 bg-zinc-900/50">
        <div className="border-b border-zinc-800 px-3 py-2 font-mono text-xs font-bold text-zinc-300">
          RECENT TRADES
        </div>
        <div className="max-h-[70vh] overflow-y-auto">
          {trades.map((t) => (
            <div key={t.id} className="grid grid-cols-3 px-3 py-[2px] font-mono text-[11px]">
              <span className={t.side === "BID" ? "text-emerald-400" : "text-red-400"}>
                {t.price.toLocaleString("es-MX", { minimumFractionDigits: 4 })}
              </span>
              <span className="text-right text-zinc-300">{t.qty.toLocaleString()}</span>
              <span className="text-right text-zinc-600">
                {new Date(t.ts).toLocaleTimeString("es-MX", { hour12: false })}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
