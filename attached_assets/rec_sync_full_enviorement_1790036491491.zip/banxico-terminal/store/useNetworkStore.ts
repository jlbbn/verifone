"use client";

import { create } from "zustand";

export type NodeRole = "app" | "tron-mainnet-lite" | "tron-signer" | "postgres" | "clickhouse";

export interface NetworkNode {
  id: NodeRole;
  label: string;
  position: [number, number, number];
  online: boolean;
  latencyMs: number | null;
  pulse: number; // timestamp del ultimo webhook (parpadeo)
}

export interface NetworkLink {
  from: NodeRole;
  to: NodeRole;
  kind: "tailscale" | "vpc" | "cdc";
}

interface NetworkState {
  nodes: Record<NodeRole, NetworkNode>;
  links: NetworkLink[];
  setNodeStatus: (id: NodeRole, online: boolean, latencyMs: number | null) => void;
  pulseNode: (id: NodeRole) => void;
}

export const useNetworkStore = create<NetworkState>((set) => ({
  nodes: {
    app: { id: "app", label: "app (API+workers)", position: [0, 0, 0], online: true, latencyMs: null, pulse: 0 },
    "tron-mainnet-lite": { id: "tron-mainnet-lite", label: "tron-mainnet-lite", position: [4, 1, -2], online: true, latencyMs: null, pulse: 0 },
    "tron-signer": { id: "tron-signer", label: "tron-signer", position: [-4, 1, -2], online: true, latencyMs: null, pulse: 0 },
    postgres: { id: "postgres", label: "banxico-plus-db", position: [0, 3, 2], online: true, latencyMs: null, pulse: 0 },
    clickhouse: { id: "clickhouse", label: "clickhouse OLAP", position: [0, -3, 2], online: true, latencyMs: null, pulse: 0 },
  },
  links: [
    { from: "app", to: "tron-mainnet-lite", kind: "vpc" },
    { from: "app", to: "tron-signer", kind: "tailscale" },
    { from: "app", to: "postgres", kind: "vpc" },
    { from: "postgres", to: "clickhouse", kind: "cdc" },
    { from: "tron-mainnet-lite", to: "tron-signer", kind: "tailscale" },
  ],

  setNodeStatus: (id, online, latencyMs) =>
    set((s) => ({ nodes: { ...s.nodes, [id]: { ...s.nodes[id], online, latencyMs } } })),

  pulseNode: (id) =>
    set((s) => ({ nodes: { ...s.nodes, [id]: { ...s.nodes[id], pulse: Date.now() } } })),
}));
