"use client";

import { create } from "zustand";

export interface BookLevel {
  price: number;
  qty: number;
  orders: number;
}

export interface Trade {
  id: string;
  price: number;
  qty: number;
  side: "BID" | "ASK";
  ts: number;
}

interface OrderBookState {
  bids: BookLevel[];
  asks: BookLevel[];
  trades: Trade[];
  lastPrice: number;
  spread: number;
  connected: boolean;
  sequence: number;

  applySnapshot: (bids: BookLevel[], asks: BookLevel[]) => void;
  applyDelta: (side: "BID" | "ASK", level: BookLevel) => void;
  pushTrade: (t: Trade) => void;
  setConnected: (c: boolean) => void;
}

const MAX_LEVELS = 25;
const MAX_TRADES = 50;

function upsertLevel(levels: BookLevel[], level: BookLevel, desc: boolean): BookLevel[] {
  if (level.qty === 0) {
    return levels.filter((l) => l.price !== level.price);
  }
  const idx = levels.findIndex((l) => l.price === level.price);
  const next = idx >= 0 ? [...levels] : [...levels, level];
  if (idx >= 0) next[idx] = level;
  next.sort((a, b) => (desc ? b.price - a.price : a.price - b.price));
  return next.slice(0, MAX_LEVELS);
}

export const useOrderBookStore = create<OrderBookState>((set) => ({
  bids: [],
  asks: [],
  trades: [],
  lastPrice: 0,
  spread: 0,
  connected: false,
  sequence: 0,

  applySnapshot: (bids, asks) =>
    set(() => ({
      bids: bids.slice(0, MAX_LEVELS),
      asks: asks.slice(0, MAX_LEVELS),
      spread: (asks[0]?.price ?? 0) - (bids[0]?.price ?? 0),
      sequence: 0,
    })),

  applyDelta: (side, level) =>
    set((s) => {
      const bids = side === "BID" ? upsertLevel(s.bids, level, true) : s.bids;
      const asks = side === "ASK" ? upsertLevel(s.asks, level, false) : s.asks;
      return {
        bids,
        asks,
        spread: (asks[0]?.price ?? 0) - (bids[0]?.price ?? 0),
        sequence: s.sequence + 1,
      };
    }),

  pushTrade: (t) =>
    set((s) => ({
      trades: [t, ...s.trades].slice(0, MAX_TRADES),
      lastPrice: t.price,
    })),

  setConnected: (c) => set({ connected: c }),
}));
