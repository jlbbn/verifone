"use client";

import { useEffect, useRef, useState } from "react";

export interface TailscalePeer {
  hostname: string;
  ip: string;
  os: string;
  online: boolean;
  latencyMs: number | null;
  rxBytes: number;
  txBytes: number;
  lastSeen: string;
  role: "app" | "tron-node" | "tron-signer" | "unknown";
}

export interface TailscaleMetrics {
  peers: TailscalePeer[];
  tunnelUp: boolean;
  updatedAt: number;
}

const POLL_MS = 5_000;

export function useTailscaleMetrics(enabled = true): TailscaleMetrics {
  const [metrics, setMetrics] = useState<TailscaleMetrics>({ peers: [], tunnelUp: false, updatedAt: 0 });
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (!enabled) return;

    async function poll() {
      try {
        const res = await fetch("/api/metrics/tailscale", { cache: "no-store" });
        if (!res.ok) throw new Error(String(res.status));
        const data = (await res.json()) as TailscaleMetrics;
        setMetrics({ ...data, updatedAt: Date.now() });
      } catch {
        setMetrics((m) => ({ ...m, tunnelUp: false, updatedAt: Date.now() }));
      }
    }

    poll();
    timer.current = setInterval(poll, POLL_MS);
    return () => {
      if (timer.current) clearInterval(timer.current);
    };
  }, [enabled]);

  return metrics;
}
