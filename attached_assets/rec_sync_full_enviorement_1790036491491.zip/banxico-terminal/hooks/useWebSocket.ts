"use client";

import { useEffect, useRef, useState, useCallback } from "react";

export interface WsMessage {
  channel: string;
  payload: unknown;
  ts: number;
}

type Handler = (msg: WsMessage) => void;

interface Options {
  url: string;
  channels: string[];
  onMessage: Handler;
  reconnectMs?: number;
  maxRetries?: number;
}

export function useWebSocket({ url, channels, onMessage, reconnectMs = 1000, maxRetries = 20 }: Options) {
  const wsRef = useRef<WebSocket | null>(null);
  const retriesRef = useRef(0);
  const handlerRef = useRef(onMessage);
  handlerRef.current = onMessage;
  const [connected, setConnected] = useState(false);
  const [attempts, setAttempts] = useState(0);

  const connect = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) return;

    const ws = new WebSocket(url);
    wsRef.current = ws;

    ws.onopen = () => {
      retriesRef.current = 0;
      setAttempts(0);
      setConnected(true);
      ws.send(JSON.stringify({ op: "subscribe", channels }));
    };

    ws.onmessage = (ev) => {
      try {
        const msg = JSON.parse(ev.data as string) as WsMessage;
        handlerRef.current(msg);
      } catch {
        // frame no-JSON: ignorar (heartbeat binario)
      }
    };

    ws.onclose = () => {
      setConnected(false);
      if (retriesRef.current >= maxRetries) return;
      const backoff = Math.min(reconnectMs * 2 ** retriesRef.current, 30_000);
      retriesRef.current += 1;
      setAttempts(retriesRef.current);
      setTimeout(connect, backoff + Math.random() * 500);
    };

    ws.onerror = () => ws.close();
  }, [url, channels, reconnectMs, maxRetries]);

  useEffect(() => {
    connect();
    return () => {
      retriesRef.current = maxRetries; // no reconectar tras unmount
      wsRef.current?.close();
      wsRef.current = null;
    };
  }, [connect, maxRetries]);

  const send = useCallback((data: unknown) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(data));
    }
  }, []);

  return { connected, attempts, send };
}
