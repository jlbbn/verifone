"use client";

import { memo, useEffect, useRef, useState } from "react";
import { useOrderBookStore, type BookLevel } from "@/store/useOrderBookStore";

const fmt = (n: number, d = 4) =>
  n.toLocaleString("es-MX", { minimumFractionDigits: d, maximumFractionDigits: d });

// Fila memoizada: solo re-renderiza si su nivel cambia (referencia estable del store)
const LevelRow = memo(function LevelRow({
  level, side, maxQty, flash,
}: { level: BookLevel; side: "BID" | "ASK"; maxQty: number; flash: boolean }) {
  const depth = maxQty > 0 ? (level.qty / maxQty) * 100 : 0;
  return (
    <div className={`relative grid grid-cols-3 px-2 py-[1px] font-mono text-[11px] leading-4 ${
      flash ? "animate-pulse" : ""
    }`}>
      <div
        className={`absolute inset-y-0 right-0 ${side === "BID" ? "bg-emerald-500/10" : "bg-red-500/10"}`}
        style={{ width: `${depth}%` }}
      />
      <span className={side === "BID" ? "text-emerald-400" : "text-red-400"}>{fmt(level.price)}</span>
      <span className="text-right text-zinc-300">{fmt(level.qty, 2)}</span>
      <span className="text-right text-zinc-600">{level.orders}</span>
    </div>
  );
});

export function OrderBook() {
  // Suscripciones selectivas: solo el slice que usa este componente
  const bids = useOrderBookStore((s) => s.bids);
  const asks = useOrderBookStore((s) => s.asks);
  const spread = useOrderBookStore((s) => s.spread);
  const lastPrice = useOrderBookStore((s) => s.lastPrice);
  const sequence = useOrderBookStore((s) => s.sequence);

  const lastSeq = useRef(sequence);
  const [flash, setFlash] = useState(false);

  useEffect(() => {
    if (sequence !== lastSeq.current) {
      lastSeq.current = sequence;
      setFlash(true);
      const t = setTimeout(() => setFlash(false), 120);
      return () => clearTimeout(t);
    }
  }, [sequence]);

  const maxQty = Math.max(
    bids[0]?.qty ?? 0,
    asks[0]?.qty ?? 0,
    ...bids.map((b) => b.qty),
    ...asks.map((a) => a.qty),
    1,
  );

  return (
    <div className="rounded-lg border border-zinc-800 bg-zinc-900/50">
      <div className="flex items-center justify-between border-b border-zinc-800 px-3 py-2">
        <span className="font-mono text-xs font-bold text-zinc-300">ORDER BOOK · USDT/MXN</span>
        <span className="font-mono text-[10px] text-zinc-500">seq {sequence}</span>
      </div>

      <div className="grid grid-cols-3 px-2 py-1 font-mono text-[10px] uppercase text-zinc-600">
        <span>Precio</span><span className="text-right">Cantidad</span><span className="text-right">#Ord</span>
      </div>

      <div className="flex flex-col-reverse">
        {asks.slice(0, 15).map((l) => (
          <LevelRow key={`a-${l.price}`} level={l} side="ASK" maxQty={maxQty} flash={flash} />
        ))}
      </div>

      <div className="flex items-center justify-between border-y border-zinc-800 bg-zinc-950/80 px-3 py-1.5">
        <span className="font-mono text-lg font-bold text-amber-300">{fmt(lastPrice)}</span>
        <span className="font-mono text-xs text-zinc-500">spread {fmt(spread, 4)}</span>
      </div>

      <div>
        {bids.slice(0, 15).map((l) => (
          <LevelRow key={`b-${l.price}`} level={l} side="BID" maxQty={maxQty} flash={flash} />
        ))}
      </div>
    </div>
  );
}
