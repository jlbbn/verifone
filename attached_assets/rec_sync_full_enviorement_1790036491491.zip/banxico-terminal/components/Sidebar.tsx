"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { signOut } from "next-auth/react";
import { motion } from "framer-motion";
import {
  Activity, ArrowLeftRight, BarChart3, Globe2, LogOut, ShieldCheck, Zap,
} from "lucide-react";

type Role = "ADMIN" | "TRADER";

const NAV = [
  { href: "/terminal", label: "Trading Terminal", icon: Zap, roles: ["ADMIN", "TRADER"] },
  { href: "/dashboard/reconciliation", label: "Reconciliation", icon: ArrowLeftRight, roles: ["ADMIN", "TRADER"] },
  { href: "/dashboard/network", label: "Network 3D", icon: Globe2, roles: ["ADMIN", "TRADER"] },
  { href: "/dashboard/analytics", label: "Analytics", icon: BarChart3, roles: ["ADMIN", "TRADER"] },
  { href: "/admin", label: "Administration", icon: ShieldCheck, roles: ["ADMIN"] },
] as const;

export function Sidebar({ role, userName }: { role: Role; userName: string }) {
  const pathname = usePathname();

  return (
    <aside className="flex w-60 flex-col border-r border-zinc-800 bg-zinc-900/60 backdrop-blur">
      <div className="flex items-center gap-2 border-b border-zinc-800 px-5 py-4">
        <Activity className="h-5 w-5 text-emerald-400" />
        <span className="font-mono text-sm font-bold tracking-widest text-emerald-400">
          BANXICO<span className="text-zinc-500">.TERM</span>
        </span>
      </div>

      <nav className="flex-1 space-y-1 px-2 py-4">
        {NAV.filter((item) => item.roles.includes(role)).map((item) => {
          const active = pathname.startsWith(item.href);
          return (
            <Link key={item.href} href={item.href} className="relative block">
              {active && (
                <motion.span
                  layoutId="nav-active"
                  className="absolute inset-0 rounded-md bg-emerald-500/10 ring-1 ring-emerald-500/40"
                  transition={{ type: "spring", stiffness: 400, damping: 32 }}
                />
              )}
              <span
                className={`relative flex items-center gap-3 rounded-md px-3 py-2 text-sm ${
                  active ? "text-emerald-300" : "text-zinc-400 hover:text-zinc-200"
                }`}
              >
                <item.icon className="h-4 w-4" />
                {item.label}
              </span>
            </Link>
          );
        })}
      </nav>

      <div className="border-t border-zinc-800 px-4 py-3">
        <div className="mb-2 truncate font-mono text-xs text-zinc-500">
          {userName} · <span className="text-emerald-500">{role}</span>
        </div>
        <button
          onClick={() => signOut({ callbackUrl: "/login" })}
          className="flex items-center gap-2 text-xs text-zinc-500 transition hover:text-red-400"
        >
          <LogOut className="h-3.5 w-3.5" /> Cerrar sesión
        </button>
      </div>
    </aside>
  );
}
