"use client";

import { motion } from "framer-motion";
import type { ReactNode } from "react";

export function Card({
  title, value, delta, icon, tone = "neutral",
}: {
  title: string;
  value: string;
  delta?: string;
  icon?: ReactNode;
  tone?: "neutral" | "up" | "down" | "warn";
}) {
  const toneClass = {
    neutral: "text-zinc-100",
    up: "text-emerald-400",
    down: "text-red-400",
    warn: "text-amber-400",
  }[tone];

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25, ease: "easeOut" }}
      className="rounded-lg border border-zinc-800 bg-zinc-900/50 p-4"
    >
      <div className="flex items-center justify-between">
        <span className="font-mono text-[10px] uppercase tracking-wider text-zinc-500">{title}</span>
        {icon}
      </div>
      <div className={`mt-2 font-mono text-2xl font-bold ${toneClass}`}>{value}</div>
      {delta && <div className="mt-1 font-mono text-xs text-zinc-500">{delta}</div>}
    </motion.div>
  );
}
