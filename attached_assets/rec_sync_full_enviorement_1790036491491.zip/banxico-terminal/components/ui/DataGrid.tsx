"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowDown, ArrowUp, ChevronLeft, ChevronRight } from "lucide-react";
import type { ReactNode } from "react";

export interface Column<T> {
  key: string;
  header: string;
  sortable?: boolean;
  align?: "left" | "right";
  className?: string;
  render: (row: T) => ReactNode;
}

interface Pagination {
  page: number;
  pageSize: number;
  total: number;
}

function buildQuery(
  basePath: string,
  overrides: Record<string, string | number>,
  extra?: Record<string, string>,
): string {
  const params = new URLSearchParams();
  for (const [k, v] of Object.entries(extra ?? {})) if (v) params.set(k, v);
  for (const [k, v] of Object.entries(overrides)) if (String(v)) params.set(k, String(v));
  const qs = params.toString();
  return qs ? `${basePath}?${qs}` : basePath;
}

export function DataGrid<T>({
  rows, columns, rowKey, pagination, sort, basePath, extraParams,
}: {
  rows: T[];
  columns: Column<T>[];
  rowKey: (row: T) => string;
  pagination: Pagination;
  sort: { key: string; order: "asc" | "desc" };
  basePath: string;
  extraParams?: Record<string, string>;
}) {
  const totalPages = Math.max(1, Math.ceil(pagination.total / pagination.pageSize));

  return (
    <div className="overflow-hidden rounded-lg border border-zinc-800">
      <table className="w-full border-collapse text-sm">
        <thead>
          <tr className="border-b border-zinc-800 bg-zinc-900/80">
            {columns.map((col) => {
              const active = sort.key === col.key;
              const nextOrder = active && sort.order === "desc" ? "asc" : "desc";
              return (
                <th
                  key={col.key}
                  className={`px-3 py-2 font-mono text-[10px] uppercase tracking-wider text-zinc-500 ${
                    col.align === "right" ? "text-right" : "text-left"
                  }`}
                >
                  {col.sortable ? (
                    <Link
                      href={buildQuery(basePath, { page: 1, pageSize: pagination.pageSize, sort: col.key, order: nextOrder }, extraParams)}
                      className={`inline-flex items-center gap-1 hover:text-zinc-200 ${active ? "text-emerald-400" : ""}`}
                    >
                      {col.header}
                      {active && (sort.order === "desc" ? <ArrowDown className="h-3 w-3" /> : <ArrowUp className="h-3 w-3" />)}
                    </Link>
                  ) : (
                    col.header
                  )}
                </th>
              );
            })}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <motion.tr
              key={rowKey(row)}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: Math.min(i * 0.012, 0.3) }}
              className="border-b border-zinc-800/50 transition-colors hover:bg-zinc-800/30"
            >
              {columns.map((col) => (
                <td
                  key={col.key}
                  className={`px-3 py-1.5 ${col.align === "right" ? "text-right font-mono" : ""} ${col.className ?? ""}`}
                >
                  {col.render(row)}
                </td>
              ))}
            </motion.tr>
          ))}
          {rows.length === 0 && (
            <tr>
              <td colSpan={columns.length} className="px-3 py-8 text-center font-mono text-xs text-zinc-600">
                sin resultados para los filtros aplicados
              </td>
            </tr>
          )}
        </tbody>
      </table>

      <div className="flex items-center justify-between border-t border-zinc-800 bg-zinc-900/60 px-4 py-2 font-mono text-xs text-zinc-500">
        <span>
          página {pagination.page} de {totalPages} · {pagination.pageSize}/pág
        </span>
        <div className="flex gap-1">
          <Link
            href={buildQuery(basePath, { page: Math.max(1, pagination.page - 1), pageSize: pagination.pageSize, sort: sort.key, order: sort.order }, extraParams)}
            className={`rounded border border-zinc-800 p-1 ${pagination.page <= 1 ? "pointer-events-none opacity-30" : "hover:border-zinc-600"}`}
          >
            <ChevronLeft className="h-4 w-4" />
          </Link>
          <Link
            href={buildQuery(basePath, { page: Math.min(totalPages, pagination.page + 1), pageSize: pagination.pageSize, sort: sort.key, order: sort.order }, extraParams)}
            className={`rounded border border-zinc-800 p-1 ${pagination.page >= totalPages ? "pointer-events-none opacity-30" : "hover:border-zinc-600"}`}
          >
            <ChevronRight className="h-4 w-4" />
          </Link>
        </div>
      </div>
    </div>
  );
}
