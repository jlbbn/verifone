"use client";

import { useMemo, useRef, useCallback } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { OrbitControls, Line, Html, Stars } from "@react-three/drei";
import * as THREE from "three";
import { useNetworkStore, type NetworkNode, type NetworkLink } from "@/store/useNetworkStore";
import { useWebSocket, type WsMessage } from "@/hooks/useWebSocket";
import { useTailscaleMetrics } from "@/hooks/useTailscaleMetrics";

const WS_URL = process.env.NEXT_PUBLIC_EVENTS_WS ?? "wss://api.internal/events";

const ROLE_COLOR: Record<NetworkNode["id"], string> = {
  app: "#34d399",
  "tron-mainnet-lite": "#f59e0b",
  "tron-signer": "#a78bfa",
  postgres: "#60a5fa",
  clickhouse: "#f472b6",
};

const LINK_COLOR: Record<NetworkLink["kind"], string> = {
  tailscale: "#22d3ee",
  vpc: "#52525b",
  cdc: "#f472b6",
};

function Node({ node }: { node: NetworkNode }) {
  const mesh = useRef<THREE.Mesh>(null);
  const ring = useRef<THREE.Mesh>(null);

  useFrame(({ clock }) => {
    if (!mesh.current) return;
    // Parpadeo: 1.2s tras el pulso del webhook
    const age = (Date.now() - node.pulse) / 1000;
    const pulsing = age < 1.2;
    const base = node.online ? 1 : 0.3;
    const intensity = pulsing ? base * (1.5 + Math.sin(clock.elapsedTime * 20) * 0.5) : base;
    (mesh.current.material as THREE.MeshStandardMaterial).emissiveIntensity = intensity;
    if (ring.current) {
      ring.current.visible = pulsing;
      const s = 1.5 + age * 2;
      ring.current.scale.setScalar(s);
      (ring.current.material as THREE.MeshBasicMaterial).opacity = Math.max(0, 0.8 - age * 0.6);
    }
  });

  return (
    <group position={node.position}>
      <mesh ref={mesh}>
        <sphereGeometry args={[0.45, 32, 32]} />
        <meshStandardMaterial
          color={node.online ? ROLE_COLOR[node.id] : "#3f3f46"}
          emissive={node.online ? ROLE_COLOR[node.id] : "#18181b"}
          emissiveIntensity={1}
        />
      </mesh>
      <mesh ref={ring} visible={false}>
        <ringGeometry args={[0.6, 0.65, 32]} />
        <meshBasicMaterial color={ROLE_COLOR[node.id]} transparent side={THREE.DoubleSide} />
      </mesh>
      <Html distanceFactor={12} className="pointer-events-none select-none">
        <div className="whitespace-nowrap rounded bg-zinc-950/80 px-2 py-1 font-mono text-[10px] text-zinc-200 ring-1 ring-zinc-700">
          {node.label}
          <span className={node.online ? "text-emerald-400" : "text-red-400"}>
            {" "}{node.online ? `● ${node.latencyMs ?? "?"}ms` : "○ down"}
          </span>
        </div>
      </Html>
    </group>
  );
}

function Links() {
  const nodes = useNetworkStore((s) => s.nodes);
  const links = useNetworkStore((s) => s.links);

  return (
    <>
      {links.map((l) => {
        const a = new THREE.Vector3(...nodes[l.from].position);
        const b = new THREE.Vector3(...nodes[l.to].position);
        const mid = a.clone().lerp(b, 0.5).add(new THREE.Vector3(0, a.distanceTo(b) * 0.15, 0));
        const curve = new THREE.QuadraticBezierCurve3(a, mid, b);
        const points = curve.getPoints(24);
        return (
          <Line
            key={`${l.from}-${l.to}`}
            points={points}
            color={LINK_COLOR[l.kind]}
            lineWidth={l.kind === "tailscale" ? 2 : 1}
            dashed={l.kind === "cdc"}
            dashSize={0.2}
            gapSize={0.1}
            transparent
            opacity={l.kind === "vpc" ? 0.4 : 0.8}
          />
        );
      })}
    </>
  );
}

function Scene() {
  const nodes = useNetworkStore((s) => s.nodes);
  const list = useMemo(() => Object.values(nodes), [nodes]);

  return (
    <>
      <ambientLight intensity={0.3} />
      <pointLight position={[10, 10, 10]} intensity={1.2} />
      <Stars radius={60} depth={30} count={2000} factor={3} fade />
      {list.map((n) => <Node key={n.id} node={n} />)}
      <Links />
      <OrbitControls enableDamping dampingFactor={0.08} autoRotate autoRotateSpeed={0.4} />
    </>
  );
}

export function NetworkVisualizer() {
  const setNodeStatus = useNetworkStore((s) => s.setNodeStatus);
  const pulseNode = useNetworkStore((s) => s.pulseNode);

  const metrics = useTailscaleMetrics(true);

  // Sincronizar metricas Tailscale -> nodos 3D
  useMemo(() => {
    for (const peer of metrics.peers) {
      const role = peer.hostname.includes("tron-signer") ? "tron-signer"
        : peer.hostname.includes("tron") ? "tron-mainnet-lite"
        : peer.hostname.includes("app") ? "app" : null;
      if (role) setNodeStatus(role, peer.online, peer.latencyMs);
    }
  }, [metrics, setNodeStatus]);

  const onMessage = useCallback(
    (msg: WsMessage) => {
      // Canales: webhook.stripe -> app, tron.block -> tron-mainnet-lite, etc.
      const map: Record<string, Parameters<typeof pulseNode>[0]> = {
        "webhook.stripe": "app",
        "webhook.mercadopago": "app",
        "tron.block": "tron-mainnet-lite",
        "tron.sign": "tron-signer",
        "cdc.event": "postgres",
        "olap.ingest": "clickhouse",
      };
      const target = map[msg.channel];
      if (target) pulseNode(target);
    },
    [pulseNode],
  );

  useWebSocket({
    url: WS_URL,
    channels: ["webhook.stripe", "webhook.mercadopago", "tron.block", "tron.sign", "cdc.event", "olap.ingest"],
    onMessage,
  });

  return (
    <div className="h-[70vh] w-full rounded-lg border border-zinc-800 bg-zinc-950">
      <Canvas camera={{ position: [0, 4, 12], fov: 50 }} dpr={[1, 2]}>
        <Scene />
      </Canvas>
      <div className="flex gap-4 px-4 py-2 font-mono text-[10px] text-zinc-500">
        <span className="text-cyan-400">━━ tailscale</span>
        <span className="text-zinc-400">━━ vpc</span>
        <span className="text-pink-400">╌╌ cdc (debezium)</span>
        <span className={metrics.tunnelUp ? "text-emerald-400" : "text-red-400"}>
          tunnel: {metrics.tunnelUp ? "UP" : "DOWN"}
        </span>
      </div>
    </div>
  );
}
