"use client";

import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
} from "recharts";

interface Point {
  day: string;
  revenue: number;
  fx_slippage: number;
  network_fees: number;
}

export function RevenueChart({ data }: { data: Point[] }) {
  return (
    <div className="rounded-lg border border-zinc-800 bg-zinc-900/50 p-4">
      <div className="mb-2 font-mono text-xs font-bold text-zinc-300">
        INGRESOS · FX SLIPPAGE · NETWORK FEES (apilado diario)
      </div>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 4, right: 8, left: 8, bottom: 0 }}>
            <defs>
              <linearGradient id="gRevenue" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#34d399" stopOpacity={0.6} />
                <stop offset="100%" stopColor="#34d399" stopOpacity={0.05} />
              </linearGradient>
              <linearGradient id="gSlip" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#f59e0b" stopOpacity={0.6} />
                <stop offset="100%" stopColor="#f59e0b" stopOpacity={0.05} />
              </linearGradient>
              <linearGradient id="gFees" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#f472b6" stopOpacity={0.6} />
                <stop offset="100%" stopColor="#f472b6" stopOpacity={0.05} />
              </linearGradient>
            </defs>
            <CartesianGrid stroke="#27272a" strokeDasharray="3 3" />
            <XAxis dataKey="day" tick={{ fill: "#71717a", fontSize: 10, fontFamily: "monospace" }} />
            <YAxis tick={{ fill: "#71717a", fontSize: 10, fontFamily: "monospace" }}
              tickFormatter={(v: number) => v >= 1000 ? `${(v / 1000).toFixed(1)}k` : String(v)} />
            <Tooltip
              contentStyle={{ background: "#09090b", border: "1px solid #27272a", fontFamily: "monospace", fontSize: 11 }}
              labelStyle={{ color: "#a1a1aa" }}
              formatter={(value: number, name: string) => [
                value.toLocaleString("es-MX", { minimumFractionDigits: 2 }),
                name,
              ]}
            />
            <Legend wrapperStyle={{ fontFamily: "monospace", fontSize: 11 }} />
            <Area type="monotone" dataKey="revenue" name="Ingresos" stackId="1"
              stroke="#34d399" fill="url(#gRevenue)" strokeWidth={1.5} />
            <Area type="monotone" dataKey="fx_slippage" name="FX Slippage" stackId="1"
              stroke="#f59e0b" fill="url(#gSlip)" strokeWidth={1.5} />
            <Area type="monotone" dataKey="network_fees" name="Network Fees" stackId="1"
              stroke="#f472b6" fill="url(#gFees)" strokeWidth={1.5} />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
