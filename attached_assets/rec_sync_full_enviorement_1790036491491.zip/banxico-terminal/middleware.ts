import { withAuth } from "next-auth/middleware";
import { NextResponse } from "next/server";

const ROLE_ROUTES: Record<string, string[]> = {
  "/terminal": ["ADMIN", "TRADER"],
  "/dashboard/reconciliation": ["ADMIN", "TRADER"],
  "/dashboard/network": ["ADMIN", "TRADER"],
  "/admin": ["ADMIN"],
};

export default withAuth(
  function middleware(req) {
    const role = req.nextauth.token?.role as string | undefined;
    const path = req.nextUrl.pathname;

    for (const [prefix, allowed] of Object.entries(ROLE_ROUTES)) {
      if (path.startsWith(prefix) && role && !allowed.includes(role)) {
        return NextResponse.redirect(new URL("/forbidden", req.url));
      }
    }
    return NextResponse.next();
  },
  {
    callbacks: {
      authorized: ({ token }) => !!token,
    },
  },
);

export const config = {
  matcher: ["/terminal/:path*", "/dashboard/:path*", "/admin/:path*"],
};
