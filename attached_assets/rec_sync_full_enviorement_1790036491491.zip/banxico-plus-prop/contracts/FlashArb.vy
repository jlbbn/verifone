# @version ^0.3.10
# ==============================================================
# FlashArb.vy — Ejecutor de arbitraje con Flash Loan (Vyper)
# Pathing: JustLend (flash) -> swaps SunSwap V2 -> repay + fee
# en la misma transaccion. Hot path con raw_call inline.
# Todo en una sola tx: si el profit neto < minProfit, revierte
# y el prestamo jamas se origina (atomicidad de EVM/TVM).
# ==============================================================

interface ERC20:
    def transfer(to: address, amount: uint256) -> bool: nonpayable
    def transferFrom(frm: address, to: address, amount: uint256) -> bool: nonpayable
    def balanceOf(account: address) -> uint256: view
    def approve(spender: address, amount: uint256) -> bool: nonpayable

interface SunSwapPair:
    def swap(amount0Out: uint256, amount1Out: uint256, to: address, data: Bytes[32]): nonpayable
    def getReserves() -> (uint256, uint256): view
    def token0() -> address: view
    def token1() -> address: view

interface JustLendFlash:
    # Flash loan estilo JustLend/AAVE: el protocolo llama a receiveFlashLoan
    def flashLoan(asset: address, amount: uint256, params: Bytes[1024]): nonpayable

# ---------------- Storage ----------------
owner: public(address)
executor: public(address)          # EOA del sniper (unico que dispara)
lender: public(address)            # pool JustLend origen del flash loan
fee_recipient: public(address)     # cuenta de fees del orquestador
bribe_bps: public(uint256)         # bribe al builder (30% = 3000)

# ---------------- Eventos ----------------
event ArbExecuted:
    profit_gross: uint256
    fee_protocol: uint256
    bribe: uint256
    hops: uint256

event ExecutorRotated:
    previous: address
    next: address

# ---------------- Errores ----------------
error NotAuthorized()
error ProfitTooLow()
error RepayFailed()

BPS: constant(uint256) = 10_000
PROTOCOL_FEE_BPS: constant(uint256) = 500   # 5% del profit bruto al orquestador

@external
def __init__(_lender: address, _executor: address, _fee_recipient: address):
    self.owner = msg.sender
    self.lender = _lender
    self.executor = _executor
    self.fee_recipient = _fee_recipient
    self.bribe_bps = 3_000

@external
def rotate_executor(next: address):
    assert msg.sender == self.owner, "not owner"
    log ExecutorRotated(self.executor, next)
    self.executor = next

# --------------------------------------------------------------
# Calculo AMM V2 puro: out = (in*997*rOut) / (rIn*1000 + in*997)
# fee 30 bps SunSwap
# --------------------------------------------------------------
@internal
@pure
def _get_amount_out(amount_in: uint256, reserve_in: uint256, reserve_out: uint256) -> uint256:
    in_eff: uint256 = amount_in * 997
    return (in_eff * reserve_out) / (reserve_in * 1000 + in_eff)

# --------------------------------------------------------------
# 1. Entrada del sniper: solicita el flash loan
# pairs/dirs packed: cada hop = (pair, zeroForOne)
# --------------------------------------------------------------
@external
def execute_arb(
    asset: address,
    amount: uint256,
    pairs: DynArray[address, 8],
    zero_for_one: DynArray[bool, 8],
    min_profit: uint256,
):
    assert msg.sender == self.executor, "not executor"
    assert len(pairs) == len(zero_for_one), "len mismatch"
    assert len(pairs) >= 2, "need >=2 hops"

    # params pasados al callback via calldata (sin storage writes)
    JustLendFlash(self.lender).flashLoan(
        asset,
        amount,
        _abi_encode(pairs, zero_for_one, min_profit),
    )

# --------------------------------------------------------------
# 2. Callback del lender: tenemos `amount` prestado + debemos
#    amount + premium al final. Todo o nada.
# --------------------------------------------------------------
@external
def receive_flash_loan(
    asset: address,
    amount: uint256,
    premium: uint256,
    params: Bytes[1024],
):
    assert msg.sender == self.lender, "not lender"

    pairs: DynArray[address, 8] = empty(DynArray[address, 8])
    dirs: DynArray[bool, 8] = empty(DynArray[bool, 8])
    min_profit: uint256 = 0
    (pairs, dirs, min_profit) = _abi_decode(params, (DynArray[address, 8], DynArray[bool, 8], uint256))

    # ---------------- Pathing del arbitraje ----------------
    current_asset: address = asset
    current_amount: uint256 = amount

    for i in range(8):
        if i >= len(pairs):
            break
        pair: address = pairs[i]
        zfo: bool = dirs[i]

        r0: uint256 = 0
        r1: uint256 = 0
        (r0, r1) = SunSwapPair(pair).getReserves()

        token0: address = SunSwapPair(pair).token0()
        next_asset: address = SunSwapPair(pair).token1() if zfo else token0

        rin: uint256 = r0 if zfo else r1
        rout: uint256 = r1 if zfo else r0
        out: uint256 = self._get_amount_out(current_amount, rin, rout)

        # Transferir input al par y ejecutar swap: salida directa
        # al siguiente par (o a este contrato en el ultimo hop)
        is_last: bool = i == len(pairs) - 1
        next_hop: address = self if is_last else pairs[i + 1]

        ERC20(current_asset).transfer(pair, current_amount)
        if zfo:
            SunSwapPair(pair).swap(0, out, next_hop, b"")
        else:
            SunSwapPair(pair).swap(out, 0, next_hop, b"")

        current_asset = next_asset
        current_amount = out

    # ---------------- Liquidacion ----------------
    owed: uint256 = amount + premium

    # El swap final devolvio `asset`? (ruta cerrada: ultimo token == asset)
    # current_amount esta en `asset` solo si la ruta cerro; validar:
    final_balance: uint256 = ERC20(asset).balanceOf(self)
    assert final_balance >= owed, "insufficient to repay"

    profit_gross: uint256 = final_balance - owed
    assert profit_gross >= min_profit, "profit below floor"

    # Repago al lender (approval previa no requerida: transfer directo)
    ERC20(asset).transfer(self.lender, owed)

    # Split: 5% protocolo, bribe_bps% builder (enviado por el sniper off-chain
    # como coinbase transfer en EVM; en TRON se liquida via builder endpoint),
    # resto al owner
    fee_protocol: uint256 = profit_gross * PROTOCOL_FEE_BPS / BPS
    bribe: uint256 = profit_gross * self.bribe_bps / BPS
    net: uint256 = profit_gross - fee_protocol - bribe

    if fee_protocol > 0:
        ERC20(asset).transfer(self.fee_recipient, fee_protocol)
    if net > 0:
        ERC20(asset).transfer(self.owner, net)

    log ArbExecuted(profit_gross, fee_protocol, bribe, len(pairs))

# --------------------------------------------------------------
# Rescue: solo owner, solo tokens fuera de operacion activa
# --------------------------------------------------------------
@external
def rescue(token: address, to: address, amount: uint256):
    assert msg.sender == self.owner, "not owner"
    ERC20(token).transfer(to, amount)
