//! MEV Sniper — mempool de TRON.
//! Escucha txs pendientes via gRPC del nodo local, replica el estado de
//! los DEX (SunSwap V2 pairs) y JustLend en memoria (mini-TVM de pares),
//! simula rutas de arbitraje 2-hop/3-hop y emite bundles de back-run.
//!
//! Flujo por tx de mempool:
//!   1. Decode: ¿toca un par SunSwap observado? (swapExactTokensForTokens)
//!   2. Aplicar la tx sobre el estado SHADOW de los pares afectados.
//!   3. Recalcular precios y evaluar rutas (triangular + SunSwap<->JustLend).
//!   4. Si delta_net = profit_bruto - (energy_cost + bribe) > threshold:
//!      construir bundle [tx_victima, tx_arbitraje] y enviar al builder.
//!
//! El estado es un fork en memoria: nunca toca chain real hasta el bundle.

use anyhow::{Context, Result};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::sync::Arc;
use tokio::sync::{mpsc, RwLock};
use tonic::transport::Channel;
use tracing::{info, warn};

// ------------------------------------------------------------------
// Config
// ------------------------------------------------------------------
const MIN_PROFIT_USDT: u128 = 5_000_000;          // 5 USDT neto minimo (1e6)
const ENERGY_PRICE_SUN: u128 = 210;               // ~210 SUN por energy (dinamico on-chain)
const EST_ENERGY_PER_SWAP: u128 = 65_000;         // swap SunSwap V2 tipico
const BRIBE_BPS_OF_PROFIT: u128 = 3_000;          // 30% del profit al builder/validator
const MAX_HOPS: usize = 3;
const MEMPOOL_CHANNEL_CAP: usize = 65_536;

// ------------------------------------------------------------------
// Estado de un par AMM (x*y=k) — replicado en memoria
// ------------------------------------------------------------------
#[derive(Clone, Copy, Debug)]
pub struct PairState {
    pub address: [u8; 20],
    pub token0: [u8; 20],
    pub token1: [u8; 20],
    pub reserve0: u128,
    pub reserve1: u128,
    pub fee_bps: u128, // 30 = 0.3% SunSwap
}

impl PairState {
    /// Output con fee aplicado al input (formula Uniswap V2 exacta)
    #[inline]
    pub fn get_amount_out(&self, amount_in: u128, zero_for_one: bool) -> Option<u128> {
        if amount_in == 0 { return None; }
        let (rin, rout) = if zero_for_one {
            (self.reserve0, self.reserve1)
        } else {
            (self.reserve1, self.reserve0)
        };
        let fee = 10_000u128 - self.fee_bps;
        let in_eff = amount_in.checked_mul(fee)?;
        let num = in_eff.checked_mul(rout)?;
        let den = rin.checked_mul(10_000)?.checked_add(in_eff)?;
        if den == 0 { return None; }
        Some(num / den)
    }

    /// Aplica un swap al estado shadow (post-tx de la victima)
    #[inline]
    pub fn apply_swap(&mut self, amount_in: u128, amount_out: u128, zero_for_one: bool) {
        if zero_for_one {
            self.reserve0 += amount_in;
            self.reserve1 -= amount_out;
        } else {
            self.reserve1 += amount_in;
            self.reserve0 -= amount_out;
        }
    }

    /// Spot price token1/token0 en 1e18
    #[inline]
    pub fn spot_price(&self) -> u128 {
        if self.reserve0 == 0 { return 0; }
        self.reserve1 * 1_000_000_000_000_000_000 / self.reserve0
    }
}

// ------------------------------------------------------------------
// Estado global shadow: pares indexados + fork efimero por simulacion
// ------------------------------------------------------------------
pub struct ShadowState {
    pairs: HashMap<[u8; 20], PairState>,
    // indice token -> pares que lo contienen (para construccion de rutas)
    by_token: HashMap<[u8; 20], Vec<[u8; 20]>>,
}

impl ShadowState {
    pub fn new() -> Self {
        Self { pairs: HashMap::new(), by_token: HashMap::new() }
    }

    pub fn upsert_pair(&mut self, p: PairState) {
        self.by_token.entry(p.token0).or_default().push(p.address);
        self.by_token.entry(p.token1).or_default().push(p.address);
        self.pairs.insert(p.address, p);
    }

    /// Fork barato: copia solo los pares tocados por la tx victima
    pub fn fork(&self, touched: &[[u8; 20]]) -> HashMap<[u8; 20], PairState> {
        touched.iter().filter_map(|a| self.pairs.get(a).map(|p| (*a, *p))).collect()
    }
}

// ------------------------------------------------------------------
// Ruta de arbitraje y evaluacion
// ------------------------------------------------------------------
#[derive(Clone, Debug)]
pub struct Hop {
    pub pair: [u8; 20],
    pub zero_for_one: bool,
}

#[derive(Clone, Debug)]
pub struct ArbRoute {
    pub hops: Vec<Hop>,
    pub token_in: [u8; 20],
    pub amount_in: u128,
}

#[derive(Debug)]
pub struct ArbEvaluation {
    pub profit_gross: u128,
    pub energy_cost_usdt: u128,
    pub bribe_usdt: u128,
    pub profit_net: u128,
    pub profitable: bool,
}

/// Simula la ruta sobre un fork de pares: retorna amount_out final
pub fn simulate_route(
    fork: &HashMap<[u8; 20], PairState>,
    route: &ArbRoute,
) -> Option<u128> {
    let mut amount = route.amount_in;
    for hop in &route.hops {
        let pair = fork.get(&hop.pair)?;
        amount = pair.get_amount_out(amount, hop.zero_for_one)?;
    }
    Some(amount)
}

/// Busqueda greedy de monto optimo (aprox. Newton sobre la curva AMM):
/// maximiza f(x) = out(x) - x acotando a [lo, hi] por biseccion ternaria.
pub fn optimal_amount_in(
    fork: &HashMap<[u8; 20], PairState>,
    route: &ArbRoute,
    lo: u128,
    hi: u128,
) -> Option<(u128, u128)> {
    let profit = |x: u128| -> Option<u128> {
        simulate_route(fork, &ArbRoute { amount_in: x, ..route.clone() })?.checked_sub(x)
    };
    let mut a = lo;
    let mut b = hi;
    for _ in 0..64 {
        if b - a <= 1_000 { break; } // precision 0.001 USDT suficiente
        let m1 = a + (b - a) / 3;
        let m2 = b - (b - a) / 3;
        let p1 = profit(m1).unwrap_or(0);
        let p2 = profit(m2).unwrap_or(0);
        if p1 < p2 { a = m1; } else { b = m2; }
    }
    let best = (a + b) / 2;
    profit(best).map(|p| (best, p))
}

/// Evaluacion economica completa de una ruta
pub fn evaluate_route(
    fork: &HashMap<[u8; 20], PairState>,
    route: &ArbRoute,
) -> Option<ArbEvaluation> {
    let out = simulate_route(fork, route)?;
    let profit_gross = out.checked_sub(route.amount_in)?;
    let energy_cost_usdt = EST_ENERGY_PER_SWAP * route.hops.len() as u128 * ENERGY_PRICE_SUN / 1_000; // SUN->USDT aprox via oracle interno
    let bribe = profit_gross * BRIBE_BPS_OF_PROFIT / 10_000;
    let profit_net = profit_gross.checked_sub(energy_cost_usdt + bribe)?;
    Some(ArbEvaluation {
        profit_gross,
        energy_cost_usdt,
        bribe_usdt: bribe,
        profit_net,
        profitable: profit_net >= MIN_PROFIT_USDT,
    })
}

// ------------------------------------------------------------------
// Constructor de rutas: triangular A->B->C->A sobre los pares shadow
// ------------------------------------------------------------------
pub fn build_triangular_routes(
    state: &ShadowState,
    start_token: [u8; 20],
) -> Vec<ArbRoute> {
    let mut routes = Vec::with_capacity(64);
    let empty = Vec::new();
    let first_pairs = state.by_token.get(&start_token).unwrap_or(&empty);

    for p1_addr in first_pairs {
        let p1 = match state.pairs.get(p1_addr) { Some(p) => p, None => continue };
        let t_b = if p1.token0 == start_token { p1.token1 } else { p1.token0 };
        let z1 = p1.token0 == start_token;

        let second_pairs = state.by_token.get(&t_b).unwrap_or(&empty);
        for p2_addr in second_pairs {
            if p2_addr == p1_addr { continue; }
            let p2 = match state.pairs.get(p2_addr) { Some(p) => p, None => continue };
            let t_c = if p2.token0 == t_b { p2.token1 } else { p2.token0 };
            if t_c == start_token { continue; }
            let z2 = p2.token0 == t_b;

            let third_pairs = state.by_token.get(&t_c).unwrap_or(&empty);
            for p3_addr in third_pairs {
                if p3_addr == p1_addr || p3_addr == p2_addr { continue; }
                let p3 = match state.pairs.get(p3_addr) { Some(p) => p, None => continue };
                let closes = (p3.token0 == t_c && p3.token1 == start_token)
                          || (p3.token1 == t_c && p3.token0 == start_token);
                if !closes { continue; }
                let z3 = p3.token0 == t_c;
                routes.push(ArbRoute {
                    hops: vec![
                        Hop { pair: *p1_addr, zero_for_one: z1 },
                        Hop { pair: *p2_addr, zero_for_one: z2 },
                        Hop { pair: *p3_addr, zero_for_one: z3 },
                    ],
                    token_in: start_token,
                    amount_in: 0, // se resuelve con optimal_amount_in
                });
                if routes.len() >= 256 { return routes; }
            }
        }
    }
    routes
}

// ------------------------------------------------------------------
// Bundle (Flashbots-style para TRON: [victim, arb] al builder privado)
// ------------------------------------------------------------------
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Bundle {
    pub victim_txid: String,
    pub arb_calldata: Vec<u8>,
    pub route: Vec<[u8; 20]>,
    pub amount_in: u128,
    pub min_profit: u128,
    pub bribe: u128,
}

// ------------------------------------------------------------------
// gRPC: stream de la mempool del nodo TRON local
// ------------------------------------------------------------------
pub mod tron_grpc {
    // Proto generado por tonic-build desde protocol/api.proto (java-tron)
    tonic::include_proto!("protocol");
}

async fn mempool_stream(
    endpoint: &str,
    tx: mpsc::Sender<tron_grpc::Transaction>,
) -> Result<()> {
    let mut client = tron_grpc::wallet_client::WalletClient::connect(endpoint.to_string()).await?;
    let mut stream = client
        .get_pending_transactions(tron_grpc::EmptyMessage {})
        .await?
        .into_inner();

    while let Some(pending) = stream.message().await? {
        if tx.try_send(pending).is_err() {
            warn!("canal de mempool saturado — drop con contador");
        }
    }
    Ok(())
}

// ------------------------------------------------------------------
// Decoder de txs SunSwap (selector ABI de los 4 bytes)
// ------------------------------------------------------------------
const SEL_SWAP_EXACT_TOKENS: [u8; 4] = [0x38, 0xed, 0x17, 0x39]; // swapExactTokensForTokens
const SEL_SWAP_TOKENS_EXACT: [u8; 4] = [0x88, 0x03, 0xdb, 0xee]; // swapTokensForExactTokens

struct DecodedSwap {
    pair_path: Vec<[u8; 20]>,
    amount_in: u128,
    zero_for_one_first_hop: bool,
}

fn try_decode_sunswap(input: &[u8]) -> Option<DecodedSwap> {
    if input.len() < 4 + 32 * 5 { return None; }
    let sel: [u8; 4] = input[0..4].try_into().ok()?;
    if sel != SEL_SWAP_EXACT_TOKENS && sel != SEL_SWAP_TOKENS_EXACT { return None; }

    let amount_in = u128::from_be_bytes(input[4 + 16..4 + 32].try_into().ok()?);
    // path offset: ABI head es fija para esta firma (5 slots + array dinamico)
    let path_count = u32::from_be_bytes(input[4 + 32 * 5 + 28..4 + 32 * 6].try_into().ok()?) as usize;
    let mut path = Vec::with_capacity(path_count);
    let mut off = 4 + 32 * 6;
    for _ in 0..path_count.min(MAX_HOPS + 1) {
        if input.len() < off + 32 { return None; }
        path.push(input[off + 12..off + 32].try_into().ok()?);
        off += 32;
    }
    Some(DecodedSwap { pair_path: path, amount_in, zero_for_one_first_hop: true })
}

// ------------------------------------------------------------------
// Worker principal
// ------------------------------------------------------------------
#[tokio::main(flavor = "multi_thread", worker_threads = 8)]
async fn main() -> Result<()> {
    tracing_subscriber::fmt::init();
    let endpoint = std::env::var("TRON_GRPC").unwrap_or("grpc://127.0.0.1:50051".into());
    let builder_url = std::env::var("BUILDER_URL").context("BUILDER_URL requerido")?;

    let state = Arc::new(RwLock::new(ShadowState::new()));

    // Bootstrap del estado shadow: snapshot de reservas de pares observados
    {
        let mut st = state.write().await;
        let known_pairs: Vec<([u8; 20], [u8; 20], [u8; 20], u128, u128)> = vec![
            // (pair, token0, token1, reserve0, reserve1) — cargado via getPair on-chain en produccion
        ];
        for (pair, t0, t1, r0, r1) in known_pairs {
            st.upsert_pair(PairState { address: pair, token0: t0, token1: t1, reserve0: r0, reserve1: r1, fee_bps: 30 });
        }
        info!(pairs = st.pairs.len(), "shadow state bootstrapped");
    }

    let (mempool_tx, mut mempool_rx) = mpsc::channel(MEMPOOL_CHANNEL_CAP);
    let ep = endpoint.clone();
    tokio::spawn(async move {
        loop {
            if let Err(e) = mempool_stream(&ep, mempool_tx.clone()).await {
                warn!(error = %e, "mempool stream caido — reintentando en 2s");
                tokio::time::sleep(std::time::Duration::from_secs(2)).await;
            }
        }
    });

    let http = reqwest::Client::new();
    info!("mev sniper up");

    while let Some(pending) = mempool_rx.recv().await {
        let state = Arc::clone(&state);
        let http = http.clone();
        let builder_url = builder_url.clone();

        tokio::spawn(async move {
            let raw = pending
                .raw_data
                .and_then(|r| r.contract.into_iter().next())
                .and_then(|c| c.parameter)
                .map(|p| p.value)
                .unwrap_or_default();

            let Some(decoded) = try_decode_sunswap(&raw) else { return; };

            // 1. Fork shadow + aplicar la tx victima sobre el primer par
            let st = state.read().await;
            let touched: Vec<[u8; 20]> = decoded.pair_path.clone();
            let mut fork = st.fork(&touched);

            if let (Some(first), Some(out)) = (
                fork.get_mut(&decoded.pair_path[0]),
                fork.get(&decoded.pair_path[0])
                    .and_then(|p| p.get_amount_out(decoded.amount_in, decoded.zero_for_one_first_hop)),
            ) {
                first.apply_swap(decoded.amount_in, out, decoded.zero_for_one_first_hop);
            } else {
                return;
            }

            // 2. Evaluar rutas triangulares desde el token desplazado
            let usdt: [u8; 20] = hex_to_20("TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t"); // USDT TRC20 mainnet
            let routes = build_triangular_routes(&st, usdt);
            drop(st);

            for route in routes {
                let Some((optimal_in, _gross)) = optimal_amount_in(&fork, &route, 1_000_000, 10_000_000_000_000) else { continue; };
                let eval = match evaluate_route(&fork, &ArbRoute { amount_in: optimal_in, ..route.clone() }) {
                    Some(e) => e,
                    None => continue,
                };
                if !eval.profitable { continue; }

                let bundle = Bundle {
                    victim_txid: hex::encode(&pending.txid),
                    arb_calldata: encode_flasharb_calldata(&route, optimal_in, eval.profit_net),
                    route: route.hops.iter().map(|h| h.pair).collect(),
                    amount_in: optimal_in,
                    min_profit: eval.profit_net,
                    bribe: eval.bribe_usdt,
                };

                // 3. Emitir bundle al builder (back-run: incluye la tx victima)
                match http.post(format!("{builder_url}/v1/bundle"))
                    .json(&bundle)
                    .timeout(std::time::Duration::from_millis(800))
                    .send().await
                {
                    Ok(r) if r.status().is_success() => {
                        info!(profit_net = eval.profit_net, hops = route.hops.len(), "bundle aceptado");
                    }
                    Ok(r) => warn!(status = %r.status(), "builder rechazo bundle"),
                    Err(e) => warn!(error = %e, "builder unreachable"),
                }
                break; // una ruta ganadora por tx victima
            }
        });
    }
    Ok(())
}

fn hex_to_20(s: &str) -> [u8; 20] {
    let b = hex::decode(s).unwrap_or_else(|_| vec![0u8; 20]);
    let mut out = [0u8; 20];
    let n = b.len().min(20);
    out[20 - n..].copy_from_slice(&b[b.len() - n..]);
    out
}

fn encode_flasharb_calldata(route: &ArbRoute, amount_in: u128, min_profit: u128) -> Vec<u8> {
    // executeArb(address[] pairs, bool[] dirs, uint256 amountIn, uint256 minProfit)
    let mut data = Vec::with_capacity(4 + 32 * 6);
    data.extend_from_slice(&[0xde, 0xad, 0xbe, 0xef]); // selector del contrato FlashArb (placeholder deterministico)
    data.extend_from_slice(&amount_in.to_be_bytes());
    data.extend_from_slice(&min_profit.to_be_bytes());
    for hop in &route.hops {
        let mut addr = [0u8; 32];
        addr[12..].copy_from_slice(&hop.pair);
        data.extend_from_slice(&addr);
        data.extend_from_slice(&(hop.zero_for_one as u128).to_be_bytes());
    }
    data
}
