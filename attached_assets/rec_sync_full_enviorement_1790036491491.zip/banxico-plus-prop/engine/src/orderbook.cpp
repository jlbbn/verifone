// ==============================================================
// Banxico-Plus Prop — HFT Matching Engine (C++20)
// Limit Order Book lock-free, zero-allocation en hot path,
// cache-line aligned (L1=64B), SPSC/MPSC ring buffers atomicos.
// Objetivo: 10M TPS single-threaded core loop (sin GC, sin RTTI,
// sin excepciones en el path caliente, sin syscalls).
// ==============================================================

#include <atomic>
#include <array>
#include <cstdint>
#include <cstddef>
#include <bit>
#include <immintrin.h>

namespace bx {

// --------------------------------------------------------------
// Constantes de plataforma
// --------------------------------------------------------------
inline constexpr std::size_t CACHE_LINE   = 64;
inline constexpr std::size_t MAX_LEVELS   = 4096;      // niveles de precio por lado
inline constexpr std::size_t POOL_ORDERS  = 1 << 20;   // 1M ordenes pre-alojadas
inline constexpr std::size_t RING_SIZE    = 1 << 16;   // 65,536 slots (potencia de 2)
inline constexpr std::size_t RING_MASK    = RING_SIZE - 1;

using Price  = std::int64_t;   // precio en ticks (1e-6 MXN/USDT)
using Qty    = std::int64_t;   // cantidad en unidades minimas
using OrderId= std::uint64_t;
enum class Side : std::uint8_t { BID = 0, ASK = 1 };

// --------------------------------------------------------------
// Mensajes del wire (tamaño fijo, POD, alineados a cache line)
// --------------------------------------------------------------
struct alignas(CACHE_LINE) OrderMsg {
    OrderId  id;
    Price    price;
    Qty      qty;
    Side     side;
    std::uint8_t  op;          // 0=new, 1=cancel, 2=replace
    std::uint8_t  _pad[6];
};
static_assert(sizeof(OrderMsg) == CACHE_LINE / 2);

struct alignas(CACHE_LINE) TradeMsg {
    OrderId  maker_id;
    OrderId  taker_id;
    Price    price;
    Qty      qty;
    std::uint64_t ts_ns;
};
static_assert(sizeof(TradeMsg) <= CACHE_LINE);

// --------------------------------------------------------------
// SPSC Ring Buffer — lock-free, wait-free en push/pop
// Un productor (gateway), un consumidor (matching core).
// Cache-line padding entre head/tail: elimina false sharing.
// --------------------------------------------------------------
template <typename T, std::size_t N>
class SpscRing {
    static_assert(std::has_single_bit(N));
public:
    SpscRing() = default;
    SpscRing(const SpscRing&) = delete;
    SpscRing& operator=(const SpscRing&) = delete;

    // Productor: retorna slot o nullptr si lleno (nunca bloquea)
    T* try_claim_write() noexcept {
        const auto h = head_.load(std::memory_order_relaxed);
        const auto next = (h + 1) & (N - 1);
        if (next == tail_.load(std::memory_order_acquire)) return nullptr;
        write_cache_ = h;
        return &buf_[h];
    }
    void commit_write() noexcept {
        head_.store((write_cache_ + 1) & (N - 1), std::memory_order_release);
    }

    // Consumidor
    const T* try_read() noexcept {
        const auto t = tail_.load(std::memory_order_relaxed);
        if (t == head_.load(std::memory_order_acquire)) return nullptr;
        read_cache_ = t;
        return &buf_[t];
    }
    void commit_read() noexcept {
        tail_.store((read_cache_ + 1) & (N - 1), std::memory_order_release);
    }

private:
    alignas(CACHE_LINE) std::atomic<std::size_t> head_{0};
    alignas(CACHE_LINE) std::atomic<std::size_t> tail_{0};
    alignas(CACHE_LINE) std::array<T, N> buf_{};
    std::size_t write_cache_{0};
    std::size_t read_cache_{0};
};

// --------------------------------------------------------------
// Pool de ordenes — zero-allocation: slab estatico + free-list
// intrusive. Toda la memoria se reserva en arranque (2MB arena,
// hugepages recomendadas: 2MB pages via mmap hugetlbfs).
// --------------------------------------------------------------
struct OrderNode {
    OrderId  id;
    Price    price;
    Qty      qty;
    Side     side;
    OrderNode* next;      // lista por nivel de precio (FIFO price-time)
    OrderNode* prev;
    OrderNode* next_free; // free-list intrusiva
};

class OrderPool {
public:
    OrderPool() noexcept {
        for (std::size_t i = 0; i < POOL_ORDERS - 1; ++i)
            arena_[i].next_free = &arena_[i + 1];
        arena_[POOL_ORDERS - 1].next_free = nullptr;
        free_head_ = &arena_[0];
    }

    OrderNode* acquire() noexcept {
        OrderNode* n = free_head_;
        if (__builtin_expect(n == nullptr, 0)) return nullptr; // pool exhausto
        free_head_ = n->next_free;
        return n;
    }
    void release(OrderNode* n) noexcept {
        n->next_free = free_head_;
        free_head_ = n;
    }

private:
    alignas(CACHE_LINE) std::array<OrderNode, POOL_ORDERS> arena_{};
    OrderNode* free_head_{nullptr};
};

// --------------------------------------------------------------
// Nivel de precio: cola FIFO doble-ligada (price-time priority)
// --------------------------------------------------------------
struct PriceLevel {
    Qty        total_qty{0};
    OrderNode* head{nullptr};
    OrderNode* tail{nullptr};

    inline void push_back(OrderNode* o) noexcept {
        o->prev = tail;
        o->next = nullptr;
        if (tail) tail->next = o; else head = o;
        tail = o;
        total_qty += o->qty;
    }
    inline void remove(OrderNode* o) noexcept {
        if (o->prev) o->prev->next = o->next; else head = o->next;
        if (o->next) o->next->prev = o->prev; else tail = o->prev;
        total_qty -= o->qty;
    }
    inline bool empty() const noexcept { return head == nullptr; }
};

// --------------------------------------------------------------
// Limit Order Book
// Indexacion directa: precio -> nivel via array plano (O(1),
// sin arboles ni hashing; requiere rango de precios acotado,
// estandar en venues HFT: price = base + idx*tick).
// Bitmap de 4096 bits por lado => best bid/ask en O(1) con TZCNT.
// --------------------------------------------------------------
class OrderBook {
public:
    explicit OrderBook(Price price_min, Price tick) noexcept
        : price_min_(price_min), tick_(tick) {}

    // ---- NEW ORDER: matching agresivo primero (taker), resto a book (maker)
    template <typename EmitTrade>
    inline void add(const OrderMsg& m, EmitTrade&& emit) noexcept {
        OrderNode* rest = nullptr;
        Qty remaining = m.qty;

        if (m.side == Side::BID) {
            remaining = match_against(m.id, remaining, m.price, Side::ASK, emit);
        } else {
            remaining = match_against(m.id, remaining, m.price, Side::BID, emit);
        }

        if (remaining > 0) {
            OrderNode* n = pool_.acquire();
            if (__builtin_expect(n == nullptr, 0)) return; // rechazo: pool lleno
            n->id = m.id; n->price = m.price; n->qty = remaining; n->side = m.side;
            const std::size_t idx = level_index(m.price);
            if (m.side == Side::BID) {
                bids_[idx].push_back(n);
                bid_bits_.set(idx);
            } else {
                asks_[idx].push_back(n);
                ask_bits_.set(idx);
            }
            locator_[m.id % POOL_ORDERS] = n; // indice id->nodo para cancel O(1)
            if (rest) (void)rest;
        }
    }

    // ---- CANCEL: O(1) via locator
    inline void cancel(OrderId id) noexcept {
        OrderNode* n = locator_[id % POOL_ORDERS];
        if (__builtin_expect(n == nullptr || n->id != id, 0)) return;
        const std::size_t idx = level_index(n->price);
        if (n->side == Side::BID) {
            bids_[idx].remove(n);
            if (bids_[idx].empty()) bid_bits_.clear(idx);
        } else {
            asks_[idx].remove(n);
            if (asks_[idx].empty()) ask_bits_.clear(idx);
        }
        pool_.release(n);
        locator_[id % POOL_ORDERS] = nullptr;
    }

    // ---- Top of book
    inline Price best_bid() const noexcept {
        const int i = bid_bits_.highest();
        return i < 0 ? 0 : index_price(static_cast<std::size_t>(i));
    }
    inline Price best_ask() const noexcept {
        const int i = ask_bits_.lowest();
        return i < 0 ? 0 : index_price(static_cast<std::size_t>(i));
    }

private:
    // Matching agresivo: barre niveles del lado contrario mientras cruza
    template <typename EmitTrade>
    inline Qty match_against(OrderId taker, Qty qty, Price limit, Side contra, EmitTrade& emit) noexcept {
        auto& levels = (contra == Side::ASK) ? asks_ : bids_;
        auto& bits   = (contra == Side::ASK) ? ask_bits_ : bid_bits_;

        while (qty > 0) {
            const int li = (contra == Side::ASK) ? bits.lowest() : bits.highest();
            if (li < 0) break;
            const Price p = index_price(static_cast<std::size_t>(li));
            // price check: bid taker no paga mas de limit; ask taker no vende por menos
            if (contra == Side::ASK && limit < p) break;
            if (contra == Side::BID && limit > p) break;

            PriceLevel& lvl = levels[li];
            while (qty > 0 && lvl.head) {
                OrderNode* maker = lvl.head;
                const Qty fill = (qty < maker->qty) ? qty : maker->qty;
                emit(TradeMsg{maker->id, taker, p, fill, rdtsc_ns()});
                maker->qty -= fill;
                qty -= fill;
                if (maker->qty == 0) {
                    lvl.remove(maker);
                    locator_[maker->id % POOL_ORDERS] = nullptr;
                    pool_.release(maker);
                }
            }
            if (lvl.empty()) bits.clear(static_cast<std::size_t>(li));
        }
        return qty;
    }

    inline std::size_t level_index(Price p) const noexcept {
        return static_cast<std::size_t>((p - price_min_) / tick_);
    }
    inline Price index_price(std::size_t i) const noexcept {
        return price_min_ + static_cast<Price>(i) * tick_;
    }

    // Timestamp de ciclo de CPU (TSC): ~20ns, sin syscall
    static inline std::uint64_t rdtsc_ns() noexcept {
        return __rdtsc();
    }

    // ---- Bitmap 4096 bits con TZCNT/LZCNT ----
    struct alignas(CACHE_LINE) LevelBits {
        std::array<std::uint64_t, MAX_LEVELS / 64> w{};

        inline void set(std::size_t i) noexcept   { w[i >> 6] |=  (1ULL << (i & 63)); }
        inline void clear(std::size_t i) noexcept { w[i >> 6] &= ~(1ULL << (i & 63)); }

        inline int lowest() const noexcept {           // mejor ASK (precio menor)
            for (std::size_t k = 0; k < w.size(); ++k)
                if (w[k]) return static_cast<int>(k * 64 + std::countr_zero(w[k]));
            return -1;
        }
        inline int highest() const noexcept {          // mejor BID (precio mayor)
            for (std::size_t k = w.size(); k-- > 0;)
                if (w[k]) return static_cast<int>(k * 64 + 63 - std::countl_zero(w[k]));
            return -1;
        }
    };

    Price price_min_;
    Price tick_;
    alignas(CACHE_LINE) std::array<PriceLevel, MAX_LEVELS> bids_{};
    alignas(CACHE_LINE) std::array<PriceLevel, MAX_LEVELS> asks_{};
    LevelBits bid_bits_{};
    LevelBits ask_bits_{};
    alignas(CACHE_LINE) std::array<OrderNode*, POOL_ORDERS> locator_{};
    OrderPool pool_{};
};

// --------------------------------------------------------------
// Core loop — pinning de hilo + busy-spin con pausa de hiperthread
// Aislar el core: isolcpus=3 nohz_full=3 rcu_nocbs=3 (GRUB)
//   taskset -c 3 ./matching_engine
// --------------------------------------------------------------
class MatchingCore {
public:
    MatchingCore(SpscRing<OrderMsg, RING_SIZE>& in,
                 SpscRing<TradeMsg, RING_SIZE>& out,
                 Price price_min, Price tick) noexcept
        : in_(in), out_(out), book_(price_min, tick) {}

    void run() noexcept {
        auto emit = [this](const TradeMsg& t) noexcept {
            // retry bounded: el consumidor downstream NUNCA debe
            // quedarse atras; si lo hace, drop con contador (no backpressure al book)
            for (int spins = 0; spins < 1024; ++spins) {
                if (TradeMsg* slot = out_.try_claim_write()) {
                    *slot = t;
                    out_.commit_write();
                    return;
                }
                _mm_pause(); // cede el pipeline al HT sibling
            }
            dropped_trades_.fetch_add(1, std::memory_order_relaxed);
        };

        for (;;) {
            if (const OrderMsg* m = in_.try_read()) {
                OrderMsg local = *m;   // copia a stack: libera el slot YA
                in_.commit_read();
                if (__builtin_expect(local.op == 0, 1)) {
                    book_.add(local, emit);
                } else if (local.op == 1) {
                    book_.cancel(local.id);
                }
            } else {
                _mm_pause();
            }
        }
    }

    std::atomic<std::uint64_t> dropped_trades_{0};

private:
    SpscRing<OrderMsg, RING_SIZE>& in_;
    SpscRing<TradeMsg, RING_SIZE>& out_;
    OrderBook book_;
};

} // namespace bx

// --------------------------------------------------------------
// main: wiring de anillos + afinidad (Linux)
// --------------------------------------------------------------
#ifdef BX_HFT_MAIN
#include <pthread.h>
#include <sched.h>
#include <cstdio>

int main() {
    static bx::SpscRing<bx::OrderMsg, bx::RING_SIZE> ingress;
    static bx::SpscRing<bx::TradeMsg, bx::RING_SIZE> egress;

    cpu_set_t set;
    CPU_ZERO(&set);
    CPU_SET(3, &set);
    pthread_setaffinity_np(pthread_self(), sizeof(set), &set);

    bx::MatchingCore core(ingress, egress, 10'000'000, 1'000); // 10.00 MXN, tick 0.0001
    core.run();
    return 0;
}
#endif
