//! AI Liquidity Predictor — Transformer de series temporales (Candle).
//! Prediccion dual: (a) congestion de red / gas spikes (energy price TRON),
//! (b) FX slippage esperado MXN/USDT a horizonte H.
//!
//! Arquitectura: encoder-only Transformer con SLIDING WINDOW ATTENTION
//! (cada token atiende solo a los W anteriores — O(n·W) en vez de O(n²),
//! estilo Longformer). Implementada con mascara aditiva -inf fuera de ventana.

use candle_core::{DType, Device, Result, Tensor, D};
use candle_nn::{self as nn, linear, layer_norm, Dropout, Linear, LayerNorm, Module, VarBuilder};

// ------------------------------------------------------------------
// Hiperparametros
// ------------------------------------------------------------------
#[derive(Clone, Debug)]
pub struct PredictorConfig {
    pub seq_len: usize,        // longitud de la ventana de entrada (ej. 512 ticks)
    pub d_model: usize,        // dimension del embedding (ej. 128)
    pub n_heads: usize,        // cabezas de atencion (ej. 8)
    pub n_layers: usize,       // bloques transformer (ej. 4)
    pub d_ff: usize,           // feed-forward interno (4*d_model)
    pub window: usize,         // sliding window W (ej. 64)
    pub n_features: usize,     // features de entrada por tick
    pub horizon: usize,        // pasos a predecir (ej. 12 ticks adelante)
    pub dropout: f32,
}

impl Default for PredictorConfig {
    fn default() -> Self {
        Self {
            seq_len: 512,
            d_model: 128,
            n_heads: 8,
            n_layers: 4,
            d_ff: 512,
            window: 64,
            n_features: 10,
            horizon: 12,
            dropout: 0.1,
        }
    }
}

// Features por tick (normalizadas z-score upstream):
//   [0] energy_price_sun        [1] pending_tx_count
//   [2] block_utilization       [3] usdt_trx_spot
//   [4] mxn_usdt_rate           [5] orderbook_imbalance
//   [6] avg_swap_size_1m        [7] volatility_ewma
//   [8] hour_of_day_sin         [9] hour_of_day_cos

// ------------------------------------------------------------------
// Mascara de sliding window: [1, 1, seq, seq], 0 en ventana, -1e9 fuera
// token i atiende a j si (i - W) < j <= i
// ------------------------------------------------------------------
fn sliding_window_mask(seq: usize, window: usize, device: &Device) -> Result<Tensor> {
    let mut m = vec![f32::NEG_INFINITY; seq * seq];
    for i in 0..seq {
        let lo = i.saturating_sub(window);
        for j in lo..=i {
            m[i * seq + j] = 0.0;
        }
    }
    Tensor::from_vec(m, (1, 1, seq, seq), device)
}

// ------------------------------------------------------------------
// Codificacion posicional senoidal (sin parametros aprendibles)
// ------------------------------------------------------------------
fn sinusoidal_pe(seq: usize, d_model: usize, device: &Device) -> Result<Tensor> {
    let half = d_model / 2;
    let mut pe = vec![0f32; seq * d_model];
    for pos in 0..seq {
        for i in 0..half {
            let w = (pos as f32) / 10_000f32.powf(2.0 * i as f32 / d_model as f32);
            pe[pos * d_model + 2 * i] = w.sin();
            pe[pos * d_model + 2 * i + 1] = w.cos();
        }
    }
    Tensor::from_vec(pe, (1, seq, d_model), device)
}

// ------------------------------------------------------------------
// Multi-Head Self-Attention con sliding window
// ------------------------------------------------------------------
struct SlidingWindowAttention {
    q: Linear,
    k: Linear,
    v: Linear,
    o: Linear,
    n_heads: usize,
    head_dim: usize,
    scale: f64,
    dropout: Dropout,
}

impl SlidingWindowAttention {
    fn new(cfg: &PredictorConfig, vb: VarBuilder) -> Result<Self> {
        let d = cfg.d_model;
        Ok(Self {
            q: linear(d, d, vb.pp("q"))?,
            k: linear(d, d, vb.pp("k"))?,
            v: linear(d, d, vb.pp("v"))?,
            o: linear(d, d, vb.pp("o"))?,
            n_heads: cfg.n_heads,
            head_dim: d / cfg.n_heads,
            scale: 1.0 / ((d / cfg.n_heads) as f64).sqrt(),
            dropout: Dropout::new(cfg.dropout),
        })
    }

    // x: [B, T, D] -> [B, T, D]
    fn forward(&self, x: &Tensor, mask: &Tensor, train: bool) -> Result<Tensor> {
        let (b, t, d) = x.dims3()?;
        let h = self.n_heads;
        let hd = self.head_dim;

        // proyeccion + reshape a cabezas: [B, H, T, hd]
        let shape = |t: Tensor| -> Result<Tensor> {
            t.reshape((b, t, h, hd))?.transpose(1, 2)?.contiguous()
        };
        let q = shape(self.q.forward(x)?)?;
        let k = shape(self.k.forward(x)?)?;
        let v = shape(self.v.forward(x)?)?;

        // scores = QK^T * scale + mascara (broadcast [1,1,T,T] sobre [B,H,T,T])
        let scores = (q.matmul(&k.t()?)? * self.scale)?;
        let scores = scores.broadcast_add(mask)?;
        let attn = candle_nn::ops::softmax_last_dim(&scores)?;
        let attn = self.dropout.forward(&attn, train)?;

        // contexto y proyeccion de salida
        let ctx = attn.matmul(&v)?;                     // [B, H, T, hd]
        let ctx = ctx.transpose(1, 2)?.reshape((b, t, d))?;
        self.o.forward(&ctx)
    }
}

// ------------------------------------------------------------------
// Bloque Transformer pre-norm (mas estable que post-norm)
// ------------------------------------------------------------------
struct EncoderBlock {
    ln1: LayerNorm,
    attn: SlidingWindowAttention,
    ln2: LayerNorm,
    ff1: Linear,
    ff2: Linear,
    dropout: Dropout,
}

impl EncoderBlock {
    fn new(cfg: &PredictorConfig, vb: VarBuilder) -> Result<Self> {
        Ok(Self {
            ln1: layer_norm(cfg.d_model, 1e-5, vb.pp("ln1"))?,
            attn: SlidingWindowAttention::new(cfg, vb.pp("attn"))?,
            ln2: layer_norm(cfg.d_model, 1e-5, vb.pp("ln2"))?,
            ff1: linear(cfg.d_model, cfg.d_ff, vb.pp("ff1"))?,
            ff2: linear(cfg.d_ff, cfg.d_model, vb.pp("ff2"))?,
            dropout: Dropout::new(cfg.dropout),
        })
    }

    fn forward(&self, x: &Tensor, mask: &Tensor, train: bool) -> Result<Tensor> {
        // x + Attn(LN(x))
        let h = self.ln1.forward(x)?;
        let h = self.attn.forward(&h, mask, train)?;
        let x = (x + self.dropout.forward(&h, train))?;
        // x + FFN(LN(x))
        let h = self.ln2.forward(&x)?;
        let h = self.ff1.forward(&h)?.gelu()?;
        let h = self.ff2.forward(&h)?;
        let x = (x + self.dropout.forward(&h, train))?;
        Ok(x)
    }
}

// ------------------------------------------------------------------
// Modelo completo: proyeccion de features + N bloques + 2 cabezas
// ------------------------------------------------------------------
pub struct LiquidityTransformer {
    input_proj: Linear,
    blocks: Vec<EncoderBlock>,
    ln_final: LayerNorm,
    head_gas: Linear,      // [d_model] -> [horizon] energy price predicho
    head_slip: Linear,     // [d_model] -> [horizon] slippage predicho (bps)
    pe: Tensor,
    mask: Tensor,
}

pub struct Predictions {
    pub gas_spike: Tensor,     // [B, horizon] log-energy-price predicho
    pub fx_slippage: Tensor,   // [B, horizon] slippage predicho en bps
}

impl LiquidityTransformer {
    pub fn new(cfg: &PredictorConfig, vb: VarBuilder) -> Result<Self> {
        let input_proj = linear(cfg.n_features, cfg.d_model, vb.pp("input_proj"))?;
        let mut blocks = Vec::with_capacity(cfg.n_layers);
        for i in 0..cfg.n_layers {
            blocks.push(EncoderBlock::new(cfg, vb.pp(&format!("layer{i}")))?);
        }
        let ln_final = layer_norm(cfg.d_model, 1e-5, vb.pp("ln_final"))?;
        let head_gas = linear(cfg.d_model, cfg.horizon, vb.pp("head_gas"))?;
        let head_slip = linear(cfg.d_model, cfg.horizon, vb.pp("head_slip"))?;
        let pe = sinusoidal_pe(cfg.seq_len, cfg.d_model, vb.device())?;
        let mask = sliding_window_mask(cfg.seq_len, cfg.window, vb.device())?;
        Ok(Self { input_proj, blocks, ln_final, head_gas, head_slip, pe, mask })
    }

    // x: [B, seq_len, n_features] normalizado z-score
    pub fn forward(&self, x: &Tensor, train: bool) -> Result<Predictions> {
        let mut h = self.input_proj.forward(x)?;
        h = h.broadcast_add(&self.pe)?;
        for blk in &self.blocks {
            h = blk.forward(&h, &self.mask, train)?;
        }
        h = self.ln_final.forward(&h)?;

        // Pooling: ultimo token (con sliding window ya agrego el contexto util)
        let last = h.narrow(1, h.dim(1)? - 1, 1)?.squeeze(1)?; // [B, d_model]
        Ok(Predictions {
            gas_spike: self.head_gas.forward(&last)?,
            fx_slippage: self.head_slip.forward(&last)?,
        })
    }
}

// ------------------------------------------------------------------
// Perdida combinada: MSE gas + Huber slippage (robusta a outliers)
// ------------------------------------------------------------------
pub fn combined_loss(pred: &Predictions, tgt_gas: &Tensor, tgt_slip: &Tensor) -> Result<Tensor> {
    let mse = (pred.gas_spike.sub(tgt_gas)?)?.sqr()?.mean_all()?;
    // Huber(delta=1.0): 0.5e^2 si |e|<1 else |e|-0.5
    let err = pred.fx_slippage.sub(tgt_slip)?;
    let abs = err.abs()?;
    let quad = (err.sqr()? * 0.5)?;
    let lin = (abs.sub(&abs.ones_like()? * 0.5))?;
    let is_small = abs.le(&abs.ones_like()?)?.to_dtype(DType::F32)?;
    let huber = ((quad.mul(&is_small)?) + (lin.mul(&(is_small.ones_like()? - is_small)?))?)?
        .mean_all()?;
    mse + huber
}

// ------------------------------------------------------------------
// Loop de entrenamiento (AdamW, cosine decay con warmup)
// ------------------------------------------------------------------
pub struct Trainer {
    pub model: LiquidityTransformer,
    pub cfg: PredictorConfig,
}

impl Trainer {
    pub fn new(cfg: PredictorConfig, device: &Device) -> Result<(Self, candle_nn::VarMap)> {
        let varmap = candle_nn::VarMap::new();
        let vb = VarBuilder::from_varmap(&varmap, DType::F32, device);
        let model = LiquidityTransformer::new(&cfg, vb)?;
        Ok((Self { model, cfg }, varmap))
    }

    /// steps de entrenamiento sobre batches (features, tgt_gas, tgt_slip)
    pub fn train_steps(
        &mut self,
        varmap: &candle_nn::VarMap,
        batches: &[(Tensor, Tensor, Tensor)],
        lr_peak: f64,
    ) -> Result<()> {
        let mut opt = candle_nn::AdamW::new_lr(varmap.all_vars(), lr_peak)?;
        let warmup = 100usize.max(batches.len() / 10);
        for (step, (x, tg, ts)) in batches.iter().enumerate() {
            // cosine schedule con warmup lineal
            let lr = if step < warmup {
                lr_peak * step as f64 / warmup as f64
            } else {
                let p = (step - warmup) as f64 / (batches.len() - warmup).max(1) as f64;
                lr_peak * 0.5 * (1.0 + (std::f64::consts::PI * p).cos())
            };
            opt.set_learning_rate(lr);

            let pred = self.model.forward(x, true)?;
            let loss = combined_loss(&pred, tg, ts)?;
            opt.backward_step(&loss)?;

            if step % 50 == 0 {
                let lv: f32 = loss.to_scalar()?;
                candle_core::safetensors::save(&varmap.all_vars(), "checkpoints/latest.safetensors")
                    .unwrap_or(());
                println!("step={step} lr={lr:.2e} loss={lv:.5}");
            }
        }
        Ok(())
    }
}

// ------------------------------------------------------------------
// Inferencia en linea (consumida por el sniper y el recon engine)
// ------------------------------------------------------------------
pub struct InferenceSession {
    model: LiquidityTransformer,
    device: Device,
}

pub struct LiquidityForecast {
    pub gas_spike_prob_next_h: f32,   // P(energy price > umbral) proxy: max predicho
    pub expected_slippage_bps: f32,   // slippage medio del horizonte
    pub horizon_gas: Vec<f32>,
    pub horizon_slip: Vec<f32>,
}

impl InferenceSession {
    pub fn load(cfg: PredictorConfig, weights: &str, device: Device) -> Result<Self> {
        let mut varmap = candle_nn::VarMap::new();
        varmap.load(weights)?;
        let vb = VarBuilder::from_varmap(&varmap, DType::F32, &device);
        let model = LiquidityTransformer::new(&cfg, vb)?;
        Ok(Self { model, device })
    }

    /// window: [1, seq_len, n_features] — ultimo tick al final
    pub fn predict(&self, window: &Tensor) -> Result<LiquidityForecast> {
        let pred = self.model.forward(&window.to_device(&self.device)?, false)?;
        let gas: Vec<f32> = pred.gas_spike.to_vec2::<f32>()?.into_iter().next().unwrap_or_default();
        let slip: Vec<f32> = pred.fx_slippage.to_vec2::<f32>()?.into_iter().next().unwrap_or_default();
        Ok(LiquidityForecast {
            gas_spike_prob_next_h: gas.iter().cloned().fold(f32::MIN, f32::max),
            expected_slippage_bps: if slip.is_empty() { 0.0 } else { slip.iter().sum::<f32>() / slip.len() as f32 },
            horizon_gas: gas,
            horizon_slip: slip,
        })
    }
}
