// ==============================================================
// server/workers/recon-engine.ts — ETL Pesado de Conciliación
// Ingiere Settlement Reports (Stripe / MercadoPago) por lotes,
// cruza contra transactions y contabiliza en el ledger inmutable.
// Diseñado para correr horas: streaming por línea + batches.
// Casos límite:
//   1. FEE_MISMATCH     — comisiones dinámicas (TRON network vs Fiat %)
//   2. FX_SLIPPAGE      — tipo de cambio captura vs liquidación
//   3. ORPHAN_*         — cobrado en procesador sin tx interna / viceversa
// ==============================================================
import { db } from "../db";
import { createReadStream, readdirSync, renameSync, existsSync, mkdirSync } from "node:fs";
import { createInterface } from "node:readline";
import { join, basename } from "node:path";
import { randomUUID } from "node:crypto";
import { sql } from "drizzle-orm";

// ---- Config (variables a modificar por entorno) ----
const SETTLEMENT_DIR   = process.env.SETTLEMENT_DIR   ?? "./settlements/incoming";
const PROCESSED_DIR    = process.env.PROCESSED_DIR    ?? "./settlements/processed";
const FAILED_DIR       = process.env.FAILED_DIR       ?? "./settlements/failed";
const BATCH_SIZE       = 500;              // líneas de settlement por batch SQL
const POLL_INTERVAL_MS = 60_000;           // barrido de directorio (ETL continuo)
const AMOUNT_TOLERANCE = 0.01;             // umbral de descuadre monetario
const FEE_TOLERANCE    = 0.005;            // 0.5% relativo sobre comisión esperada
const FX_TOLERANCE     = 0.01;             // $0.01 MXN por slippage

// ---- Modelos de comisión (fuente: contratos con procesadores) ----
interface FeeModel { pct: number; fixed: number; currency: string }
const FIAT_FEES: Record<string, FeeModel> = {
  STRIPE:      { pct: 0.036,  fixed: 3.00, currency: "MXN" }, // tarjetas MX domésticas
  MERCADOPAGO: { pct: 0.0355, fixed: 0.00, currency: "MXN" },
};
const TRON_NETWORK_FEE_USDT = { min: 0.3, max: 15.0 }; // bandwidth/energy: rango sano; fuera = anomalía

// ---- Tipos de settlement (CSV normalizado) ----
// Formato esperado (una línea por liquidación):
// provider,external_ref,gross_amount,fee_amount,net_amount,currency,
// capture_fx_rate,settlement_fx_rate,settled_at,tron_payout_ref
interface SettlementLine {
  provider: "STRIPE" | "MERCADOPAGO";
  externalRef: string;
  gross: number;
  fee: number;
  net: number;
  currency: string;
  captureFxRate: number | null;     // tipo de cambio al capturar
  settlementFxRate: number | null;  // tipo de cambio al liquidar
  settledAt: string;
  tronPayoutRef: string | null;     // txHash del payout cripto asociado
}

interface InternalTx {
  id: string;
  external_tx_id: string;
  provider: string;
  amount: string;          // NUMERIC llega como string — nunca parsear a float antes de comparar
  currency: string;
  status: string;
}

// ==============================================================
// LEDGER — posteo de asientos balanceados (idempotente)
// La unicidad (source, external_ref) + constraint trigger de
// balance en DB hacen segura la re-ejecución del ETL.
// ==============================================================
type Line = { account: string; debit?: number; credit?: number };

async function postEntry(
  tx: any,
  source: "STRIPE" | "MERCADOPAGO" | "TRON" | "RECON" | "FX" | "RESERVE",
  externalRef: string,
  description: string,
  lines: Line[],
  batchId: string,
): Promise<void> {
  const debit  = lines.reduce((s, l) => s + (l.debit  ?? 0), 0);
  const credit = lines.reduce((s, l) => s + (l.credit ?? 0), 0);
  if (Math.abs(debit - credit) > 1e-6) {
    throw new Error(`asiento desbalanceado en app: ${externalRef} D=${debit} C=${credit}`);
  }

  const inserted = await tx.execute(sql`
    INSERT INTO ledger.journal_entries (source, external_ref, description, recon_batch)
    VALUES (${source}, ${externalRef}, ${description}, ${batchId}::uuid)
    ON CONFLICT (source, external_ref) DO NOTHING
    RETURNING id
  `);
  const entryId = inserted.rows[0]?.id;
  if (!entryId) return; // ya contabilizado en corrida previa — idempotencia

  for (const l of lines) {
    await tx.execute(sql`
      INSERT INTO ledger.entry_lines (entry_id, account_code, debit, credit)
      VALUES (${entryId}::uuid, ${l.account}, ${l.debit ?? 0}, ${l.credit ?? 0})
    `);
  }
}

async function recordException(
  tx: any,
  batchId: string,
  kind: string,
  provider: string,
  externalRef: string,
  expected: number | null,
  actual: number | null,
  detail: object,
): Promise<void> {
  await tx.execute(sql`
    INSERT INTO ledger.recon_exceptions
      (batch_id, kind, provider, external_ref, expected_amt, actual_amt, delta, detail)
    VALUES (${batchId}::uuid, ${kind}, ${provider}, ${externalRef},
            ${expected}, ${actual},
            ${expected !== null && actual !== null ? actual - expected : null},
            ${JSON.stringify(detail)}::jsonb)
    ON CONFLICT (batch_id, kind, external_ref) DO NOTHING
  `);
}

// ==============================================================
// CASO LÍMITE 1 — Comisiones dinámicas
// Fiat: fee esperado = gross*pct + fixed. TRON: network fee en
// rango sano; fuera de rango = anomalía (congestión o drain).
// ==============================================================
async function reconcileFee(tx: any, batchId: string, line: SettlementLine): Promise<void> {
  const model = FIAT_FEES[line.provider];
  const expectedFee = round6(line.gross * model.pct + model.fixed);
  const relDiff = Math.abs(line.fee - expectedFee) / Math.max(expectedFee, 1e-6);

  // Contabilizar liquidación SIEMPRE a valores reales (el ledger refleja la realidad)
  const clearing = line.provider === "STRIPE" ? "stripe_clearing" : "mp_clearing";
  const feeAcct  = line.provider === "STRIPE" ? "fees_stripe"    : "fees_mp";
  await postEntry(tx, line.provider, `settle:${line.externalRef}`,
    `Liquidación ${line.provider} ${line.externalRef}`, [
      { account: clearing,        debit:  line.net },   // entra neto al clearing
      { account: feeAcct,         debit:  line.fee },   // comisión real cobrada
      { account: "user_balances", credit: line.gross }, // obligación bruta con el usuario
    ], batchId);

  if (relDiff > FEE_TOLERANCE) {
    await recordException(tx, batchId, "FEE_MISMATCH", line.provider, line.externalRef,
      expectedFee, line.fee, {
        gross: line.gross, expected_model: model, rel_diff: relDiff,
        hypothesis: "cambio de tarifa, IC++/interchange variable, o cargo de disputa embebido",
      });
  }
}

// Network fee TRON asociado al payout de la línea (si existe)
async function reconcileTronNetworkFee(
  tx: any, batchId: string, line: SettlementLine,
  tronFee: number | null,
): Promise<void> {
  if (tronFee === null) return;
  const inRange = tronFee >= TRON_NETWORK_FEE_USDT.min && tronFee <= TRON_NETWORK_FEE_USDT.max;
  if (!inRange) {
    await recordException(tx, batchId, "FEE_MISMATCH", "TRON", line.tronPayoutRef ?? line.externalRef,
      TRON_NETWORK_FEE_USDT.max, tronFee, {
        hypothesis: tronFee > TRON_NETWORK_FEE_USDT.max
          ? "congestión de energy o fee draining — revisar delegación de recursos"
          : "lectura corrupta del receipt del nodo",
      });
  }
  if (tronFee > 0) {
    await postEntry(tx, "TRON", `netfee:${line.tronPayoutRef}`,
      `Network fee TRON payout ${line.tronPayoutRef}`, [
        { account: "fees_tron_network", debit:  tronFee },
        { account: "tron_wallet",       credit: tronFee },
      ], batchId);
  }
}

// ==============================================================
// CASO LÍMITE 2 — Slippage cambiario
// Captura a tasa T0, liquidación a T1. La diferencia en MXN se
// reconoce como fx_loss / fx_gain (nunca se "absorbe" en silencio).
// ==============================================================
async function reconcileFx(tx: any, batchId: string, line: SettlementLine): Promise<void> {
  if (!line.captureFxRate || !line.settlementFxRate) return; // misma divisa: nada que medir

  const expectedMxn = round6(line.gross * line.captureFxRate);
  const settledMxn  = round6(line.gross * line.settlementFxRate);
  const slippage    = round6(settledMxn - expectedMxn);

  if (Math.abs(slippage) <= FX_TOLERANCE) return;

  // Asiento de reconocimiento: transit ↔ fx_loss/fx_gain
  const isLoss = slippage < 0;
  await postEntry(tx, "FX", `fx:${line.externalRef}`,
    `Slippage cambiario ${line.externalRef} T0=${line.captureFxRate} T1=${line.settlementFxRate}`, [
      isLoss
        ? { account: "fx_loss", debit: Math.abs(slippage) }
        : { account: "transit", debit: slippage },
      isLoss
        ? { account: "transit", credit: Math.abs(slippage) }
        : { account: "fx_gain", credit: slippage },
    ], batchId);

  await recordException(tx, batchId, "FX_SLIPPAGE", line.provider, line.externalRef,
    expectedMxn, settledMxn, {
      capture_fx: line.captureFxRate, settlement_fx: line.settlementFxRate,
      slippage_mxn: slippage,
      hypothesis: "latencia captura→payout del procesador; evaluar hedge o liquidación T+0",
    });
}

// ==============================================================
// CASO LÍMITE 3 — Huérfanos
// ORPHAN_SETTLEMENT: dinero real cobrado sin tx interna →
// suspense en transit, jamás se ignora.
// TRON_NOT_DISPATCHED: fiat cobrado, payout cripto ausente.
// ORPHAN_INTERNAL: tx CONFIRMED sin liquidación en el archivo.
// ==============================================================
async function reconcileOrphan(tx: any, batchId: string, line: SettlementLine): Promise<void> {
  await recordException(tx, batchId, "ORPHAN_SETTLEMENT", line.provider, line.externalRef,
    null, line.net, { gross: line.gross, settled_at: line.settledAt });

  // Contabilizar en suspense: el dinero existe y debe rastrearse
  const clearing = line.provider === "STRIPE" ? "stripe_clearing" : "mp_clearing";
  await postEntry(tx, "RECON", `orphan:${line.externalRef}`,
    `Liquidación huérfana ${line.provider} ${line.externalRef} — suspense`, [
      { account: clearing,  debit:  line.net },
      { account: "transit", credit: line.net },
    ], batchId);

  if (!line.tronPayoutRef) {
    await recordException(tx, batchId, "TRON_NOT_DISPATCHED", line.provider, line.externalRef,
      line.gross, null, {
        hypothesis: "cobro fiat OK, payout TRON jamás disparado — revisar tron-poller y signer",
      });
  }
}

// ==============================================================
// Núcleo del batch: cruzar N líneas settlement contra DB en 1 query
// ==============================================================
async function processBatch(batchId: string, lines: SettlementLine[]): Promise<void> {
  const refs = lines.map((l) => l.externalRef);

  await db.transaction(async (tx) => {
    // 1 lookup para todo el batch (evita N+1)
    const found = await tx.execute(sql`
      SELECT id, external_tx_id, provider, amount, currency, status
      FROM transactions
      WHERE external_tx_id = ANY(${refs}::varchar[])
        AND environment = 'mainnet'
    `);
    const byRef = new Map<string, InternalTx>(
      (found.rows as InternalTx[]).map((r) => [r.external_tx_id, r]),
    );

    // Network fees TRON del batch (receipts ya persistidos por el poller)
    const payoutRefs = lines.map((l) => l.tronPayoutRef).filter(Boolean) as string[];
    const tronFees = new Map<string, number>();
    if (payoutRefs.length) {
      const feeRows = await tx.execute(sql`
        SELECT external_tx_id, amount FROM transactions
        WHERE external_tx_id = ANY(${payoutRefs}::varchar[])
          AND provider = 'TRON' AND status = 'CONFIRMED'
      `);
      for (const r of feeRows.rows as any[]) tronFees.set(r.external_tx_id, Number(r.amount));
    }

    for (const line of lines) {
      const internal = byRef.get(line.externalRef);

      if (!internal) {
        await reconcileOrphan(tx, batchId, line);
        continue;
      }

      // Descuadre de bruto (antes de comisiones)
      const grossDelta = round6(Number(internal.amount) - line.gross);
      if (Math.abs(grossDelta) > AMOUNT_TOLERANCE) {
        await recordException(tx, batchId, "AMOUNT_MISMATCH", line.provider, line.externalRef,
          Number(internal.amount), line.gross, { internal_status: internal.status });
      }

      await reconcileFee(tx, batchId, line);
      await reconcileFx(tx, batchId, line);
      await reconcileTronNetworkFee(tx, batchId, line, tronFees.get(line.tronPayoutRef ?? "") ?? null);

      // Marcar línea como conciliada (bitácora del lote en la excepción inversa: ausencia = OK)
    }
  });
}

// Barrido inverso: internas CONFIRMED sin liquidación en el archivo (ORPHAN_INTERNAL)
async function sweepInternalOrphans(batchId: string, fileRefs: Set<string>, provider: string): Promise<void> {
  if (fileRefs.size === 0) return;
  await db.transaction(async (tx) => {
    const rows = await tx.execute(sql`
      SELECT external_tx_id, amount FROM transactions
      WHERE provider = ${provider} AND environment = 'mainnet' AND status = 'CONFIRMED'
        AND created_at > now() - INTERVAL '45 days'
        AND external_tx_id <> ALL(${[...fileRefs]}::varchar[])
    `);
    for (const r of rows.rows as any[]) {
      await recordException(tx, batchId, "ORPHAN_INTERNAL", provider, r.external_tx_id,
        Number(r.amount), null, {
          hypothesis: "CONFIRMED interno sin settlement — payout retenido, rolling reserve, o reporte incompleto",
        });
    }
  });
}

// ==============================================================
// Ingesta streaming — memoria O(BATCH_SIZE) sin importar el tamaño
// ==============================================================
function parseLine(raw: string): SettlementLine | null {
  const c = raw.split(",");
  if (c.length < 10 || c[0] === "provider") return null; // header / malformada
  const num = (v: string) => (v === "" || v === "null" ? null : Number(v));
  if (c[0] !== "STRIPE" && c[0] !== "MERCADOPAGO") return null;
  return {
    provider: c[0] as SettlementLine["provider"],
    externalRef: c[1],
    gross: Number(c[2]),
    fee: Number(c[3]),
    net: Number(c[4]),
    currency: c[5],
    captureFxRate: num(c[6]),
    settlementFxRate: num(c[7]),
    settledAt: c[8],
    tronPayoutRef: c[9] || null,
  };
}

async function ingestFile(path: string): Promise<void> {
  const batchId = randomUUID();
  const fileRefs = new Set<string>();
  const rl = createInterface({ input: createReadStream(path), crlfDelay: Infinity });

  let batch: SettlementLine[] = [];
  let processed = 0;
  const provider = basename(path).startsWith("mp") ? "MERCADOPAGO" : "STRIPE";

  for await (const raw of rl) {
    const line = parseLine(raw);
    if (!line) continue;
    fileRefs.add(line.externalRef);
    batch.push(line);
    if (batch.length >= BATCH_SIZE) {
      await processBatch(batchId, batch);
      processed += batch.length;
      batch = [];
      if (processed % 5000 === 0) console.log(`[recon] ${basename(path)}: ${processed} líneas...`);
    }
  }
  if (batch.length) { await processBatch(batchId, batch); processed += batch.length; }

  await sweepInternalOrphans(batchId, fileRefs, provider);
  console.log(`[recon] ${basename(path)} completo: ${processed} líneas, batch=${batchId}`);
}

async function refreshCloseViews(): Promise<void> {
  await db.execute(sql`REFRESH MATERIALIZED VIEW CONCURRENTLY ledger.daily_close`);
  await db.execute(sql`REFRESH MATERIALIZED VIEW CONCURRENTLY ledger.daily_close_alerts`);
}

function round6(n: number): number { return Math.round(n * 1e6) / 1e6; }

// ==============================================================
// Demonio — corre indefinidamente, un archivo a la vez
// ==============================================================
async function main(): Promise<void> {
  for (const d of [SETTLEMENT_DIR, PROCESSED_DIR, FAILED_DIR]) {
    if (!existsSync(d)) mkdirSync(d, { recursive: true });
  }
  console.log(`[recon] engine start dir=${SETTLEMENT_DIR} batch=${BATCH_SIZE}`);

  for (;;) {
    const files = readdirSync(SETTLEMENT_DIR).filter((f) => f.endsWith(".csv"));
    for (const f of files) {
      const src = join(SETTLEMENT_DIR, f);
      try {
        await ingestFile(src);
        renameSync(src, join(PROCESSED_DIR, `${Date.now()}-${f}`));
      } catch (e) {
        console.error(`[recon] FALLO ${f}:`, (e as Error).message);
        renameSync(src, join(FAILED_DIR, `${Date.now()}-${f}`)); // aislado para reproceso manual
      }
    }
    if (files.length) await refreshCloseViews();
    await new Promise((r) => setTimeout(r, POLL_INTERVAL_MS));
  }
}

main();
```

```bash
# package.json → "scripts": { "worker:recon": "tsx server/workers/recon-engine.ts" }
doppler run --project banxico-plus --config prod -- npx tsx server/workers/recon-engine.ts
```