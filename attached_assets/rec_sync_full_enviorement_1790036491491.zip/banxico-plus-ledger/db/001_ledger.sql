-- ==============================================================
-- Banxico-Plus — LEDGER ESTRICTO DE PARTIDA DOBLE (Módulo 1)
-- Inmutable. Ecuación: Activo = Pasivo + Capital (validada por
-- balance por asiento: SUM(debit) = SUM(credit)).
-- Correcciones SOLO por asientos de contrapartida (reversing).
-- ==============================================================

CREATE SCHEMA IF NOT EXISTS ledger;

-- --------------------------------------------------------------
-- Catálogo de cuentas
-- --------------------------------------------------------------
CREATE TABLE ledger.accounts (
    code        VARCHAR(40) PRIMARY KEY,
    name        VARCHAR(120) NOT NULL,
    type        VARCHAR(10) NOT NULL CHECK (type IN ('ASSET','LIABILITY','EQUITY','REVENUE','EXPENSE')),
    currency    VARCHAR(10) NOT NULL,          -- MXN | USD | USDT
    is_system   BOOLEAN NOT NULL DEFAULT TRUE, -- cuentas de sistema: no editables
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Cuentas de sistema (semilla idempotente)
-- ASSET: lo que la empresa posee / le deben
-- LIABILITY: lo que la empresa debe
-- EQUITY: capital; REVENUE/EXPENSE: resultado del periodo
INSERT INTO ledger.accounts (code, name, type, currency) VALUES
    ('stripe_clearing',    'Fondos en tránsito Stripe',        'ASSET',     'MXN'),
    ('mp_clearing',        'Fondos en tránsito MercadoPago',   'ASSET',     'MXN'),
    ('tron_wallet',        'Hot wallet TRON (USDT)',           'ASSET',     'USDT'),
    ('transit',            'Tránsito cross-riel (suspense)',   'ASSET',     'MXN'),
    ('rolling_reserves',   'Reserva rodante retenida',         'ASSET',     'MXN'),
    ('user_balances',      'Saldos de usuarios (pasivo)',      'LIABILITY', 'MXN'),
    ('reserves_payable',   'Reservas por liberar a clientes',  'LIABILITY', 'MXN'),
    ('capital',            'Capital contable',                 'EQUITY',    'MXN'),
    ('revenue_fees',       'Ingreso por comisiones propias',   'REVENUE',   'MXN'),
    ('fees_stripe',        'Gasto: comisiones Stripe',         'EXPENSE',   'MXN'),
    ('fees_mp',            'Gasto: comisiones MercadoPago',    'EXPENSE',   'MXN'),
    ('fees_tron_network',  'Gasto: network fees TRON',         'EXPENSE',   'USDT'),
    ('fx_loss',            'Pérdida cambiaria (slippage)',     'EXPENSE',   'MXN'),
    ('fx_gain',            'Ganancia cambiaria',               'REVENUE',   'MXN')
ON CONFLICT (code) DO NOTHING;

-- --------------------------------------------------------------
-- Asientos (journal) — INMUTABLE
-- Idempotencia: (source, external_ref) UNIQUE — un evento de
-- negocio genera exactamente UN asiento aunque el ETL re-corra.
-- --------------------------------------------------------------
CREATE TABLE ledger.journal_entries (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source        VARCHAR(20) NOT NULL CHECK (source IN ('STRIPE','MERCADOPAGO','TRON','RECON','FX','RESERVE','MANUAL')),
    external_ref  VARCHAR(255) NOT NULL,       -- event.id / payout id / txHash / settlement line id
    description   TEXT NOT NULL,
    booked_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    recon_batch   UUID,                        -- trazabilidad al lote del ETL
    UNIQUE (source, external_ref)
);

CREATE TABLE ledger.entry_lines (
    id           BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    entry_id     UUID NOT NULL REFERENCES ledger.journal_entries(id),
    account_code VARCHAR(40) NOT NULL REFERENCES ledger.accounts(code),
    debit        NUMERIC(20,6) NOT NULL DEFAULT 0 CHECK (debit >= 0),
    credit       NUMERIC(20,6) NOT NULL DEFAULT 0 CHECK (credit >= 0),
    CHECK (NOT (debit > 0 AND credit > 0)),    -- una línea nunca es débito y crédito a la vez
    CHECK (debit > 0 OR credit > 0)            -- ni línea vacía
);

CREATE INDEX idx_lines_entry   ON ledger.entry_lines (entry_id);
CREATE INDEX idx_lines_account ON ledger.entry_lines (account_code);
CREATE INDEX idx_journal_ref   ON ledger.journal_entries (external_ref);

-- --------------------------------------------------------------
-- INMUTABILIDAD: prohibir UPDATE/DELETE en journal y líneas
-- --------------------------------------------------------------
CREATE OR REPLACE FUNCTION ledger.reject_mutation() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
    RAISE EXCEPTION 'ledger inmutable: % prohibido en % — usar asiento de contrapartida', TG_OP, TG_TABLE_NAME;
END;
$$;

CREATE TRIGGER trg_journal_immutable
    BEFORE UPDATE OR DELETE ON ledger.journal_entries
    FOR EACH ROW EXECUTE FUNCTION ledger.reject_mutation();

CREATE TRIGGER trg_lines_immutable
    BEFORE UPDATE OR DELETE ON ledger.entry_lines
    FOR EACH ROW EXECUTE FUNCTION ledger.reject_mutation();

-- --------------------------------------------------------------
-- EQUACIÓN CONTABLE POR ASIENTO: SUM(debit) = SUM(credit)
-- Constraint trigger DEFERRABLE: se valida al COMMIT, permitiendo
-- insertar asiento y líneas en cualquier orden dentro de la tx.
-- --------------------------------------------------------------
CREATE OR REPLACE FUNCTION ledger.check_entry_balance() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE
    d NUMERIC(20,6);
    c NUMERIC(20,6);
BEGIN
    SELECT COALESCE(SUM(debit),0), COALESCE(SUM(credit),0) INTO d, c
      FROM ledger.entry_lines WHERE entry_id = NEW.id;
    IF d <> c THEN
        RAISE EXCEPTION 'asiento % descuadrado: debit=% credit=% — violación Activo=Pasivo+Capital', NEW.id, d, c;
    END IF;
    IF d = 0 THEN
        RAISE EXCEPTION 'asiento % sin líneas — prohibido', NEW.id;
    END IF;
    RETURN NULL;
END;
$$;

CREATE CONSTRAINT TRIGGER trg_entry_balanced
    AFTER INSERT ON ledger.journal_entries
    DEFERRABLE INITIALLY DEFERRED
    FOR EACH ROW EXECUTE FUNCTION ledger.check_entry_balance();

-- --------------------------------------------------------------
-- Excepciones de conciliación (salida del ETL pesado)
-- --------------------------------------------------------------
CREATE TABLE ledger.recon_exceptions (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    batch_id      UUID NOT NULL,
    kind          VARCHAR(30) NOT NULL CHECK (kind IN (
                      'FEE_MISMATCH',        -- comisión dinámica difiere de lo esperado
                      'FX_SLIPPAGE',         -- diferencia captura vs liquidación
                      'ORPHAN_SETTLEMENT',   -- cobrado en procesador, sin tx interna
                      'ORPHAN_INTERNAL',     -- tx interna CONFIRMED sin liquidación
                      'AMOUNT_MISMATCH',     -- bruto difiere > tolerancia
                      'TRON_NOT_DISPATCHED'  -- cobrado en Stripe, payout TRON jamás disparado
                  )),
    provider      VARCHAR(20) NOT NULL,
    external_ref  VARCHAR(255) NOT NULL,
    expected_amt  NUMERIC(20,6),
    actual_amt    NUMERIC(20,6),
    delta         NUMERIC(20,6),
    detail        JSONB,
    resolved      BOOLEAN NOT NULL DEFAULT FALSE,  -- resolución manual permitida (esta tabla SÍ es mutable)
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (batch_id, kind, external_ref)          -- idempotencia por lote
);

CREATE INDEX idx_recon_open ON ledger.recon_exceptions (kind) WHERE resolved = FALSE;
