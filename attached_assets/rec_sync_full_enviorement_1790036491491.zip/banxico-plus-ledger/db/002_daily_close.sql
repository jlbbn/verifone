-- ==============================================================
-- Módulo 3 — Cierre Diario (vista materializada)
-- Suma débitos/créditos por proveedor y día; alerta descuadre > $0.01
-- Refresco: REFRESH MATERIALIZED VIEW CONCURRENTLY ledger.daily_close;
-- ==============================================================

-- Vista base: líneas enriquecidas con cuenta y asiento
CREATE MATERIALIZED VIEW ledger.daily_close AS
WITH lines AS (
    SELECT
        date_trunc('day', je.booked_at)::date           AS day,
        je.source                                        AS provider,
        a.code                                           AS account_code,
        a.type                                           AS account_type,
        a.currency,
        SUM(el.debit)                                    AS total_debit,
        SUM(el.credit)                                   AS total_credit
    FROM ledger.entry_lines el
    JOIN ledger.journal_entries je ON je.id = el.entry_id
    JOIN ledger.accounts a        ON a.code = el.account_code
    GROUP BY 1, 2, 3, 4, 5
),
totals AS (
    SELECT
        day,
        provider,
        currency,
        SUM(total_debit)  AS debits,
        SUM(total_credit) AS credits,
        SUM(total_debit) - SUM(total_credit) AS imbalance
    FROM lines
    GROUP BY 1, 2, 3
)
SELECT
    t.day,
    t.provider,
    t.currency,
    t.debits,
    t.credits,
    t.imbalance,
    CASE
        WHEN ABS(t.imbalance) > 0.01 THEN 'DESCUADRADO — INVESTIGAR'
        ELSE 'BALANCED'
    END AS close_status,
    -- Posición neta por tipo de cuenta (ecuación Activo = Pasivo + Capital)
    (SELECT COALESCE(SUM(CASE WHEN l.account_type = 'ASSET'     THEN l.total_debit - l.total_credit END), 0)
       FROM lines l WHERE l.day = t.day AND l.provider = t.provider) AS net_assets,
    (SELECT COALESCE(SUM(CASE WHEN l.account_type IN ('LIABILITY','EQUITY')
                               THEN l.total_credit - l.total_debit END), 0)
       FROM lines l WHERE l.day = t.day AND l.provider = t.provider) AS net_liab_equity,
    now() AS refreshed_at
FROM totals t;

-- Requerido para REFRESH CONCURRENTLY (sin bloquear lecturas del dashboard)
CREATE UNIQUE INDEX idx_daily_close_pk
    ON ledger.daily_close (day, provider, currency);

-- Alertas abiertas de conciliación por día (join lateral al cierre)
CREATE MATERIALIZED VIEW ledger.daily_close_alerts AS
SELECT
    date_trunc('day', created_at)::date AS day,
    provider,
    kind,
    COUNT(*)                            AS open_count,
    SUM(ABS(delta))                     AS total_delta
FROM ledger.recon_exceptions
WHERE resolved = FALSE
GROUP BY 1, 2, 3
HAVING SUM(ABS(delta)) > 0.01;

CREATE UNIQUE INDEX idx_close_alerts_pk
    ON ledger.daily_close_alerts (day, provider, kind);

-- Refresh operativo (cron del orquestador, post-ETL):
--   REFRESH MATERIALIZED VIEW CONCURRENTLY ledger.daily_close;
--   REFRESH MATERIALIZED VIEW CONCURRENTLY ledger.daily_close_alerts;
