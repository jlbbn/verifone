// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

// ==============================================================
// BanxicoRollup — Verificador L1 del zk-Rollup soberano
// Groth16 sobre BN254 (alt_bn128 precompiles 0x06/0x07/0x08).
// Hot path en Yul: verificacion de pairing + extraccion de
// calldata (Data Availability) sin copias ABI innecesarias.
//
// Public inputs del circuito (orden fijo, 3 x 32 bytes):
//   [0] oldRoot  [1] newRoot  [2] totalFees
// ==============================================================

contract BanxicoRollup {
    // ---------------- Estado ----------------
    bytes32 public stateRoot;
    uint64  public batchIndex;
    address public sequencer;          // lider autorizado a postear batches
    address public immutable owner;

    // Verification key Groth16 (fijada en deploy, proviene del setup del circuito)
    // IC length = 4 (G1): IC[0] constante + 3 public inputs
    uint256[2]   private immutable ALPHA;   // G1
    uint256[4]   private immutable BETA;    // G2 (x_im, x_re, y_im, y_re) — orden FQ2 del precompile
    uint256[4]   private immutable GAMMA;   // G2
    uint256[4]   private immutable DELTA;   // G2
    uint256[2][] private IC;                // G1, length 4

    // Data Availability: hash del calldata del batch (los datos crudos
    // viven EN calldata, no en storage — disponibilidad garantizada por L1)
    mapping(uint64 => bytes32) public batchDataHash;

    // ---------------- Eventos ----------------
    event BatchPosted(
        uint64 indexed batchIndex,
        bytes32 oldRoot,
        bytes32 newRoot,
        uint256 totalFees,
        bytes32 dataHash
    );
    event SequencerRotated(address indexed previous, address indexed next);

    error NotSequencer();
    error InvalidProof();
    error StaleRoot();
    error BadCalldataLength();
    error InvalidVkLength();

    constructor(
        address _sequencer,
        bytes32 _genesisRoot,
        uint256[2] memory alpha,
        uint256[4] memory beta,
        uint256[4] memory gamma,
        uint256[4] memory delta,
        uint256[2][] memory ic
    ) {
        if (ic.length != 4) revert InvalidVkLength();
        owner = msg.sender;
        sequencer = _sequencer;
        stateRoot = _genesisRoot;
        ALPHA = alpha;
        BETA = beta;
        GAMMA = gamma;
        DELTA = delta;
        for (uint256 i = 0; i < ic.length; i++) {
            IC.push(ic[i]);
        }
    }

    // --------------------------------------------------------------
    // Rotacion de liderazgo (alineada con la rotacion P2P off-chain)
    // --------------------------------------------------------------
    function rotateSequencer(address next) external {
        if (msg.sender != owner && msg.sender != sequencer) revert NotSequencer();
        emit SequencerRotated(sequencer, next);
        sequencer = next;
    }

    // --------------------------------------------------------------
    // postBatch — hot path
    // calldata layout (todo packed, sin ABI decoder):
    //   [0x00..0x20)  A.x        [0x20..0x40)  A.y        (G1 proof)
    //   [0x40..0x80)  B (2 x FQ2: x_im, x_re, y_im, y_re) (G2 proof)
    //   [0x80..0xC0)  C.x, C.y   (G1 proof)
    //   [0xC0..0xE0)  oldRoot    [0xE0..0x100) newRoot    [0x100..0x120) totalFees
    //   [0x120..   )  txData cruda (DA): n*88 bytes por tx
    //                  (sender32 || receiver32 || amount8 || fee8 || nonce8)
    // --------------------------------------------------------------
    function postBatch(bytes calldata proofAndData) external {
        if (msg.sender != sequencer) revert NotSequencer();
        if (proofAndData.length < 0x120) revert BadCalldataLength();

        bytes32 oldRoot;
        bytes32 newRoot;
        uint256 totalFees;
        bytes32 dataHash;

        assembly {
            let base := proofAndData.offset

            oldRoot   := calldataload(add(base, 0xC0))
            newRoot   := calldataload(add(base, 0xE0))
            totalFees := calldataload(add(base, 0x100))

            // Encadenamiento estricto: oldRoot del batch == stateRoot actual
            if iszero(eq(oldRoot, sload(stateRoot.slot))) {
                mstore(0x00, 0x08c379a0) // revert con mensaje (fallback)
                mstore(0x04, 0x20)
                mstore(0x24, 0x0a)
                mstore(0x44, "stale root")
                revert(0x00, 0x64)
            }

            // ---- DA: keccak256 del segmento de datos crudos ----
            let dataPtr := add(base, 0x120)
            let dataLen := sub(proofAndData.length, 0x120)
            // scratch space: copiar calldata a memoria para keccak (calldatacopy es barato)
            calldatacopy(0x00, dataPtr, dataLen)
            dataHash := keccak256(0x00, dataLen)
        }

        // Carga de IC desde storage + verificacion Groth16 (Yul puro en pairing)
        _verifyAndFinalize(proofAndData, newRoot, dataHash);

        emit BatchPosted(batchIndex - 1, oldRoot, newRoot, totalFees, dataHash);
    }

    // --------------------------------------------------------------
    // Subrutina de verificacion (Yul puro en el pairing)
    // --------------------------------------------------------------
    function _verifyAndFinalize(
        bytes calldata proofAndData,
        bytes32 newRoot,
        bytes32 dataHash
    ) internal {
        // Cargar IC a memoria (4 puntos G1 = 8 words)
        uint256[8] memory ic;
        for (uint256 i = 0; i < 4; i++) {
            ic[i * 2] = IC[i][0];
            ic[i * 2 + 1] = IC[i][1];
        }

        uint256[2] memory alpha = ALPHA;
        uint256[4] memory beta = BETA;
        uint256[4] memory gamma = GAMMA;
        uint256[4] memory delta = DELTA;

        bool ok;
        uint64 idx = batchIndex;

        assembly {
            let base := proofAndData.offset
            let oldRoot   := calldataload(add(base, 0xC0))
            let newR      := calldataload(add(base, 0xE0))
            let totalFees := calldataload(add(base, 0x100))

            let mulBuf := msize()      // 96 bytes por mul: x,y,scalar
            mstore(add(mulBuf, 0x00), 0)
            let addBuf := add(mulBuf, 0x60)

            // ---------- L = IC[0] + oldRoot*IC[1] + newRoot*IC[2] + fees*IC[3]
            // IC[0]
            let lx := mload(add(ic, 0x00))
            let ly := mload(add(ic, 0x20))

            // scalar-mul + add para cada public input
            // helper inline repetido (evita costo de dispatch interno)
            // --- term 1: oldRoot * IC[1]
            mstore(mulBuf,       mload(add(ic, 0x40)))
            mstore(add(mulBuf, 0x20), mload(add(ic, 0x60)))
            mstore(add(mulBuf, 0x40), oldRoot)
            if iszero(staticcall(gas(), 0x07, mulBuf, 0x60, mulBuf, 0x40)) { revert(0, 0) }
            mstore(addBuf, lx)
            mstore(add(addBuf, 0x20), ly)
            mstore(add(addBuf, 0x40), mload(mulBuf))
            mstore(add(addBuf, 0x60), mload(add(mulBuf, 0x20)))
            if iszero(staticcall(gas(), 0x06, addBuf, 0x80, addBuf, 0x40)) { revert(0, 0) }
            lx := mload(addBuf)
            ly := mload(add(addBuf, 0x20))

            // --- term 2: newRoot * IC[2]
            mstore(mulBuf,       mload(add(ic, 0x80)))
            mstore(add(mulBuf, 0x20), mload(add(ic, 0xA0)))
            mstore(add(mulBuf, 0x40), newR)
            if iszero(staticcall(gas(), 0x07, mulBuf, 0x60, mulBuf, 0x40)) { revert(0, 0) }
            mstore(addBuf, lx)
            mstore(add(addBuf, 0x20), ly)
            mstore(add(addBuf, 0x40), mload(mulBuf))
            mstore(add(addBuf, 0x60), mload(add(mulBuf, 0x20)))
            if iszero(staticcall(gas(), 0x06, addBuf, 0x80, addBuf, 0x40)) { revert(0, 0) }
            lx := mload(addBuf)
            ly := mload(add(addBuf, 0x20))

            // --- term 3: totalFees * IC[3]
            mstore(mulBuf,       mload(add(ic, 0xC0)))
            mstore(add(mulBuf, 0x20), mload(add(ic, 0xE0)))
            mstore(add(mulBuf, 0x40), totalFees)
            if iszero(staticcall(gas(), 0x07, mulBuf, 0x60, mulBuf, 0x40)) { revert(0, 0) }
            mstore(addBuf, lx)
            mstore(add(addBuf, 0x20), ly)
            mstore(add(addBuf, 0x40), mload(mulBuf))
            mstore(add(addBuf, 0x60), mload(add(mulBuf, 0x20)))
            if iszero(staticcall(gas(), 0x06, addBuf, 0x80, addBuf, 0x40)) { revert(0, 0) }
            lx := mload(addBuf)
            ly := mload(add(addBuf, 0x20))

            // ---------- Pairing input: 4 pares (G1, G2) = 4*6 words = 0x300 bytes
            let pk := add(addBuf, 0x80)

            // Par 1: (-A, B)  — negacion de A.y mod q
            // q = 21888242871839275222246405745257275088696311157297823662689037894645226208583
            let q := 0x30644e72e131a029b85045b68181585d97816a916871ca8d3c208c16d87cfd47
            let ax := calldataload(add(base, 0x00))
            let ay := calldataload(add(base, 0x20))
            mstore(pk, ax)
            mstore(add(pk, 0x20), sub(q, mod(ay, q)))        // -A
            mstore(add(pk, 0x40), calldataload(add(base, 0x40)))  // B.x_im
            mstore(add(pk, 0x60), calldataload(add(base, 0x60)))  // B.x_re
            mstore(add(pk, 0x80), calldataload(add(base, 0x80)))  // B.y_im
            mstore(add(pk, 0xA0), calldataload(add(base, 0xA0)))  // B.y_re

            // Par 2: (alpha, beta)
            mstore(add(pk, 0xC0),  mload(alpha))
            mstore(add(pk, 0xE0),  mload(add(alpha, 0x20)))
            mstore(add(pk, 0x100), mload(beta))
            mstore(add(pk, 0x120), mload(add(beta, 0x20)))
            mstore(add(pk, 0x140), mload(add(beta, 0x40)))
            mstore(add(pk, 0x160), mload(add(beta, 0x60)))

            // Par 3: (L, gamma)
            mstore(add(pk, 0x180), lx)
            mstore(add(pk, 0x1A0), ly)
            mstore(add(pk, 0x1C0), mload(gamma))
            mstore(add(pk, 0x1E0), mload(add(gamma, 0x20)))
            mstore(add(pk, 0x200), mload(add(gamma, 0x40)))
            mstore(add(pk, 0x220), mload(add(gamma, 0x60)))

            // Par 4: (C, delta)
            mstore(add(pk, 0x240), calldataload(add(base, 0x80)))  // C.x
            mstore(add(pk, 0x260), calldataload(add(base, 0xA0)))  // C.y
            mstore(add(pk, 0x280), mload(delta))
            mstore(add(pk, 0x2A0), mload(add(delta, 0x20)))
            mstore(add(pk, 0x2C0), mload(add(delta, 0x40)))
            mstore(add(pk, 0x2E0), mload(add(delta, 0x60)))

            // ecmul/ecadd/pairing precompiles: 0x08 = pairing
            if iszero(staticcall(gas(), 0x08, pk, 0x300, pk, 0x20)) { revert(0, 0) }
            ok := eq(mload(pk), 1)

            if ok {
                // Commit de estado: nuevo stateRoot + DA hash + batchIndex
                sstore(stateRoot.slot, newR)
                sstore(batchIndex.slot, add(idx, 1))
            }
        }

        if (!ok) revert InvalidProof();
        batchDataHash[idx] = dataHash;
    }

    // --------------------------------------------------------------
    // Withdraw bridge (salida soberana): prueba Merkle contra
    // batchDataHash del calldata publicado — DA verificada on-chain
    // --------------------------------------------------------------
    function verifyDataAvailability(
        uint64 batch,
        bytes32 leaf,
        bytes32[] calldata merklePath,
        uint256 pathBits
    ) external view returns (bool) {
        bytes32 root = batchDataHash[batch];
        if (root == bytes32(0)) return false;
        bytes32 node = leaf;
        for (uint256 i = 0; i < merklePath.length; i++) {
            bytes32 sib = merklePath[i];
            node = ((pathBits >> i) & 1) == 1
                ? keccak256(abi.encodePacked(sib, node))
                : keccak256(abi.encodePacked(node, sib));
        }
        // Nota: batchDataHash es keccak del segmento crudo; en produccion
        // el DA root es la raiz del arbol de txs del batch (mismo formato).
        return node == root;
    }
}
