//! Circuito ZK del rollup — arkworks (R1CS sobre BN254).
//!
//! Prueba por BATCH de transiciones de estado:
//!   1. Schnorr (BabyJubJub/Ed-on-BN254) verificado IN-CIRCUIT:
//!        s·G == R + e·P,   e = Poseidon(R.x || P.x || msg)
//!   2. Conservacion de masa por tx:
//!        old_balance_sender - amount - fee == new_balance_sender
//!        old_balance_receiver + amount    == new_balance_receiver
//!        amount, fee, balances ∈ [0, 2^64)  (range constraints a bit)
//!   3. Transicion del State Root (SMT Poseidon, profundidad generica):
//!        recompute_root(old_leaf, path) == old_root   (public input)
//!        recompute_root(new_leaf, path) == new_root   (public input)
//!
//! La transicion de la raiz usa Poseidon (SNARK-friendly, ~300 constraints
//! por hash vs ~25k de SHA-256): el SMT on-chain del circuito es un SMT
//! Poseidon isomorfo al SHA-256 del secuenciador (misma topologia,
//! distinto hash — el L1 solo conoce raices Poseidon).

use ark_bn254::Fr;
use ark_ec::AffineRepr;
use ark_ed_on_bn254::{EdwardsAffine, EdwardsParameters, Fq};
use ark_ff::{Field, PrimeField};
use ark_r1cs_std::alloc::{AllocVar, AllocationMode};
use ark_r1cs_std::bits::uint64::UInt64;
use ark_r1cs_std::bits::uint8::UInt8;
use ark_r1cs_std::bits::ToBitsGadget;
use ark_r1cs_std::boolean::Boolean;
use ark_r1cs_std::eq::EqGadget;
use ark_r1cs_std::fields::fp::FpVar;
use ark_r1cs_std::groups::curves::twisted_edwards::AffineVar as EdwardsVar;
use ark_r1cs_std::R1CSVar;
use ark_relations::r1cs::{ConstraintSynthesizer, ConstraintSystemRef, SynthesisError};
use ark_sponge::poseidon::constraints::CRHGadget as PoseidonCRHGadget;
use ark_sponge::poseidon::PoseidonParameters;
use ark_std::marker::PhantomData;
use ark_std::vec::Vec;

// ------------------------------------------------------------------
// Parametros del circuito
// ------------------------------------------------------------------
pub const SMT_DEPTH: usize = 32;        // 2^32 cuentas (shadow); produccion: 64+
pub const BATCH_SIZE: usize = 8;        // txs por proof (shadow); produccion: 1024+
pub const AMOUNT_BITS: usize = 64;      // rango de montos y balances

// ------------------------------------------------------------------
// Testigo de una transicion de cuenta (una hoja SMT)
// ------------------------------------------------------------------
#[derive(Clone)]
pub struct AccountTransition {
    pub key: Fr,                        // clave de la hoja (hash de pubkey)
    pub old_balance: u64,
    pub old_nonce: u64,
    pub new_balance: u64,
    pub new_nonce: u64,
    pub path: Vec<Fr>,                  // hermanos raiz->hoja (SMT_DEPTH)
    pub path_bits: Vec<bool>,           // bit de direccion por nivel
}

// ------------------------------------------------------------------
// Testigo de una transaccion del batch
// ------------------------------------------------------------------
#[derive(Clone)]
pub struct TxWitness {
    pub amount: u64,
    pub fee: u64,
    pub msg_hash: Fr,                   // Poseidon(tx_bytes) firmado por el usuario
    pub sig_r: EdwardsAffine,           // R de Schnorr
    pub sig_s: Fr,                      // escalar s (embebido en Fr para el circuito)
    pub sender_pk: EdwardsAffine,       // P (clave publica BabyJubJub del sender)
    pub sender: AccountTransition,
    pub receiver: AccountTransition,
}

// ------------------------------------------------------------------
// El circuito
// ------------------------------------------------------------------
pub struct RollupCircuit {
    pub poseidon_params: PoseidonParameters<Fr>,
    pub old_root: Fr,                   // PUBLIC INPUT
    pub new_root: Fr,                   // PUBLIC INPUT
    pub total_fees: Fr,                 // PUBLIC INPUT (se acredita a la cuenta del secuenciador)
    pub txs: Vec<TxWitness>,            // testigo privado (BATCH_SIZE)
    pub _params: PhantomData<EdwardsParameters>,
}

// ------------------------------------------------------------------
// Primitivas in-circuit
// ------------------------------------------------------------------

/// Hash Poseidon de 2 elementos (nodo interno del SMT)
fn poseidon_hash2(
    cs: ConstraintSystemRef<Fr>,
    params: &PoseidonParameters<Fr>,
    a: &FpVar<Fr>,
    b: &FpVar<Fr>,
) -> Result<FpVar<Fr>, SynthesisError> {
    PoseidonCRHGadget::<Fr>::evaluate(params, &[a.clone(), b.clone()])
}

/// Hoja SMT: Poseidon(balance || nonce || key_tag)
/// balance/nonce se range-construyen a 64 bits — su FpVar es canonico.
fn leaf_hash(
    cs: ConstraintSystemRef<Fr>,
    params: &PoseidonParameters<Fr>,
    balance: &FpVar<Fr>,
    nonce: &FpVar<Fr>,
    key: &FpVar<Fr>,
) -> Result<FpVar<Fr>, SynthesisError> {
    PoseidonCRHGadget::<Fr>::evaluate(params, &[balance.clone(), nonce.clone(), key.clone()])
}

/// Recomputa la raiz SMT desde una hoja: para cada nivel, si bit=0 el nodo
/// va a la izquierda, si bit=1 a la derecha. Constraint polinomial:
///   parent = bit * H(sib,node) + (1-bit) * H(node,sib)
fn recompute_root(
    cs: ConstraintSystemRef<Fr>,
    params: &PoseidonParameters<Fr>,
    leaf: &FpVar<Fr>,
    path: &[FpVar<Fr>],
    bits: &[Boolean<Fr>],
) -> Result<FpVar<Fr>, SynthesisError> {
    let mut node = leaf.clone();
    for (sibling, bit) in path.iter().zip(bits.iter()) {
        let h_lr = poseidon_hash2(cs.clone(), params, &node, sibling)?;   // H(node, sib)
        let h_rl = poseidon_hash2(cs.clone(), params, sibling, &node)?;   // H(sib, node)
        // select bit ? h_rl : h_lr  (Boolean::select genera el constraint lineal)
        node = Boolean::select(bit, &h_rl, &h_lr)?;
    }
    Ok(node)
}

/// Verificacion Schnorr in-circuit: s·G == R + e·P
///   e = Poseidon(R.x || P.x || msg)
/// Escalares como vectores de bits little-endian; mul por ventana fija
/// del gadget (twisted Edwards, curva cofactor 8 — subgroup prime order).
fn schnorr_verify(
    cs: ConstraintSystemRef<Fr>,
    params: &PoseidonParameters<Fr>,
    r_var: &EdwardsVar<EdwardsParameters, FpVar<Fr>>,
    p_var: &EdwardsVar<EdwardsParameters, FpVar<Fr>>,
    s_bits: &[Boolean<Fr>],
    msg: &FpVar<Fr>,
) -> Result<Boolean<Fr>, SynthesisError> {
    // e = Poseidon(R.x, P.x, msg) como escalar del subgrupo (Fr == Fq orden del subgrupo en ed-on-bn254)
    let e_var = PoseidonCRHGadget::<Fr>::evaluate(
        params,
        &[r_var.x.clone(), p_var.x.clone(), msg.clone()],
    )?;
    let e_bits: Vec<Boolean<Fr>> = e_var.to_bits_le()?;

    // s·G (mul por base fija del generador del subgrupo)
    let g_affine = EdwardsAffine::prime_subgroup_generator();
    let g_var = EdwardsVar::<EdwardsParameters, FpVar<Fr>>::new_constant(cs.clone(), g_affine)?;
    let sg = g_var.scalar_mul_le(s_bits.iter())?;

    // e·P (mul por punto variable del testigo)
    let ep = p_var.scalar_mul_le(e_bits.iter())?;

    // R + e·P
    let rhs = r_var.clone() + ep;

    // Igualdad de puntos: ambas coordenadas
    let x_ok = sg.x.is_eq(&rhs.x)?;
    let y_ok = sg.y.is_eq(&rhs.y)?;
    Ok(x_ok & y_ok)
}

// ------------------------------------------------------------------
// Sintesis del circuito
// ------------------------------------------------------------------
impl ConstraintSynthesizer<Fr> for RollupCircuit {
    fn generate_constraints(self, cs: ConstraintSystemRef<Fr>) -> Result<(), SynthesisError> {
        assert_eq!(self.txs.len(), BATCH_SIZE, "batch incompleto");

        // ---- Public inputs ----
        let old_root_pub = FpVar::<Fr>::new_input(cs.clone(), || Ok(self.old_root))?;
        let new_root_pub = FpVar::<Fr>::new_input(cs.clone(), || Ok(self.new_root))?;
        let fees_pub = FpVar::<Fr>::new_input(cs.clone(), || Ok(self.total_fees))?;

        let params = &self.poseidon_params;

        // Raiz corriente: se encadena tx a tx (old_root -> ... -> new_root)
        let mut current_root = old_root_pub.clone();
        let mut fees_acc = FpVar::<Fr>::zero();

        for (tx_idx, tx) in self.txs.iter().enumerate() {
            let tx_cs = cs.clone();

            // ================= 1. Sincronizacion del testigo =================
            let amount = UInt64::<Fr>::new_witness(tx_cs.clone(), || Ok(tx.amount))?;
            let fee = UInt64::<Fr>::new_witness(tx_cs.clone(), || Ok(tx.fee))?;
            let msg = FpVar::<Fr>::new_witness(tx_cs.clone(), || Ok(tx.msg_hash))?;

            let r_var = EdwardsVar::<EdwardsParameters, FpVar<Fr>>::new_witness(
                tx_cs.clone(), || Ok(tx.sig_r),
            )?;
            let p_var = EdwardsVar::<EdwardsParameters, FpVar<Fr>>::new_witness(
                tx_cs.clone(), || Ok(tx.sender_pk),
            )?;
            let s_var = FpVar::<Fr>::new_witness(tx_cs.clone(), || Ok(tx.sig_s))?;
            let s_bits: Vec<Boolean<Fr>> = s_var.to_bits_le()?;

            // ================= 2. Schnorr in-circuit =================
            let sig_ok = schnorr_verify(tx_cs.clone(), params, &r_var, &p_var, &s_bits, &msg)?;
            sig_ok.enforce_equal(&Boolean::TRUE)?;

            // ================= 3. Conservacion de masa (UInt64 con rango) =================
            let s_old_bal = UInt64::<Fr>::new_witness(tx_cs.clone(), || Ok(tx.sender.old_balance))?;
            let s_old_nonce = UInt64::<Fr>::new_witness(tx_cs.clone(), || Ok(tx.sender.old_nonce))?;
            let s_new_bal = UInt64::<Fr>::new_witness(tx_cs.clone(), || Ok(tx.sender.new_balance))?;
            let s_new_nonce = UInt64::<Fr>::new_witness(tx_cs.clone(), || Ok(tx.sender.new_nonce))?;
            let r_old_bal = UInt64::<Fr>::new_witness(tx_cs.clone(), || Ok(tx.receiver.old_balance))?;
            let r_old_nonce = UInt64::<Fr>::new_witness(tx_cs.clone(), || Ok(tx.receiver.old_nonce))?;
            let r_new_bal = UInt64::<Fr>::new_witness(tx_cs.clone(), || Ok(tx.receiver.new_balance))?;
            let r_new_nonce = UInt64::<Fr>::new_witness(tx_cs.clone(), || Ok(tx.receiver.new_nonce))?;

            // sender: old - amount - fee == new  (UInt64::subtract valida sin underflow -> constraint)
            let (deducted, borrow1) = s_old_bal.subtract_with_borrow(&amount);
            borrow1.enforce_equal(&Boolean::FALSE)?;              // underflow prohibido
            let (deducted2, borrow2) = deducted.subtract_with_borrow(&fee);
            borrow2.enforce_equal(&Boolean::FALSE)?;              // balance insuficiente prohibido
            deducted2.enforce_equal(&s_new_bal)?;

            // receiver: old + amount == new (carry prohibido: overflow de 64 bits)
            let (r_sum, carry) = r_old_bal.add_with_carry(&amount);
            carry.enforce_equal(&Boolean::FALSE)?;
            r_sum.enforce_equal(&r_new_bal)?;

            // nonces: +1 exacto (anti-replay del rollup)
            let one = UInt64::<Fr>::constant(1u64);
            let (n_sender, c1) = s_old_nonce.add_with_carry(&one);
            c1.enforce_equal(&Boolean::FALSE)?;
            n_sender.enforce_equal(&s_new_nonce)?;
            let (n_recv, c2) = r_old_nonce.add_with_carry(&one);
            c2.enforce_equal(&Boolean::FALSE)?;
            n_recv.enforce_equal(&r_new_nonce)?;

            // fees del batch (FpVar acumulado; suma exacta sin overflow por construccion)
            fees_acc = &fees_acc + &FpVar::from(fee.clone());

            // ================= 4. Transicion del State Root =================
            for (acct, old_b, old_n, new_b, new_n) in [
                (&tx.sender, &s_old_bal, &s_old_nonce, &s_new_bal, &s_new_nonce),
                (&tx.receiver, &r_old_bal, &r_old_nonce, &r_new_bal, &r_new_nonce),
            ] {
                let key_var = FpVar::<Fr>::new_witness(tx_cs.clone(), || Ok(acct.key))?;
                let path_var: Vec<FpVar<Fr>> = acct
                    .path
                    .iter()
                    .map(|s| FpVar::<Fr>::new_witness(tx_cs.clone(), || Ok(*s)))
                    .collect::<Result<_, _>>()?;
                let bits_var: Vec<Boolean<Fr>> = acct
                    .path_bits
                    .iter()
                    .map(|b| Boolean::new_witness(tx_cs.clone(), || Ok(*b)))
                    .collect::<Result<_, _>>()?;

                let bal_f = |u: &UInt64<Fr>| -> FpVar<Fr> {
                    // UInt64 -> FpVar canonico (los bits ya estan range-construidos)
                    let bits = u.to_bits_le();
                    Boolean::le_bits_to_fp_var(&bits).expect("64 bits < |Fr|")
                };

                // Raiz con el ESTADO VIEJO debe coincidir con la raiz corriente
                let old_leaf = leaf_hash(tx_cs.clone(), params, &bal_f(old_b), &bal_f(old_n), &key_var)?;
                let recomputed_old = recompute_root(tx_cs.clone(), params, &old_leaf, &path_var, &bits_var)?;
                recomputed_old.enforce_equal(&current_root)?;

                // Raiz con el ESTADO NUEVO pasa a ser la raiz corriente
                let new_leaf = leaf_hash(tx_cs.clone(), params, &bal_f(new_b), &bal_f(new_n), &key_var)?;
                current_root = recompute_root(tx_cs.clone(), params, &new_leaf, &path_var, &bits_var)?;
            }

            tracing::trace!(tx = tx_idx, "tx constrained");
        }

        // ---- Cierres contra public inputs ----
        current_root.enforce_equal(&new_root_pub)?;   // raiz final del batch == new_root
        fees_acc.enforce_equal(&fees_pub)?;           // suma de fees == total declarado

        Ok(())
    }
}

// ------------------------------------------------------------------
// Generacion de prueba Groth16 (BN254) — la verifica el contrato L1
// ------------------------------------------------------------------
#[cfg(feature = "prove")]
pub mod proving {
    use super::*;
    use ark_bn254::Bn254;
    use ark_groth16::{Groth16, Proof, ProvingKey, VerifyingKey};
    use ark_snark::SNARK;
    use ark_std::rand::{rngs::StdRng, SeedableRng};

    pub fn setup(
        params: PoseidonParameters<Fr>,
        mut rng: &mut StdRng,
    ) -> Result<(ProvingKey<Bn254>, VerifyingKey<Bn254>), SynthesisError> {
        let dummy = RollupCircuit {
            poseidon_params: params,
            old_root: Fr::ZERO,
            new_root: Fr::ZERO,
            total_fees: Fr::ZERO,
            txs: vec![],
            _params: PhantomData,
        };
        Groth16::<Bn254>::circuit_specific_setup(dummy, &mut rng)
            .map_err(|_| SynthesisError::AssignmentMissing)
    }

    pub fn prove(
        pk: &ProvingKey<Bn254>,
        circuit: RollupCircuit,
        mut rng: &mut StdRng,
    ) -> Result<Proof<Bn254>, SynthesisError> {
        Groth16::<Bn254>::prove(pk, circuit, &mut rng)
            .map_err(|_| SynthesisError::AssignmentMissing)
    }

    pub fn verify(
        vk: &VerifyingKey<Bn254>,
        public_inputs: &[Fr], // [old_root, new_root, total_fees]
        proof: &Proof<Bn254>,
    ) -> Result<bool, SynthesisError> {
        Groth16::<Bn254>::verify(vk, public_inputs, proof)
            .map_err(|_| SynthesisError::AssignmentMissing)
    }
}
