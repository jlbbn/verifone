//! P2P Mempool del secuenciador L2 — libp2p gossipsub + mDNS.
//!
//! Topologia:
//!   - Topic `banxico-l2/txs/1.0`: propagacion de transacciones candidatas
//!     (los pares retransmiten; validacion ligera antes de forward).
//!   - Topic `banxico-l2/batches/1.0`: batches sellados por el lider de epoca.
//!   - Liderazgo rotativo DETERMINISTA: leader(epoch) = sorted_peers[epoch % n]
//!     (misma entrada => mismo lider en todos los nodos, sin consenso extra
//!     en la fase de mempool; la finalidad la da el proof en L1).
//!   - mDNS para LAN/shadow; bootstrap explicito por multiaddr para WAN.

use futures::StreamExt;
use libp2p::{
    gossipsub::{self, IdentTopic, MessageAuthenticity, ValidationMode},
    identity,
    mdns,
    noise,
    swarm::{NetworkBehaviour, SwarmEvent},
    tcp, yamux,
    Multiaddr, PeerId, Swarm, Transport,
};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::collections::{HashMap, HashSet};
use std::time::{Duration, SystemTime, UNIX_EPOCH};
use tokio::sync::mpsc;
use tracing::{info, warn};

// ------------------------------------------------------------------
// Mensajes del enjambre
// ------------------------------------------------------------------
pub const TOPIC_TXS: &str = "banxico-l2/txs/1.0";
pub const TOPIC_BATCHES: &str = "banxico-l2/batches/1.0";
const EPOCH_MS: u64 = 12_000;          // rotacion de lider cada 12s
const MAX_TX_BYTES: usize = 4 * 1024;  // rechazo temprano de spam
const MEMPOOL_CAP: usize = 100_000;    // objetivo 100k TPS: cap por nodo

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct L2Tx {
    pub tx_hash: [u8; 32],
    pub sender: [u8; 32],
    pub receiver: [u8; 32],
    pub amount: u64,
    pub fee: u64,
    pub nonce: u64,
    pub sig_r: [u8; 64], // punto R comprimido + paridad (serializacion externa)
    pub sig_s: [u8; 32],
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct SealedBatch {
    pub epoch: u64,
    pub leader: PeerId,
    pub old_root: [u8; 32],
    pub new_root: [u8; 32],
    pub tx_hashes: Vec<[u8; 32]>,
}

#[derive(Debug)]
pub enum MempoolEvent {
    TxAccepted(L2Tx),
    BatchReceived(SealedBatch),
    LeaderChanged { epoch: u64, leader: PeerId, is_self: bool },
}

// ------------------------------------------------------------------
// Behaviour compuesto: gossipsub + mdns
// ------------------------------------------------------------------
#[derive(NetworkBehaviour)]
pub struct MempoolBehaviour {
    pub gossipsub: gossipsub::Behaviour,
    pub mdns: mdns::tokio::Behaviour,
}

// ------------------------------------------------------------------
// Nodo
// ------------------------------------------------------------------
pub struct MempoolNode {
    swarm: Swarm<MempoolBehaviour>,
    topic_txs: IdentTopic,
    topic_batches: IdentTopic,
    local_id: PeerId,
    mempool: HashMap<[u8; 32], L2Tx>,
    seen_batches: HashSet<(u64, [u8; 32])>,
    peers: HashSet<PeerId>,
    events_tx: mpsc::Sender<MempoolEvent>,
}

impl MempoolNode {
    pub fn new(
        keypair: identity::Keypair,
        listen_port: u16,
        events_tx: mpsc::Sender<MempoolEvent>,
    ) -> Result<Self, Box<dyn std::error::Error>> {
        let local_id = PeerId::from(keypair.public());

        // IDs de mensaje por contenido: dedup nativo de gossipsub
        let msg_id = |m: &gossipsub::Message| {
            let mut h = Sha256::new();
            h.update(&m.data);
            gossipsub::MessageId::from(&h.finalize()[..20])
        };
        let gs_config = gossipsub::ConfigBuilder::default()
            .heartbeat_interval(Duration::from_millis(700))
            .validation_mode(ValidationMode::Strict)  // firma del emisor obligatoria
            .message_id_fn(msg_id)
            .max_transmit_size(MAX_TX_BYTES * 64)
            .duplicate_cache_time(Duration::from_secs(30))
            .build()?;

        let gossipsub = gossipsub::Behaviour::new(
            MessageAuthenticity::Signed(keypair.clone()),
            gs_config,
        )?;

        let mdns = mdns::tokio::Behaviour::new(mdns::Config::default(), local_id)?;
        let behaviour = MempoolBehaviour { gossipsub, mdns };

        let transport = tcp::tokio::Transport::new(tcp::Config::default().nodelay(true))
            .upgrade(libp2p::core::upgrade::Version::V1Lazy)
            .authenticate(noise::Config::new(&keypair)?)
            .multiplex(yamux::Config::default())
            .boxed();

        let mut swarm = Swarm::new(
            transport,
            behaviour,
            local_id,
            libp2p::swarm::Config::with_tokio_executor()
                .with_idle_connection_timeout(Duration::from_secs(60)),
        );

        swarm.listen_on(format!("/ip4/0.0.0.0/tcp/{listen_port}").parse()?)?;

        let topic_txs = IdentTopic::new(TOPIC_TXS);
        let topic_batches = IdentTopic::new(TOPIC_BATCHES);
        swarm.behaviour_mut().gossipsub.subscribe(&topic_txs)?;
        swarm.behaviour_mut().gossipsub.subscribe(&topic_batches)?;

        Ok(Self {
            swarm,
            topic_txs,
            topic_batches,
            local_id,
            mempool: HashMap::with_capacity(MEMPOOL_CAP),
            seen_batches: HashSet::new(),
            peers: HashSet::new(),
            events_tx,
        })
    }

    // --------------------------------------------------------------
    // Liderazgo rotativo determinista por epoca
    // --------------------------------------------------------------
    pub fn current_epoch() -> u64 {
        SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_millis() as u64
            / EPOCH_MS
    }

    pub fn leader_of(&self, epoch: u64) -> PeerId {
        let mut set: Vec<PeerId> = self.peers.iter().copied().collect();
        set.push(self.local_id);
        set.sort();
        set[(epoch as usize) % set.len()]
    }

    pub fn is_leader(&self, epoch: u64) -> bool {
        self.leader_of(epoch) == self.local_id
    }

    // --------------------------------------------------------------
    // Inyeccion local de tx (desde el JSON-RPC del secuenciador)
    // --------------------------------------------------------------
    pub fn submit_tx(&mut self, tx: L2Tx) -> Result<(), Box<dyn std::error::Error>> {
        if self.mempool.len() >= MEMPOOL_CAP {
            return Err("mempool llena — aplicar backpressure al ingreso RPC".into());
        }
        if self.mempool.contains_key(&tx.tx_hash) {
            return Ok(()); // duplicada: silenciosa (idempotencia)
        }
        self.mempool.insert(tx.tx_hash, tx.clone());
        let bytes = bincode::serialize(&tx)?;
        self.swarm
            .behaviour_mut()
            .gossipsub
            .publish(self.topic_txs.clone(), bytes)?;
        Ok(())
    }

    // --------------------------------------------------------------
    // Validacion ligera pre-forward (la fuerte la hace el circuito)
    // --------------------------------------------------------------
    fn sanity_check(tx: &L2Tx) -> bool {
        if tx.amount == 0 && tx.fee == 0 {
            return false; // polvo sin valor: no gastar ancho de banda
        }
        let mut h = Sha256::new();
        h.update(tx.sender);
        h.update(tx.receiver);
        h.update(tx.amount.to_be_bytes());
        h.update(tx.fee.to_be_bytes());
        h.update(tx.nonce.to_be_bytes());
        let expected: [u8; 32] = h.finalize().into();
        expected == tx.tx_hash // integridad del payload propagado
    }

    // --------------------------------------------------------------
    // Sellado de batch (solo lider de epoca) — lo consume el prover
    // --------------------------------------------------------------
    pub fn seal_epoch_batch(&mut self, epoch: u64, old_root: [u8; 32], new_root: [u8; 32])
        -> Result<(), Box<dyn std::error::Error>>
    {
        if !self.is_leader(epoch) {
            return Err(format!("no soy lider de la epoca {epoch}").into());
        }
        let tx_hashes: Vec<[u8; 32]> = self.mempool.keys().copied().take(8192).collect();
        let batch = SealedBatch {
            epoch,
            leader: self.local_id,
            old_root,
            new_root,
            tx_hashes: tx_hashes.clone(),
        };
        let bytes = bincode::serialize(&batch)?;
        self.swarm
            .behaviour_mut()
            .gossipsub
            .publish(self.topic_batches.clone(), bytes)?;
        for h in &tx_hashes {
            self.mempool.remove(h); // limpieza del batch sellado
        }
        Ok(())
    }

    // --------------------------------------------------------------
    // Event loop del enjambre
    // --------------------------------------------------------------
    pub async fn run(mut self) -> Result<(), Box<dyn std::error::Error>> {
        let mut last_leader_epoch = Self::current_epoch();
        let mut epoch_tick = tokio::time::interval(Duration::from_millis(500));

        info!(peer = %self.local_id, "mempool node up");
        loop {
            tokio::select! {
                _ = epoch_tick.tick() => {
                    let epoch = Self::current_epoch();
                    if epoch != last_leader_epoch {
                        last_leader_epoch = epoch;
                        let leader = self.leader_of(epoch);
                        let is_self = leader == self.local_id;
                        info!(epoch, %leader, is_self, "rotacion de lider");
                        let _ = self.events_tx.send(MempoolEvent::LeaderChanged {
                            epoch, leader, is_self,
                        }).await;
                    }
                }

                event = self.swarm.select_next_some() => match event {
                    SwarmEvent::NewListenAddr { address, .. } => {
                        info!(%address, "escuchando");
                    }

                    SwarmEvent::Behaviour(MempoolBehaviourEvent::Mdns(
                        mdns::Event::Discovered(list),
                    )) => {
                        for (peer, addr) in list {
                            info!(%peer, %addr, "mDNS: par descubierto");
                            self.swarm
                                .behaviour_mut()
                                .gossipsub
                                .add_explicit_peer(&peer);
                            self.peers.insert(peer);
                        }
                    }

                    SwarmEvent::Behaviour(MempoolBehaviourEvent::Mdns(
                        mdns::Event::Expired(list),
                    )) => {
                        for (peer, _) in list {
                            self.swarm
                                .behaviour_mut()
                                .gossipsub
                                .remove_explicit_peer(&peer);
                            self.peers.remove(&peer);
                        }
                    }

                    SwarmEvent::Behaviour(MempoolBehaviourEvent::Gossipsub(
                        gossipsub::Event::Message { message, .. },
                    )) => {
                        if message.topic == self.topic_txs.hash() {
                            match bincode::deserialize::<L2Tx>(&message.data) {
                                Ok(tx) if Self::sanity_check(&tx) => {
                                    if self.mempool.len() < MEMPOOL_CAP
                                        && !self.mempool.contains_key(&tx.tx_hash)
                                    {
                                        self.mempool.insert(tx.tx_hash, tx.clone());
                                        let _ = self.events_tx
                                            .send(MempoolEvent::TxAccepted(tx)).await;
                                    }
                                }
                                Ok(_) => warn!("tx corrupta (hash mismatch) — descartada"),
                                Err(e) => warn!(error = %e, "tx malformada — descartada"),
                            }
                        } else if message.topic == self.topic_batches.hash() {
                            if let Ok(batch) = bincode::deserialize::<SealedBatch>(&message.data) {
                                let key = (batch.epoch, batch.new_root);
                                if self.seen_batches.insert(key) {
                                    // limpieza: las txs selladas salen de la mempool local
                                    for h in &batch.tx_hashes {
                                        self.mempool.remove(h);
                                    }
                                    let _ = self.events_tx
                                        .send(MempoolEvent::BatchReceived(batch)).await;
                                }
                            }
                        }
                    }

                    SwarmEvent::ConnectionEstablished { peer_id, .. } => {
                        self.peers.insert(peer_id);
                    }
                    SwarmEvent::ConnectionClosed { peer_id, .. } => {
                        self.peers.remove(&peer_id);
                    }

                    _ => {}
                }
            }
        }
    }

    // --------------------------------------------------------------
    // Bootstrap WAN: conectar a pares semilla por multiaddr
    // --------------------------------------------------------------
    pub fn dial_bootstrap(&mut self, addrs: &[Multiaddr]) {
        for addr in addrs {
            if let Err(e) = self.swarm.dial(addr.clone()) {
                warn!(%addr, error = %e, "bootstrap dial fallido");
            }
        }
    }
}

