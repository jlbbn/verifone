//! Sparse Merkle Tree (SMT) desde cero — profundidad 256 bits.
//!
//! Modelo:
//!   - Arbol binario completo de profundidad 256 (una hoja por clave posible
//!     de 32 bytes = espacio de claves de hashes de cuenta).
//!   - Las hojas vacias colapsan a un hash por defecto por nivel:
//!       default[0]   = 0x00..00
//!       default[i+1] = SHA256(default[i] || default[i])
//!     => solo se persisten nodos distintos del default (sparse).
//!   - Nodo interno: SHA256(DOMAIN_INTERNAL || left || right)
//!   - Hoja:         SHA256(DOMAIN_LEAF || balance || nonce || pubkey)
//!     Dominio separado: previene ataques de segunda preimagen hoja/interno.
//!
//! Persistencia: mapa (nivel, prefijo_de_ruta) -> hash del nodo.
//! El prefijo de ruta de un nodo en nivel `lvl` son los primeros `lvl` bits
//! de la clave de la hoja, almacenados alineados a la izquierda (MSB-first)
//! en un [u8; 32].

use sha2::{Digest, Sha256};
use std::collections::HashMap;

pub const DEPTH: usize = 256;
const DOMAIN_LEAF: u8 = 0x00;
const DOMAIN_INTERNAL: u8 = 0x01;

pub type Hash32 = [u8; 32];

// ------------------------------------------------------------------
// Estado de cuenta almacenado en cada hoja
// ------------------------------------------------------------------
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct AccountState {
    pub balance: u128,      // unidades minimas (1e-6 USDT/MXN)
    pub nonce: u64,         // anti-replay, monotono
    pub public_key: Hash32, // X coordenada comprimida secp256k1/schnorr
}

impl AccountState {
    pub const EMPTY: Self = Self { balance: 0, nonce: 0, public_key: [0u8; 32] };

    /// Serializacion canonica big-endian: 16 + 8 + 32 = 56 bytes
    pub fn serialize(&self) -> [u8; 56] {
        let mut out = [0u8; 56];
        out[0..16].copy_from_slice(&self.balance.to_be_bytes());
        out[16..24].copy_from_slice(&self.nonce.to_be_bytes());
        out[24..56].copy_from_slice(&self.public_key);
        out
    }

    pub fn is_empty(&self) -> bool {
        *self == Self::EMPTY
    }

    /// Hash de hoja con separacion de dominio; la hoja vacia colapsa al default[0]
    pub fn leaf_hash(&self) -> Hash32 {
        if self.is_empty() {
            return [0u8; 32];
        }
        let mut h = Sha256::new();
        h.update([DOMAIN_LEAF]);
        h.update(self.serialize());
        h.finalize().into()
    }
}

// ------------------------------------------------------------------
// Hashes por defecto precalculados (lazy, una sola vez)
// ------------------------------------------------------------------
pub struct DefaultHashes(pub [Hash32; DEPTH + 1]);

impl DefaultHashes {
    pub fn new() -> Self {
        let mut d = [[0u8; 32]; DEPTH + 1];
        for lvl in 1..=DEPTH {
            d[lvl] = hash_internal(&d[lvl - 1], &d[lvl - 1]);
        }
        Self(d)
    }
}

#[inline]
fn hash_internal(left: &Hash32, right: &Hash32) -> Hash32 {
    let mut h = Sha256::new();
    h.update([DOMAIN_INTERNAL]);
    h.update(left);
    h.update(right);
    h.finalize().into()
}

// ------------------------------------------------------------------
// Utilidades de bits sobre la clave de 256 bits (MSB-first)
// ------------------------------------------------------------------
#[inline]
fn key_bit(key: &Hash32, level: usize) -> bool {
    // bit `level` contando desde el MSB de key[0]
    (key[level / 8] >> (7 - (level % 8))) & 1 == 1
}

/// Prefijo de ruta: copia la clave y pone a cero todos los bits >= level
fn path_prefix(key: &Hash32, level: usize) -> Hash32 {
    let mut p = *key;
    let full = level / 8;
    let rem = level % 8;
    if rem != 0 {
        p[full] &= 0xFF << (8 - rem); // conserva los `rem` bits altos
        for b in p.iter_mut().skip(full + 1) {
            *b = 0;
        }
    } else {
        for b in p.iter_mut().skip(full) {
            *b = 0;
        }
    }
    p
}

// ------------------------------------------------------------------
// Merkle Proof: 256 hermanos (uno por nivel, raiz -> hoja)
// ------------------------------------------------------------------
#[derive(Clone, Debug)]
pub struct MerkleProof {
    pub siblings: [Hash32; DEPTH],
}

// ------------------------------------------------------------------
// El SMT
// ------------------------------------------------------------------
pub struct SparseMerkleTree {
    /// (nivel, prefijo) -> hash del nodo. Nivel 0 = raiz (prefijo 0x00..00).
    nodes: HashMap<(usize, Hash32), Hash32>,
    defaults: DefaultHashes,
    root: Hash32,
}

impl SparseMerkleTree {
    pub fn new() -> Self {
        let defaults = DefaultHashes::new();
        let root = defaults.0[DEPTH];
        Self { nodes: HashMap::new(), defaults, root }
    }

    pub fn root(&self) -> Hash32 {
        self.root
    }

    /// Hash del nodo en (nivel, clave): si no esta persistido, es el default
    /// del sub-arbol vacio de esa altura.
    fn node_hash(&self, level: usize, key: &Hash32) -> Hash32 {
        let prefix = path_prefix(key, level);
        self.nodes
            .get(&(level, prefix))
            .copied()
            .unwrap_or(self.defaults.0[DEPTH - level])
    }

    /// Hash del hermano del nodo en `level` sobre el camino de `key`:
    /// si el bit `level` de key es 0, el hermano esta a la derecha (bit=1).
    fn sibling_hash(&self, level: usize, key: &Hash32) -> Hash32 {
        let mut sib_key = *key;
        let bit = level; // el bit que diferencia al hermano es el de este nivel
        // flip del bit `bit` en sib_key
        sib_key[bit / 8] ^= 1 << (7 - (bit % 8));
        // El hermano vive en nivel+1 (hijo opuesto del padre en nivel).
        self.node_hash(level + 1, &sib_key)
    }

    // --------------------------------------------------------------
    // Lectura: estado de cuenta por clave (pubkey hash)
    // --------------------------------------------------------------
    pub fn get(&self, key: &Hash32) -> Option<AccountState> {
        // Solo persistimos hashes, no valores: el estado lo mantiene el
        // secuenciador en su DB de hojas; get() aqui resuelve el hash de hoja.
        // (la hoja solo tiene sentido contra la DB externa de estados)
        let _ = key;
        None
    }

    // --------------------------------------------------------------
    // Proof de inclusion/exclusion para `key`
    // siblings[i] = hash del hermano a profundidad i (raiz=0 -> hoja=255)
    // --------------------------------------------------------------
    pub fn prove(&self, key: &Hash32) -> MerkleProof {
        let mut siblings = [[0u8; 32]; DEPTH];
        for level in 0..DEPTH {
            siblings[level] = self.sibling_hash(level, key);
        }
        MerkleProof { siblings }
    }

    // --------------------------------------------------------------
    // Actualizacion: escribe `state` en la hoja `key` y recalcula
    // la raiz. Devuelve (raiz_anterior, raiz_nueva, proof_previo).
    // El proof_previo es el testigo del estado ANTES del cambio:
    // lo consume el circuito ZK para probar la transicion.
    // --------------------------------------------------------------
    pub fn update(&mut self, key: &Hash32, state: &AccountState) -> (Hash32, Hash32, MerkleProof) {
        let old_root = self.root;
        let proof = self.prove(key); // testigo pre-transicion (hermanos no cambian en este update)

        // Recalculo bottom-up: nivel 256 (hoja) -> nivel 0 (raiz)
        let mut current = state.leaf_hash();
        for level in (0..DEPTH).rev() {
            let prefix = path_prefix(key, level + 1);

            // Persistir/limpiar el nodo hijo
            if current == self.defaults.0[DEPTH - (level + 1)] {
                self.nodes.remove(&(level + 1, prefix));
            } else {
                self.nodes.insert((level + 1, prefix), current);
            }

            let sibling = proof.siblings[level];
            current = if key_bit(key, level) {
                hash_internal(&sibling, &current) // nodo a la derecha
            } else {
                hash_internal(&current, &sibling) // nodo a la izquierda
            };
        }

        // Raiz
        if current == self.defaults.0[DEPTH] {
            self.nodes.remove(&(0, [0u8; 32]));
        } else {
            self.nodes.insert((0, [0u8; 32]), current);
        }
        self.root = current;
        (old_root, self.root, proof)
    }

    // --------------------------------------------------------------
    // Verificacion estatica de un proof contra una raiz dada.
    // Recomputa la raiz desde la hoja y compara — misma matematica
    // que replica el circuito ZK en constraints.
    // --------------------------------------------------------------
    pub fn verify_proof(
        root: &Hash32,
        key: &Hash32,
        state: &AccountState,
        proof: &MerkleProof,
    ) -> bool {
        let defaults = DefaultHashes::new();
        let mut current = state.leaf_hash();
        for level in (0..DEPTH).rev() {
            let sibling = proof.siblings[level];
            // Optimizacion: si ambos son default, subir sin rehashear
            if current == defaults.0[DEPTH - (level + 1)]
                && sibling == defaults.0[DEPTH - (level + 1)]
            {
                current = defaults.0[DEPTH - level];
                continue;
            }
            current = if key_bit(key, level) {
                hash_internal(&sibling, &current)
            } else {
                hash_internal(&current, &sibling)
            };
        }
        &current == root
    }
}

// ------------------------------------------------------------------
// Tests de la matematica del arbol
// ------------------------------------------------------------------
#[cfg(test)]
mod tests {
    use super::*;

    fn key(n: u8) -> Hash32 {
        let mut k = [0u8; 32];
        k[31] = n;
        k
    }

    fn acct(balance: u128, nonce: u64, pk: u8) -> AccountState {
        let mut public_key = [0u8; 32];
        public_key[31] = pk;
        AccountState { balance, nonce, public_key }
    }

    #[test]
    fn root_vacia_es_default() {
        let t = SparseMerkleTree::new();
        assert_eq!(t.root(), DefaultHashes::new().0[DEPTH]);
    }

    #[test]
    fn update_y_proof_inclusion() {
        let mut t = SparseMerkleTree::new();
        let k = key(1);
        let a = acct(1_000_000, 0, 7);
        let (_, new_root, proof) = t.update(&k, &a);
        assert!(SparseMerkleTree::verify_proof(&new_root, &k, &a, &proof));
        // estado distinto -> proof invalido
        assert!(!SparseMerkleTree::verify_proof(&new_root, &k, &acct(999, 0, 7), &proof));
        // clave distinta -> proof invalido
        assert!(!SparseMerkleTree::verify_proof(&new_root, &key(2), &a, &proof));
    }

    #[test]
    fn exclusion_es_default_leaf() {
        let mut t = SparseMerkleTree::new();
        let (_, root, _) = t.update(&key(1), &acct(5, 0, 1));
        let proof = t.prove(&key(200));
        // hoja vacia = AccountState::EMPTY
        assert!(SparseMerkleTree::verify_proof(&root, &key(200), &AccountState::EMPTY, &proof));
    }

    #[test]
    fn transicion_secuencial_raices() {
        let mut t = SparseMerkleTree::new();
        let k = key(9);
        let (r0, r1, _) = t.update(&k, &acct(100, 0, 3));
        let (r1b, r2, _) = t.update(&k, &acct(90, 1, 3));
        assert_eq!(r1, r1b);
        assert_ne!(r0, r1);
        assert_ne!(r1, r2);
        // eliminar (vaciar) restaura la raiz original
        let (_, r3, _) = t.update(&k, &AccountState::EMPTY);
        assert_eq!(r3, r0);
    }

    #[test]
    fn esparcimiento_miles_de_hojas() {
        let mut t = SparseMerkleTree::new();
        for i in 0..1000u32 {
            let mut k = [0u8; 32];
            k[28..32].copy_from_slice(&i.to_be_bytes());
            t.update(&k, &acct(i as u128, 0, (i % 251) as u8));
        }
        for i in 0..1000u32 {
            let mut k = [0u8; 32];
            k[28..32].copy_from_slice(&i.to_be_bytes());
            let proof = t.prove(&k);
            assert!(SparseMerkleTree::verify_proof(
                &t.root(), &k, &acct(i as u128, 0, (i % 251) as u8), &proof
            ));
        }
    }
}
