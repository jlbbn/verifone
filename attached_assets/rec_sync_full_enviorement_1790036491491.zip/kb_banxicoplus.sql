-- ================================================================================
-- PROJECT: Banxico Plus LLC - rec_sync_full_enviorement
-- FILE: sql-insight.sql
-- DESCRIPTION: Core schema, replication metrics, and environment sync queries 
--              for TRON Mainnet/Nile nodes and Fiat (Stripe/MercadoPago) webhooks.
-- ENGINE: PostgreSQL 14+
-- ================================================================================

-- --------------------------------------------------------------------------------
-- 1. SCHEMA MIGRATION: SYNCHRONIZATION TABLES
-- --------------------------------------------------------------------------------

CREATE SCHEMA IF NOT EXISTS sync_env;

-- Table to track TRON blocks processed by tron-mainnet-lite / tron-nile-lite
CREATE TABLE IF NOT EXISTS sync_env.tron_blocks (
    block_height BIGINT PRIMARY KEY,
    block_hash VARCHAR(64) UNIQUE NOT NULL,
    environment VARCHAR(20) NOT NULL CHECK (environment IN ('mainnet', 'nile', 'sandbox')),
    timestamp TIMESTAMPTZ NOT NULL,
    synced_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Table for unified transaction states (TRON + Fiat providers)
CREATE TABLE IF NOT EXISTS sync_env.transactions (
    tx_internal_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    provider VARCHAR(50) NOT NULL CHECK (provider IN ('TRON', 'STRIPE', 'MERCADOPAGO')),
    external_tx_id VARCHAR(255) UNIQUE NOT NULL,
    wallet_address VARCHAR(255), -- Applica to TRON (e.g., tron-signer-mainnet)
    amount NUMERIC(20, 6) NOT NULL,
    currency VARCHAR(10) NOT NULL,
    status VARCHAR(50) NOT NULL CHECK (status IN ('PENDING', 'CONFIRMED', 'FAILED', 'SYNCING')),
    environment VARCHAR(20) NOT NULL CHECK (environment IN ('mainnet', 'sandbox')),
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- --------------------------------------------------------------------------------
-- 2. CRITICAL INDEXES FOR QUERY OPTIMIZATION (I/O EFFICIENCY)
-- --------------------------------------------------------------------------------

-- Index for fast retrieval of pending synchronizations between mainnet and sandbox
CREATE INDEX IF NOT EXISTS idx_tx_status_env 
ON sync_env.transactions (status, environment) 
WHERE status = 'SYNCING';

-- Index for block height monitoring (Poller queries)
CREATE INDEX IF NOT EXISTS idx_tron_blocks_height_env 
ON sync_env.tron_blocks (environment, block_height DESC);

-- --------------------------------------------------------------------------------
-- 3. DIAGNOSTIC QUERY: SYNC BOTTLENECKS & LAG MONITORING
-- --------------------------------------------------------------------------------

-- Calculates the block lag between the mainnet node and the sandbox/sync environment
WITH NodeLatest AS (
    SELECT environment, MAX(block_height) as max_height, MAX(timestamp) as last_block_time
    FROM sync_env.tron_blocks
    GROUP BY environment
)
SELECT 
    m.max_height AS mainnet_height,
    s.max_height AS sandbox_height,
    (m.max_height - COALESCE(s.max_height, 0)) AS block_lag,
    EXTRACT(EPOCH FROM (CURRENT_TIMESTAMP - m.last_block_time))/60 AS minutes_since_last_mainnet_block,
    CASE 
        WHEN (m.max_height - COALESCE(s.max_height, 0)) > 100 THEN 'CRITICAL_LAG'
        ELSE 'HEALTHY'
    END as sync_health_status
FROM NodeLatest m
LEFT JOIN NodeLatest s ON s.environment = 'sandbox'
WHERE m.environment = 'mainnet';

-- --------------------------------------------------------------------------------
-- 4. PROCEDURE: FULL ENVIRONMENT SYNC (REC_SYNC)
-- --------------------------------------------------------------------------------
-- This mimics the safe promotion of data from banxico.plus-db to banxico.plus-sandbox-db
-- without copying sensitive keys or webhook secrets.

CREATE OR REPLACE FUNCTION sync_env.replicate_to_sandbox()
RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
    -- 1. Upsert TRON confirmed transactions to Sandbox schema (obfuscating wallets if needed)
    INSERT INTO sync_env.transactions (external_tx_id, provider, amount, currency, status, environment)
    SELECT 
        external_tx_id, 
        provider, 
        amount, 
        currency, 
        'CONFIRMED', 
        'sandbox'
    FROM sync_env.transactions
    WHERE environment = 'mainnet' AND status = 'CONFIRMED'
    ON CONFLICT (external_tx_id) DO NOTHING;

    -- 2. Clean up dead tuples in sandbox tracking
    DELETE FROM sync_env.transactions 
    WHERE environment = 'sandbox' AND created_at < NOW() - INTERVAL '30 days';

END;
$$;